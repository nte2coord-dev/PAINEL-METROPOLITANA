# Portal SRE Metropolitana A

Site que substitui a planilha "DESKTOP WEB" usada como página inicial do
Setor de Pagamento — e que agora serve **todos os setores da Metropolitana
A**, cada um com seu próprio espaço isolado de grupos e sistemas. Mesma
função da planilha original (um painel com atalhos para os sistemas do dia
a dia, organizados em grupos), com visual moderno, busca rápida, tema
claro/escuro — e tudo **editável diretamente pelo site**: criar/editar/mover
sistemas entre grupos, trocar cores, adicionar mais de um link por sistema,
criar novos grupos e, agora, cadastrar novos setores.

## Estrutura do projeto

```
.
├── index.html          # marcação da página (cabeçalho, busca, modais)
├── css/styles.css       # estilos, cores, tema e responsividade
├── js/vendor/supabase-js.umd.js  # biblioteca oficial do Supabase (baixada, não CDN — ver seção de autenticação)
├── js/supabase.js        # cliente pro Supabase (sessão de verdade, RPC, Edge Functions)
├── js/store.js            # camada de dados: le/escreve no Supabase + paleta de cores
├── js/app.js               # views, navegação, modais, busca
├── js/sicalc-data.js        # SICALC: cargos/situações/meses/verbas (estático); vencimentos/faixas/IPSEMG vêm do banco (ver seção própria)
├── js/sicalc.js               # calculadora "Calculadora de Pagamento" (cálculos do SICALC)
├── js/leitor-diario/              # leitor do Diário Oficial de MG (compilado de TypeScript — ver seção própria)
├── js/leitor-diario-view.js        # tela da ferramenta "Leitor do Diário" (upload, processar, tabela de resultado)
├── supabase/config.toml         # estrutura exigida pela integração Supabase+GitHub (ver seção própria)
├── supabase/migrations/*.sql      # mudanças no banco, na ordem que devem ser aplicadas
├── supabase/functions/             # Edge Functions (criar/remover conta) — publicação manual, ver seção própria
└── assets/                         # logo e favicon
```

## Como visualizar localmente

Não há build nem dependências. Basta servir a pasta com qualquer servidor
estático, por exemplo:

```bash
python3 -m http.server 8000
```

e abrir `http://localhost:8000` no navegador (o site já conecta no mesmo
banco Supabase compartilhado — não precisa de nenhum servidor próprio).

## Como editar pelo site (sem mexer em código)

- **Adicionar sistema**: dentro de um grupo, botão "+ Adicionar novo sistema"
  no topo da página (só aparece depois que você entra em algum grupo).
- **Editar um sistema**: passe o mouse sobre o card e clique no lápis (título,
  sigla/cor do selo, ícone, grupo, documentos/links).
- **Vários documentos por sistema**: no editor do sistema, clique em
  "+ Adicionar documento" quantas vezes precisar. Se o sistema tiver mais de
  um link, ao clicar no card a pessoa escolhe qual abrir. Cada documento
  pode ser um **link** (cole a URL) ou um **arquivo anexado direto**
  (clique no ícone de clipe, limite de 4 MB) — arquivo anexado fica salvo
  no banco de dados do portal, junto com o resto, e aparece pra quem abrir
  o portal em qualquer computador.
- **Mover um sistema para outro grupo**: abra o sistema pelo lápis e troque o
  campo "Grupo".
- **Criar um grupo**: tile tracejado "+ Novo grupo" na tela inicial.
- **Editar um grupo**: lápis ao lado do nome do grupo (dentro do grupo) ou no
  card do grupo na tela inicial — nome, cor e ícone. Um grupo só pode ser
  excluído se estiver vazio (mova ou apague os sistemas primeiro).
- **Usar uma imagem própria como ícone**: no editor do sistema ou do grupo,
  em "Ícone" clique em "Escolher imagem" e selecione um arquivo do
  computador. A imagem é recortada ao quadrado e reduzida automaticamente;
  "Remover imagem" volta pro selo colorido com a sigla/ícone de pasta.
- **Criar um setor novo** (só o diretor): tile tracejado "+ Novo setor" no
  Painel de Setores. Pede só nome, cor e ícone — o setor nasce **sem
  nenhuma conta**. Depois de criado, o diretor já cai dentro do setor novo
  pra começar a montar os grupos e sistemas; pra dar acesso a alguém
  (coordenador ou servidor), use o botão "Servidores" pra cadastrar
  diretamente ou aprove um pedido de acesso (ver seções de login abaixo).
  Um setor só pode ser excluído se estiver vazio (sem nenhum grupo).

## Login (o portal inteiro é protegido por senha) e os três papéis

Ao abrir o site, aparece direto uma tela pedindo pra escolher **como você
vai entrar** — Diretor, Coordenador ou Servidor — e só depois disso pede
usuário/e-mail e senha; nada do portal (grupos, sistemas, busca) aparece
antes disso. Escolher o papel errado (mesmo com a senha certa) mostra um
aviso em vez de liberar o acesso — um "← Voltar" retorna pra escolha do
papel. Existem três papéis:

| Papel | Pode fazer |
|-------|------------|
| **Diretor** | Acesso a **todos os setores**. Ao entrar, cai no **Painel de Setores** (visão geral de todos os setores cadastrados) em vez de cair direto num setor. Dali pode cadastrar um setor novo (nasce sem conta nenhuma), cadastrar coordenadores/servidores direto ou aprovar pedidos de acesso pra dar conta a alguém em qualquer setor, promover/revogar coordenador de qualquer setor (menu ☰ → "Gerenciar acessos", ver seção própria abaixo), renomear/recolorir ou excluir um setor vazio, e **entrar** em qualquer setor — uma vez dentro, tem exatamente os mesmos poderes do coordenador daquele setor (criar/editar/mover/excluir grupos e sistemas, ver/cadastrar/remover os coordenadores e servidores daquele setor). Um botão "← Painel de Setores" no topo, ou o menu ☰ no cabeçalho ("Gerenciar setores"), levam de volta à visão geral a qualquer momento, de dentro de qualquer setor. Hoje só davi.zicker e o Kelson (conta `sre.metropa.dipe@educacao.mg.gov.br`) têm esse papel. |
| **Coordenador** | Preso ao próprio setor: navegar, criar/editar/mover/excluir sistemas e grupos daquele setor, trocar ícones e cores, ver/cadastrar/remover os coordenadores e servidores daquele setor (botão "Servidores") e promover/revogar coordenador de alguém já cadastrado no próprio setor (botão "Gerenciar acessos", ver seção própria abaixo). |
| **Servidor** | Preso ao próprio setor, só navegar e abrir o que o coordenador publicou — nenhum botão de editar, adicionar, excluir ou "Servidores" aparece. |

Qualquer papel logado (diretor, coordenador ou servidor) pode abrir o
ícone de engrenagem no cabeçalho pra trocar o **próprio** nome/senha —
ver "Configurações" mais abaixo.

Existe uma conta de fábrica de cada tipo (o usuário não diferencia
maiúsculas/minúsculas):

| Usuário/e-mail                              | Senha        | Papel        |
|----------------------------------------------|--------------|--------------|
| `sre.metropa.dipe@educacao.mg.gov.br`         | `diretor123` | Diretor (acesso a todos os setores) |
| `everton`                                     | `12345`      | Coordenador do Setor de Pagamento |
| `pagamento`                                   | `54321`      | Servidor (visualização) do Setor de Pagamento |

O diretor loga com o e-mail institucional do Kelson (em vez de um
"usuário") — a primeira vez que entrar, pede um código de verificação
mandado pra esse e-mail (ver seção própria abaixo). **Troque a senha do
diretor pelo próprio site assim que possível** (depois de entrar, abra o
ícone de engrenagem e troque a senha ali).

- Depois de entrar uma vez, o acesso fica liberado nessa aba do navegador
  até alguém clicar no ícone de saída no cabeçalho (ao lado do tema
  claro/escuro) ou fechar a aba/janela — não precisa digitar a senha de
  novo a cada recarregada de página na mesma aba, e o diretor continua
  exatamente onde estava (no Painel ou dentro do setor em que tinha
  entrado). Isso permite trocar de usuário num computador compartilhado.
- **Configurações**: o ícone de engrenagem mostra sempre a **própria
  conta** de quem está logado (nome e senha) — nunca a de outra pessoa,
  mesmo que o setor tenha mais de um coordenador ou servidor cadastrado.
  Deixe a senha em branco para não alterá-la.

### Cadastrar coordenador ou servidor: dois jeitos

Existem hoje dois jeitos de dar acesso a alguém — os dois criam a mesma
conta por baixo (nome, MASP, telefone, cargo, e-mail institucional, papel
e senha inicial), a diferença é só quem começa o processo:

**1. Cadastro direto (diretor ou o próprio coordenador do setor)**

Dentro de um setor (o coordenador no próprio setor, ou o diretor depois
de "entrar" nele), o botão **"Servidores"** no topo mostra a lista de
coordenadores e servidores daquele setor, separados em duas seções, e um
botão **"+ Cadastrar servidor"**:

1. Preenche nome completo, MASP, telefone (opcional), cargo (opcional),
   e-mail institucional (precisa terminar em `@educacao.mg.gov.br`), o
   papel (Coordenador ou Servidor) e uma senha inicial.
2. A conta já é criada na hora — sem precisar de nenhum pedido de acesso
   antes. Passe o e-mail e a senha inicial pra pessoa; ela troca a senha
   depois de entrar, em Configurações (ver acima).
3. "Remover" na lista de Servidores tira o acesso de alguém cadastrado por
   engano ou que saiu do setor.

**2. Auto-cadastro + aprovação do diretor**

Pra quem ainda não tem conta e prefere se cadastrar em vez de esperar o
coordenador cadastrar:

1. Na tela de login, quem ainda não tem acesso clica em "Cadastre-se" e
   preenche os próprios dados: nome completo, MASP, telefone (opcional),
   cargo (opcional), e-mail institucional (precisa terminar em
   `@educacao.mg.gov.br`, confirmado tanto no navegador quanto no banco),
   o setor e uma senha (com confirmação). O pedido cai numa fila.
2. O diretor vê os pedidos pendentes no topo do Painel de Setores
   ("Solicitações de acesso"), já com o nome ao lado do e-mail. Em
   "Cadastrar", os dados já vêm todos pré-preenchidos (dá pra corrigir
   algo antes de confirmar) — só falta escolher o papel (Coordenador ou
   Servidor) e clicar em "Cadastrar": **não precisa mais digitar senha
   nenhuma**, porque a pessoa já escolheu a própria no cadastro. Isso cria
   a conta de verdade (a mesma coisa que o cadastro direto cria) e some
   com o pedido da fila. "Dispensar" remove o pedido sem criar conta (e,
   se a pessoa quiser, pode se cadastrar de novo com o mesmo e-mail depois
   — nada fica "preso").

Em qualquer um dos dois casos, a pessoa loga digitando o próprio e-mail
(em vez de um "usuário") e a senha inicial — na primeira vez, precisa
confirmar o e-mail com um código (ver seção abaixo); depois disso funciona
igual a qualquer coordenador/servidor (fica presa ao setor escolhido,
aparece só a própria conta em Configurações, etc.).

As contas antigas (`everton`, `pagamento`) continuam logando pelo usuário
de sempre — o e-mail é só uma segunda forma de identificar a conta, cada
conta usa uma ou a outra, nunca as duas.

### Gerenciar acessos: promover/revogar coordenador

Além de cadastrar e remover (acima), dá pra trocar o papel de quem **já**
tem conta — sem precisar remover e cadastrar de novo. Coordenador abre
pelo botão **"Gerenciar acessos"** no topo (ao lado de "Servidores");
diretor abre pelo menu ☰ → **"Gerenciar acessos"** (funciona tanto no
Painel de Setores quanto de dentro de qualquer setor). A tela é uma
tabela só de leitura **Nome / E-mail / Setor / Papel / Ação**:

- **Coordenador** vê só o próprio setor, sem filtro nenhum (não tem como
  ver ou afetar outro setor — nem pela tela, nem chamando a Edge Function
  direto, ver "Autenticação de verdade… RLS por papel/setor" abaixo).
- **Diretor** vê todo mundo de uma vez, com um filtro de setor no topo da
  tabela ("Todos os setores" ou um setor específico).
- Cada linha de coordenador ou servidor tem um botão: **"Tornar
  coordenador"** (servidor → coordenador) ou **"Revogar coordenador"**
  (coordenador → servidor), com uma confirmação antes de aplicar. A
  própria "caixinha" do papel (coluna Papel) faz a mesma coisa — é só um
  atalho pra não precisar olhar pra coluna Ação.
- Linhas de **diretor não têm botão** (aparecem só pra conferência, com
  "—" na coluna Ação) — promover alguém a diretor continua sendo só um
  passo manual direto no SQL, de propósito (ver seção do Supabase).

Essa troca de papel é a mesma Edge Function `manage-account` usada pra
cadastrar/remover conta (ação `set_role`), com a mesma regra de permissão
de sempre: diretor em qualquer setor, coordenador só no próprio.

### Verificação de e-mail no primeiro login (só diretor, exceto quem administra o site)

**Só o papel diretor** precisa confirmar que é dono do próprio e-mail **na
primeira vez** que entra: depois da senha certa, o site manda um código de
verificação pro e-mail e pede pra digitar esse código antes de liberar o
acesso. Da segunda vez em diante, não pede mais. Coordenador e servidor
**não passam por essa etapa**, mesmo tendo e-mail institucional e mesmo no
primeiro login — a senha certa já é suficiente pra eles (decisão explícita:
o diretor é a única conta de acesso geral, então só ela recebe essa camada
extra de confirmação). A conta de quem administra o site (`accounts.email`
listado em `EMAIL_VERIFICATION_EXEMPT`, em `js/store.js`) fica de fora
dessa etapa mesmo sendo diretor — só as outras contas de diretor (o Kelson,
por exemplo) passam por ela de verdade. Pra adicionar ou tirar alguém dessa
lista, edite esse array direto no arquivo.

- O envio do código usa o **Auth do próprio Supabase** (o mesmo projeto,
  sem servidor nem serviço de e-mail extra) — só pra essa confirmação
  pontual; o login "de verdade" continua sendo a tabela `accounts` de
  sempre. Pra isso funcionar, o projeto Supabase precisa ter o provedor
  de e-mail do Auth habilitado (normalmente já vem assim; confira em
  Authentication → Providers → Email, no painel do Supabase).
- **SMTP customizado é obrigatório**, não só recomendado: o remetente
  padrão do Supabase só manda esse e-mail pro próprio dono da conta
  Supabase, nunca pra terceiros (nem pro diretor) — sem configurar um SMTP
  próprio em Authentication → Emails → SMTP Settings, esse código nunca
  chega. Projetos gratuitos de SMTP (ex: Resend) também restringem o
  domínio de envio padrão ao próprio dono da conta até um domínio de
  verdade ser verificado — verifique um domínio (qualquer um que você
  tenha acesso ao DNS) antes de considerar isso resolvido de vez.
- Contas sem e-mail institucional (login por usuário, como `everton`/
  `pagamento`) nunca passam por essa etapa, independente do papel.

### "Esqueceu a senha?" (código por e-mail, sem precisar estar logado)

Na tela de login, depois de escolher o tipo de acesso (diretor/coordenador/
servidor), tem um link **"Esqueceu a senha?"** embaixo do campo de senha.
Funciona em dois passos, com verificação de duas etapas pelo e-mail — o
mesmo mecanismo de código do item acima, só que disparado antes do login
em vez de depois:

1. A pessoa digita o **e-mail institucional** da própria conta. O site
   sempre avança pro passo seguinte, dê ou não dê conta pra aquele e-mail
   — de propósito, pra ninguém de fora conseguir descobrir quais e-mails
   têm acesso ao portal só tentando essa tela.
2. Um código de 6 dígitos chega no e-mail (mesmo Auth do Supabase, mesmo
   SMTP customizado do item acima — é a mesma infraestrutura, então tudo
   que está configurado pra verificação de e-mail já vale pra isso
   também, sem precisar de nada extra). A pessoa digita o código e a
   senha nova (duas vezes, pra confirmar) e pronto — a senha já está
   trocada, e ela entra com a senha nova a partir daí.

**Só funciona pra contas com e-mail institucional cadastrado**
(`accounts.email`, formato `@educacao.mg.gov.br`) — contas antigas,
login por usuário sem e-mail (como `everton`/`pagamento`, enquanto
continuarem assim), não têm pra onde mandar o código; nesse caso só o
diretor consegue trocar a senha delas (editando a conta, ou cadastrando
um e-mail institucional pra ela primeiro). Funciona tanto pra quem já
logou antes quanto pra quem nunca logou (a função
`link_auth_after_password_reset`, na migração
`20261008000000_forgot_password.sql`, liga a conta à sessão confirmada
pelo código na primeira vez que isso for necessário — sempre comparando
e-mail com e-mail, nunca deixando ligar a conta errada).

### Autenticação de verdade (Supabase Auth) + RLS por papel/setor

Esse é o ponto mais importante desta seção: **o site inteiro passou a usar
autenticação de verdade**, com o próprio banco de dados decidindo o que
cada papel pode ver e fazer — não é mais só a tela escondendo botão.

- **Login**: continua exatamente com a mesma cara (escolher o papel, digitar
  usuário/e-mail e senha, código do e-mail só na primeira vez e só pro
  diretor — ver seção própria abaixo) — por baixo,
  quem confere a senha agora é o [Supabase Auth](https://supabase.com/docs/guides/auth)
  de verdade, não uma função nossa comparando texto. Contas antigas (que só
  tinham "usuário", sem e-mail) migram sozinhas, sem precisar trocar de
  senha nem fazer nada diferente: no primeiro login de cada uma depois
  dessa mudança, a senha digitada é conferida contra o valor antigo uma
  única vez e a conta passa a usar o Auth de verdade dali em diante — a
  senha antiga em texto puro é apagada nesse momento.
- **Senhas não ficam mais em texto puro em lugar nenhum**: o Supabase Auth
  guarda senha com hash (o padrão da indústria) — nem um acesso direto ao
  banco mostra a senha de ninguém.
- **RLS (Row Level Security) real, por papel e por setor**: as regras de
  quem pode ler/criar/editar/apagar cada linha agora vivem no próprio
  Postgres (`supabase/migrations/20260929020000_rls_by_role.sql`), não só
  no JavaScript da tela:
  - Diretor: lê e edita qualquer setor.
  - Coordenador: só lê/edita o próprio setor (`groups`/`systems`) e só vê
    as contas do próprio setor.
  - Servidor: só lê o próprio setor, não edita nada.
  - Qualquer papel: só lê/edita a própria conta em `accounts` (e só o
    campo "nome" — trocar de papel ou de setor não é possível nem pra si
    mesmo, isso é column-level `GRANT`, uma segunda camada além do RLS).
  - `solicitacoes_acesso`: qualquer um pode criar um pedido (mesmo sem
    estar logado); só diretor vê e processa a fila.
  - `setores`: legível por qualquer um, mesmo sem estar logado (o
    formulário de auto-cadastro precisa listar os setores antes da pessoa
    logar) — nada sensível ali, só nome/cor/ícone; escrever continua só
    com diretor.

  Isso significa que alguém que abrir as ferramentas de desenvolvedor do
  navegador e tentar chamar a API direto, pulando a tela — o que **dava**
  pra fazer antes — agora recebe erro de permissão do próprio banco,
  mesmo sabendo a chave pública do projeto. Isso foi testado de propósito
  tentando exatamente esses ataques (ler dados de outro setor, criar uma
  conta de diretor pra si mesmo, trocar o próprio papel) direto contra um
  Postgres real, não só no site.
- **Criar ou remover uma conta** (auto-cadastro, aprovar pedido, cadastro
  direto, botão "Remover") exige uma chave secreta que só existe no lado
  do Supabase, nunca no navegador — por isso essas ações passaram a ser
  **Edge Functions** (`supabase/functions/legacy-login` e
  `supabase/functions/manage-account`) em vez de funções SQL comuns. É a
  única parte do projeto que deixa de ser "puro HTML/JS estático" — ver
  como publicar essas duas funções na seção abaixo.

**O que isso não resolve** (limitações que continuam): quem tiver acesso
de coordenador/servidor de verdade (login válido) continua vendo e editando
o que aquele papel já tinha direito de ver — RLS protege contra pular a
tela ou acessar o que não é seu, não contra o uso indevido de uma conta
legítima. E a senha ainda é só uma senha (sem exigir letra maiúscula,
número, etc. além do mínimo de 6 caracteres do próprio Supabase) — não
tem MFA nesta versão.

### Onde os dados ficam salvos: banco de dados compartilhado (Supabase)

Diferente da primeira versão deste site (que guardava tudo em
`localStorage`, por navegador), agora os dados ficam num banco Postgres
gratuito no [Supabase](https://supabase.com) — o que o coordenador editar
aparece pra qualquer computador que abrir o portal (basta recarregar a
página).

- **Schema**: `supabase/migrations/*.sql` — tabelas `setores`/`groups`/
  `systems`/`solicitacoes_acesso`/`accounts`, todas com RLS de verdade
  (ver seção de autenticação acima). Também `sicalc_vencimentos`/
  `sicalc_previd_faixas`/`sicalc_ipsemg` (parâmetros da Calculadora de
  Pagamento, editáveis pela própria tela — ver "Parâmetros do ano" na
  seção da ferramenta), com leitura liberada pra qualquer logado e escrita
  restrita a diretor/dev ou coordenador do setor que hospeda a ferramenta
  no momento (achado dinamicamente, não fixo em "Setor de Pagamento"). Funções que sobraram no banco (só
  as que não exigem a chave secreta): `resolve_login_email` e
  `login_needs_migration` (usadas no login, pra saber se uma conta ainda
  usa a senha antiga), e `mark_email_verified()` (marca
  `accounts.email_verified_at` depois do código de verificação — sem
  parâmetro, sempre marca a própria conta de quem chamou). Criar/remover
  conta de verdade (`approve_access_request`/`create_servidor`/
  `delete_account` de antes) virou as Edge Functions abaixo, porque
  precisam da chave secreta do Auth. O e-mail em `solicitacoes_acesso` e
  em `accounts` tem um `check` no próprio banco garantindo que termine em
  `@educacao.mg.gov.br`. `solicitacoes_acesso` também guarda name/masp/
  telefone/cargo/setor_id (preenchidos pela própria pessoa no
  auto-cadastro) e `auth_user_id` (liga o pedido ao usuário já criado no
  Auth com a senha que ela mesma escolheu — aprovar só reaproveita esse
  usuário, nunca cria um novo nem guarda senha em texto puro ali).
- **Edge Functions** (`supabase/functions/`) — os dois únicos pedaços de
  código que rodam no servidor do Supabase, não no navegador de quem
  acessa, porque só eles têm a chave secreta (`service_role`) que fala
  com o Auth:
  - `legacy-login`: migra uma conta antiga (com senha em texto puro) pro
    Auth de verdade, no primeiro login dela depois dessa mudança.
  - `manage-account`: cinco ações, sempre confirmando que quem está
    chamando tem o papel certo (menos "register", que é chamada por quem
    ainda nem tem conta):
    - `register`: auto-cadastro — cria o usuário no Auth com a senha que
      a pessoa escolheu e guarda o pedido em `solicitacoes_acesso`.
    - `create`: cria a conta de verdade (aprovar pedido ou cadastro
      direto) — reaproveita o usuário do Auth já criado pelo `register`
      quando vem de um pedido, em vez de criar de novo.
    - `reject_request`: recusa um pedido — apaga o usuário órfão no Auth
      se veio de auto-cadastro (o pedido some sozinho, `on delete
      cascade`), liberando o e-mail pra tentar de novo.
    - `delete`: remove uma conta (botão "Remover").
    - `set_role`: promove servidor → coordenador ou revoga coordenador →
      servidor (tela "Gerenciar acessos", ver seção própria acima). Só
      troca entre esses dois papéis — nunca aceita diretor como
      origem ou destino.

  **Diferente das migrações, essas duas funções não publicam sozinhas** —
  a integração do GitHub cobre só `supabase/migrations/`. Publique (ou
  atualize, se o código de uma delas mudar) direto no painel do Supabase:
  Edge Functions → Deploy a new function → cole o conteúdo de
  `supabase/functions/<nome>/index.ts` → Deploy. Repita pra cada uma das
  duas. **As duas precisam existir no projeto antes do banco começar a
  usar RLS de verdade** (a migração `20260929020000_rls_by_role.sql`) —
  senão ninguém consegue logar (todo login de conta ainda não migrada
  passa por `legacy-login`).

  **Depois de publicar (passo obrigatório, senão o login não funciona):**
  em cada uma das duas, abra a função no painel → "Enforce JWT
  Verification" (ou "Verify JWT") → **desligue**. Por padrão o Supabase
  liga essa verificação em toda função nova, e ela roda antes mesmo do
  código da função — inclusive na requisição `OPTIONS` que o navegador
  manda primeiro (preflight de CORS), que nunca leva um token de sessão
  porque, no caso de `legacy-login`, a pessoa ainda nem logou. Com a
  verificação ligada, esse preflight é rejeitado e o navegador nunca chega
  a chamar a função de verdade — o login trava com um erro genérico de
  CORS/conexão, mesmo com o código certo publicado. As duas funções já
  conferem quem está chamando por conta própria (`legacy-login` confere a
  senha antiga; `manage-account` valida o token de quem chamou à mão), então
  desligar essa verificação da plataforma é seguro e esperado, não uma
  brecha.
- **Deploy automático via GitHub**: o projeto Supabase está conectado a
  este repositório (Settings → Integrations → GitHub, branch de produção
  `main`) — toda vez que um commit muda algo em `supabase/migrations/` e
  chega em `main`, o Supabase aplica automaticamente as migrações novas
  no banco de produção, sem precisar abrir o SQL Editor manualmente.
  `supabase/migrations/20260929000000_initial_schema.sql` é a migração
  "inicial": junta tudo que antes era colado manualmente num `schema.sql`
  só, reunido num arquivo continua **idempotente** de propósito ("if not
  exists", "on conflict do nothing"), então roda sem erro nem duplicação
  independente do estado em que o banco já estava. **A partir de agora,
  toda mudança nova no banco entra como um arquivo novo** em
  `supabase/migrations/` (nome no formato `AAAAMMDDHHMMSS_descrição.sql`,
  em ordem cronológica) — não editamos mais um arquivo único.
  `supabase/config.toml` só existe porque a integração exige essa
  estrutura de pasta; não usamos a CLI do Supabase nem o stack local.
- **Conectar o site a um projeto Supabase diferente** (ex: trocar de conta,
  recriar o projeto): edite `SUPABASE_URL` e `SUPABASE_KEY` no topo de
  `js/supabase.js` com a "Project URL" e a "Publishable key" (Settings →
  API do projeto no Supabase), conecte esse projeto novo à mesma
  integração GitHub (ou rode o conteúdo de cada arquivo em
  `supabase/migrations/`, em ordem, uma vez no SQL Editor dele, pra criar
  a base), e publique as duas Edge Functions nele também (ver acima) —
  sem isso, ninguém consegue logar no projeto novo.
- **Se o banco ficar fora do ar ou a chave estiver errada**: a tela de
  login mostra um aviso vermelho ("Não foi possível carregar os dados do
  banco...") e o botão de entrar fica desabilitado — o site não trava
  silenciosamente. Se uma edição específica não conseguir salvar (ex: perda
  de conexão no meio do uso), o mesmo aviso vermelho aparece no topo do
  site — a mudança fica visível na tela na hora, mas convém confirmar que
  salvou de verdade (recarregando a página) antes de sair.

## Ferramenta: Calculadora de Pagamento

Dentro do grupo **Ferramentas** existe um sistema especial, "Calculadora
de Pagamento", que não abre um link — ele abre uma calculadora embutida no
próprio site. Ela foi construída a partir das fórmulas reais da planilha
`SICALC_2025.xlsm` do Everton (abas DADOS/TELA/VENCIMENTOS/PREVID/IPSEMG/
OCORRENCIA/TABELAS), conferida contra o exemplo real que já estava
calculado na própria planilha (cargo ANEI, nível 1, grau A, 40H, situação
"02 Convocado", de 25 a 30/11/2025, incluída na taxação de 06/2026 =>
vencimento R$ 7.301,95, pró-rata R$ 1.460,39, contribuição INSS R$ 109,53):

- **Vencimento básico pró-rata**: `vencimento íntegro da vigência ÷ divisor
  × dias do período`, com o mesmo divisor da planilha original (108 para
  PEB/PEBS, 30 para os demais cargos) e a mesma tabela de vencimentos
  (cargo + carga horária + nível + grau, versionada por ano — guardada no
  banco, tabela `sicalc_vencimentos`, editável pela própria tela, ver
  "Parâmetros do ano" mais abaixo).
- **Contribuição previdenciária (INSS ou RPPS)**: faixas progressivas com
  "parcela a deduzir" (igual à aba PREVID), escolhidas automaticamente pela
  situação funcional — RPPS pra Efetivo (01/16) e Nomeado (28), INSS pra
  Convocado (02) e Contrato (21). Tem dois campos avançados opcionais
  (outros rendimentos no mês / valor já descontado) que só valem pro ramo
  INSS, iguais aos da planilha original.
- **Desconto do IPSEMG**: 3,2% da base (titular e/ou cônjuge, cada um com
  teto de R$ 500) mais 1% extra (mesmo teto) pra quem tiver 59 anos ou mais.
- **Texto pra ocorrência do SISAP**: monta a frase exatamente como a
  planilha monta ("PAGO 6 DIAS DE NOV-25 REF CONVOCAÇÃO ANEI1A DE 25/11/25
  A 30/11/25 TX 06/2026."), com um botão de copiar.
- Cada valor mostra o **código de verba** correspondente (2916 vencimento
  básico, 7837 contribuição, 7732 IPSEMG titular, 8716 IPSEMG cônjuge) pra
  facilitar o lançamento no SISAP.

**O que a calculadora ainda NÃO faz:**

- **Situação "04/40 Aposentado" fica sem contribuição calculada.** A tabela
  de faixa dela na própria planilha original (`PREVID!A23:D29`) tem
  intervalos sobrepostos e faixas vazias — o arquivo em si está incompleto
  nessa parte, então preferimos avisar em vez de inventar um valor. As
  outras 5 situações (01/02/16/21/28) têm a tabela de faixa completa e
  conferida.
- **A.E.C./A.E.J. (Extensão de Jornada) não são somados.** A calculadora só
  soma vencimento básico (R.B.); a planilha original soma R.B.+A.E.C.+A.E.J.
  antes de aplicar as faixas de contribuição e o IPSEMG. Se o período
  também tiver A.E.C./A.E.J. retroativo, os valores de contribuição/IPSEMG
  calculados aqui ficam subestimados.

Só a situação funcional "02 Convocado" tem o texto de ocorrência 100%
confirmado contra um exemplo real; as outras (01/16 Efetivo, 21 Contrato,
28 Nomeado, 04 Aposentado) aparecem marcadas como "revisar texto" no
resultado — o cálculo do valor funciona igual (exceto Aposentado, acima),
mas revise a palavra depois de "REF" no texto antes de colar no SISAP.

### Parâmetros do ano (pro Everton atualizar sozinho, sem pedir mudança de código)

A tabela de vencimentos, as faixas de contribuição (INSS/RPPS) e os valores
do IPSEMG não ficam mais escritos num arquivo de código — moraram pro banco
(tabelas `sicalc_vencimentos`, `sicalc_previd_faixas` e `sicalc_ipsemg`, ver
`supabase/migrations/20261007000000_sicalc_data_tables.sql`). Quem é
coordenador do setor que hospeda esta ferramenta (ou o diretor) edita esses
valores direto pela tela, dentro da própria Calculadora de Pagamento, numa
seção chamada **"Parâmetros do ano"** (aparece recolhida, no fim da tela —
clique para abrir). Quem só visualiza (servidor) não vê essa seção.

**Instruções pro Everton — como importar a tabela de vencimentos de uma
vigência nova (ex: 2026):**

1. Abra a planilha do ano novo no Excel. Selecione, na aba de vencimentos,
   as 5 colunas na ordem **cargo, carga horária, nível, grau, valor** — a
   mesma ordem de sempre — para todas as linhas (não precisa incluir a
   linha de cabeçalho, mas não tem problema se incluir: a tela reconhece e
   ignora).
2. Copie (Ctrl+C) exatamente essas células.
3. No site: entre no Setor de Pagamento → Ferramentas → Calculadora de
   Pagamento → abra a seção "Parâmetros do ano" (clique nela para expandir)
   → "Importar vencimentos de uma vigência".
4. No campo **"Ano desta vigência"**, digite o ano (ex: `2026`).
5. Clique dentro do campo **"Colar aqui"** e cole (Ctrl+V) o que você
   copiou no passo 2.
6. Clique em **"Validar"**. A tela mostra quantas linhas estão prontas e
   quantas têm problema. Se alguma linha der erro (combinação de cargo/
   carga/nível/grau que não existe, ou um valor que não parece número), ela
   aparece numa tabelinha com o motivo — confira se não é erro de digitação
   na planilha e cole de novo. **O botão de confirmar só é liberado quando
   não sobra erro nenhum** — isso é de propósito: é melhor a tela recusar e
   te pedir pra olhar de novo do que aceitar um valor errado.
7. Quando a validação vier limpa, clique em **"Confirmar importação"**.
   Pronto — a calculadora já passa a usar os valores novos na hora, pra
   todo mundo que abrir o site, sem precisar de mim nem de nenhum deploy.
8. Se precisar corrigir algum valor depois (reparou que digitou errado),
   repita o processo colando de novo só as linhas certas com o valor
   corrigido — a importação sempre sobrescreve a combinação daquele ano
   específico, nunca duplica.

Duas coisas importantes pra não dar problema:

- **Cole sempre direto do Excel** (Ctrl+C nas células, Ctrl+V na caixa de
  texto) — isso já separa as colunas com TAB automaticamente, o que evita
  qualquer confusão entre a vírgula do separador de coluna e a vírgula
  decimal brasileira (R$ 7.301,95). A tela também aceita colar separado por
  vírgula, mas tab é sempre mais seguro.
- **A combinação de cargo/carga horária/nível/grau tem que já existir na
  tabela atual.** A tela recusa qualquer linha com uma combinação
  desconhecida (pra pegar erro de digitação antes de salvar) — ela não
  serve pra cadastrar um cargo/grau novo que nunca existiu. Se isso for
  realmente necessário um dia, me avise que a gente vê como fazer.

**Faixas de contribuição (INSS/RPPS) e IPSEMG:** na mesma seção
"Parâmetros do ano", mais abaixo, tem uma tabelinha com as 11 faixas (7 do
RPPS, 4 do INSS) e os 3 valores do IPSEMG, cada um com uma caixinha
editável. Diferente do vencimento, esses valores **não mudam toda
vigência** — só edite quando o Everton confirmar uma faixa nova de verdade.
Preencha os campos e clique em "Salvar alterações"; o campo "Máximo"
pode ficar vazio na última faixa de cada tabela (significa "sem limite
superior").

## Aba Ferramentas (catálogo + acesso por setor)

Em vez de cada ferramenta interna (Calculadora de Pagamento, Leitor do
Diário, e qualquer outra que entrar no futuro) ser um "sistema" dentro de
um grupo/setor específico, elas vivem num catálogo fixo (`FERRAMENTAS_CATALOGO`
em `js/app.js`) acessível por um botão "Ferramentas" no cabeçalho, ao lado
do menu ☰ — em qualquer tela do site, não só dentro de um setor.

**Quem vê o quê:**
- **Coordenador/servidor** (e diretor "dentro" de um setor): veem só as
  ferramentas que o diretor liberou pro próprio setor, como cards
  clicáveis que abrem a ferramenta de verdade.
- **Diretor no Painel de Setores** (nenhum setor aberto): vê o modo de
  gerenciar — pra cada ferramenta do catálogo, uma lista de checkboxes
  (um por setor) pra conceder/revogar o acesso, mais quantas pessoas isso
  libera (coordenador + servidores daquele setor) e um link "ver quem"
  com os nomes.

Um mesmo setor pode ter acesso a várias ferramentas ao mesmo tempo, e uma
mesma ferramenta pode ser liberada pra vários setores — diferente do
modelo antigo (1 sistema = 1 dono), isso deixa o diretor compor o acesso
setor por setor conforme o fluxo de trabalho de cada um.

**Banco de dados:** tabela `ferramenta_acessos` (migração
`20261014000000_ferramentas_catalogo.sql`), chave composta
(ferramenta_id, setor_id), com RLS: qualquer um vê se o próprio setor tem
acesso (ou o diretor vê tudo), só o diretor concede/revoga. Essa mesma
migração converteu o modelo antigo pro novo automaticamente — qualquer
sistema que já existisse com `internal_tool` preenchido virou uma
concessão de acesso pro setor que já tinha aquele card, e o sistema em si
foi apagado (não sobra card duplicado em nenhum grupo).

**Limitação conhecida:** a concessão de acesso (`ferramenta_acessos`) é
sobre a aba de navegação — ela decide o que aparece pra cada setor e
bloqueia a UI de abrir uma ferramenta não concedida. A escrita de dados
de cada ferramenta continua com sua própria RLS (ex: SICALC agora checa
diretamente `ferramenta_acessos` pra decidir quem pode editar os
parâmetros do ano; o Leitor do Diário continua isolando os registros por
setor, igual antes). Se uma ferramenta futura não checar
`ferramenta_acessos` na própria RLS, a concessão vira só uma conveniência
de navegação pra ela, não uma trava de segurança — vale a pena revisar
isso ao adicionar algo novo ao catálogo.

## Ferramenta: Leitor do Diário

Ferramenta interna (igual a Calculadora de Pagamento) que lê PDF(s) do
**Diário do Executivo de Minas Gerais** e extrai os atos de pessoal da
**SRE Metropolitana A** — descarta deliberadamente conteúdo de outras SREs
(é por desenho, não limitação). Cada servidor encontrado vem com uma nota
de confiança ("alta" ou "revisar") e, quando precisa de revisão, o motivo
exato, nunca um aviso genérico.

**Como abrir:** pela aba "Ferramentas" no cabeçalho do site (ver seção
própria abaixo) — não é mais um sistema dentro de um grupo/setor.

**De onde veio:** a lógica de extração/validação (`js/leitor-diario/`,
compilada a partir de um pacote TypeScript enviado pelo usuário, com 96
testes automatizados verificados antes da conversão) **não foi alterada**
— só convertida de TypeScript pra JavaScript puro (o site não tem bundler
nem build step; a conversão usa só `tsc` pra tirar os tipos, sem tocar em
nenhuma regra de negócio). Quem for mexer nessa lógica deve ler primeiro
`js/leitor-diario/leitor-diario-mg-README.md` (o README original do
pacote) — ele documenta os princípios de confiabilidade (nunca inventar
dado, nunca deixar um servidor sumir em silêncio) que qualquer mudança
futura precisa preservar.

**Dependências externas (só dessa ferramenta):** como ela precisa ler PDF
e, quando necessário, fazer OCR, carrega duas bibliotecas por CDN (via
`<script type="importmap">` no `<head>` do `index.html`, que é como o
navegador resolve `import ... from "pdfjs-dist"` sem precisar de bundler):
[pdf.js](https://mozilla.github.io/pdf.js/) (extração nativa de texto do
PDF) e [Tesseract.js](https://tesseract.projectnaptha.com/) (OCR local, só
roda quando o PDF não tem texto nativo bom — por exemplo, digitalizado por
foto). Nenhuma chave de API é necessária. Se trocar a versão de alguma das
duas, atualize os dois lugares: a URL no import map E a URL do worker do
pdf.js em `js/leitor-diario-view.js` (os dois têm que ser exatamente a
mesma versão).

**Testado com Diário real:** além do PDF sintético inicial, a integração foi
validada com Diários do Executivo de verdade (edição de 2026-10-01) —
40 servidores extraídos em segundos, sem erro de console. Os 96 testes
automatizados do pacote original (que cobrem a lógica de verdade, com
exemplos reais) continuam passando — ver
`js/leitor-diario/leitor-diario-mg-README.md` pra rodá-los de novo se a
lógica for alterada no futuro.

**O que fica salvo:** cada "Processar arquivos" grava os registros
extraídos no banco (tabela `leitor_diario_registros`, com RLS igual à de
`groups`: cada setor só vê/edita o próprio, diretor vê todos), então os
resultados sobrevivem a sair/voltar e ficam visíveis pra qualquer um do
mesmo setor, não só quem processou. Quem pode editar (coordenador/diretor)
também pode:
- **Filtrar antes de processar** — checkboxes por tipo de ato (licença,
  afastamento, designação etc.), todos marcados por padrão, com "Marcar
  todos"/"Desmarcar todos".
- **Editar/excluir cada registro** — ícones de lápis/lixeira na tabela,
  com confirmação antes de excluir.
- **Limpar dados do fluxo atual** — apaga só o último lote processado
  (clique em "Processar arquivos"), sem tocar em lotes anteriores já
  revisados.
- **Limpar TODOS os dados do painel** — apaga tudo que já foi salvo
  nesse setor (com confirmação, não dá pra desfazer).
- **Exportar CSV** — baixa a tabela atual (com acentos corretos em
  Excel) pra quem quiser levar os dados pra outro lugar.

Quem só visualiza (servidor) vê a mesma tabela, sem upload nem botões de
editar/excluir.

**Fora de escopo (por desenho):** a geração de documentos Word (CTC,
Lauda, Confirmação) do programa original **não foi portada** — o código
dessa parte não veio no pacote enviado. Esta ferramenta cobre só a etapa
de leitura/extração/revisão dos atos do Diário.

## Como publicar (GitHub Pages ou Render)

**GitHub Pages**: em Settings → Pages do repositório, escolha "Deploy from a
branch", selecione `main` e a pasta `/ (root)`.

**Render**: New → Static Site, aponte para este repositório, branch `main`,
sem build command, publish directory `.`.

## Origem dos dados de fábrica

Os 33 sistemas e seus links (seed em `supabase/migrations/`) foram extraídos da planilha
original (`DESKTOP WEB - Visual 1.xlsx`), mantendo os mesmos destinos. Os 8
grupos correspondem às 8 colunas de botões da planilha original — os nomes
dados a cada grupo (ex: "Principais", "Frequência e Pagamentos") são só um
ponto de partida; renomeie como preferir pelo site. Três sistemas não tinham
link cadastrado na planilha original (SISAP WEB, CARGOS APOSENTADOS -
APOSENTADORIA/MIGRACAO e ACOMPANHAMENTO JUDICIAL) e por isso aparecem sem
link ("Sem link") até alguém adicionar um documento a eles.
