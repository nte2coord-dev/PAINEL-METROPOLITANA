// Migra uma conta antiga (criada antes da autenticação de verdade, com
// senha guardada em texto puro na coluna "accounts.password") pro Auth
// real do Supabase, no primeiro login dela depois dessa mudança — sem
// precisar de nenhum passo manual, nem trocar de senha. A pessoa digita
// usuário/e-mail e senha exatamente como sempre fez; se a conta ainda não
// migrou, o site chama essa função em vez de ir direto no Auth.
//
// Depois que TODAS as contas tiverem passado por aqui uma vez (ou seja,
// accounts.auth_user_id preenchido em todo mundo), a coluna "password"
// pode ser apagada numa migração futura — ela só existe até então pra
// essa função conseguir confirmar a senha de quem ainda não migrou.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// Cabeçalhos CORS embutidos aqui (em vez de importados de um arquivo
// compartilhado): o painel do Supabase publica cada função a partir de
// um único arquivo colado, então uma segunda função só existe se ela
// também for criada manualmente do outro lado — mais simples e mais
// confiável duplicar essas poucas linhas nas duas funções.
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return jsonResponse({ error: "method_not_allowed" }, 405);

  let body: { login?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: "invalid_json" }, 400);
  }
  const login = (body.login || "").trim();
  const password = body.password || "";
  if (!login || !password) return jsonResponse({ error: "missing_fields" }, 400);

  const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

  // Mesma lógica de "o que essa pessoa digitou corresponde a qual conta"
  // usada no login normal (resolve_login_email) — assim as duas trilhas
  // (migrada e não migrada) nunca divergem sobre quem é quem.
  const { data: authEmail } = await admin.rpc("resolve_login_email", { p_login: login });
  const { data: account, error: findError } = authEmail
    ? await admin.from("accounts").select("*").eq("auth_email", authEmail).is("auth_user_id", null).maybeSingle()
    : { data: null, error: null };

  if (findError) return jsonResponse({ error: "lookup_failed" }, 500);
  // Conta não existe (ou já migrou — nesse caso o site nem deveria ter
  // chamado essa função) ou a senha antiga não confere: mesma mensagem
  // genérica dos dois casos, pra não revelar qual deles é o certo.
  if (!account || account.password !== password) {
    return jsonResponse({ error: "invalid_credentials" }, 401);
  }

  let userId: string;
  const { data: created, error: createError } = await admin.auth.admin.createUser({
    email: account.auth_email,
    password,
    email_confirm: true,
  });
  if (created?.user) {
    userId = created.user.id;
  } else {
    // Já existe um usuário no Auth com esse e-mail sem estar ligado a
    // essa conta — sinal de que uma migração anterior criou o usuário
    // mas falhou num passo depois disso (queda de rede, etc.), antes de
    // terminar. Em vez de travar pra sempre, reaproveita esse usuário:
    // atualiza a senha dele pra que acabou de digitar (já confirmada
    // acima) e liga em accounts, completando a migração que ficou pela
    // metade.
    if (!/already.*(registered|exists)/i.test(createError?.message || "")) {
      return jsonResponse({ error: "auth_create_failed", detail: createError?.message }, 500);
    }
    const { data: list, error: listError } = await admin.auth.admin.listUsers({ perPage: 1000 });
    const existing = list?.users?.find((u) => (u.email || "").toLowerCase() === account.auth_email.toLowerCase());
    if (listError || !existing) {
      return jsonResponse({ error: "auth_create_failed", detail: createError?.message }, 500);
    }
    const { error: updateError } = await admin.auth.admin.updateUserById(existing.id, { password, email_confirm: true });
    if (updateError) return jsonResponse({ error: "auth_create_failed", detail: updateError.message }, 500);
    userId = existing.id;
  }

  // Zera a senha antiga em texto puro junto com a migração — depois
  // disso ela não serve mais pra nada (o Auth já tem a própria, com
  // hash), então não faz sentido continuar guardando esse valor.
  const { error: linkError } = await admin
    .from("accounts")
    .update({ auth_user_id: userId, password: null })
    .eq("id", account.id);
  if (linkError) return jsonResponse({ error: "link_failed" }, 500);

  const anon = createClient(SUPABASE_URL, ANON_KEY);
  const { data: signIn, error: signInError } = await anon.auth.signInWithPassword({
    email: account.auth_email,
    password,
  });
  if (signInError || !signIn.session) {
    return jsonResponse({ error: "sign_in_failed", detail: signInError?.message }, 500);
  }

  return jsonResponse({ session: signIn.session });
});
