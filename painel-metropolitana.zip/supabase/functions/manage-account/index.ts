// Cria, remove ou troca o papel (coordenador/servidor) de uma conta. Fica
// numa Edge Function (em vez de uma função no banco) porque criar/remover
// um usuário de verdade no Auth do Supabase exige a chave secreta
// (service_role) — essa chave nunca pode ir pro navegador, então esse é
// o único lugar onde ela existe. set_role em si não toca no Auth (só na
// coluna "role"), mas fica junto por reaproveitar o mesmo canManage() e a
// mesma resolução de quem está chamando.
//
// Quem pode chamar: só verificamos isso aqui dentro (lendo o token de
// quem chamou e o papel/setor dessa conta) — diretor pode criar ou
// remover em qualquer setor; coordenador só no próprio setor; servidor
// não pode nenhuma das duas coisas. Substitui approve_access_request,
// create_servidor e delete_account, que faziam isso sem checar quem
// estava chamando.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// Cabeçalhos CORS embutidos aqui (em vez de importados de um arquivo
// compartilhado): o painel do Supabase publica cada função a partir de
// um único arquivo colado, então uma segunda função só existe se ela
// também for criada manualmente do outro lado — mais simples e mais
// confiável duplicar essas poucas linhas nas duas funções.
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const EMAIL_DOMAIN_RE = /@educacao\.mg\.gov\.br$/i;

function uid(prefix: string): string {
  return prefix + "-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

async function callerAccount(admin: ReturnType<typeof createClient>, authHeader: string | null) {
  if (!authHeader) return null;
  const jwt = authHeader.replace(/^Bearer\s+/i, "");
  const { data: userData, error: userError } = await admin.auth.getUser(jwt);
  if (userError || !userData?.user) return null;
  const { data: account } = await admin.from("accounts").select("*").eq("auth_user_id", userData.user.id).maybeSingle();
  return account || null;
}

function canManage(caller: { role: string; setor_id: string | null } | null, targetSetorId: string | null): boolean {
  if (!caller) return false;
  if (caller.role === "diretor") return true;
  return caller.role === "admin" && caller.setor_id === targetSetorId;
}

function isDiretorLike(caller: { role: string } | null): boolean {
  return !!caller && caller.role === "diretor";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return jsonResponse({ error: "method_not_allowed" }, 405);

  const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
  const caller = await callerAccount(admin, req.headers.get("Authorization"));

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: "invalid_json" }, 400);
  }

  if (body.action === "create") {
    const setorId = (body.setor_id as string) || null;
    if (!canManage(caller, setorId)) return jsonResponse({ error: "forbidden" }, 403);

    const email = String(body.email || "").trim().toLowerCase();
    const role = String(body.role || "");
    if (!email || (role !== "admin" && role !== "viewer")) {
      return jsonResponse({ error: "missing_fields" }, 400);
    }

    // Se vier de um pedido de auto-cadastro (ver ação "register"), o
    // usuário no Auth já existe, com a senha que a própria pessoa
    // escolheu — só falta ligar ele numa conta de verdade, sem criar de
    // novo (isso falharia com "already registered").
    let requestRow: { auth_user_id: string | null } | null = null;
    if (body.request_id) {
      const { data } = await admin
        .from("solicitacoes_acesso")
        .select("auth_user_id")
        .eq("id", body.request_id as string)
        .maybeSingle();
      requestRow = data;
    }

    let authUserId: string;
    if (requestRow?.auth_user_id) {
      authUserId = requestRow.auth_user_id;
    } else {
      const password = String(body.password || "");
      if (!password) return jsonResponse({ error: "missing_fields" }, 400);
      const { data: created, error: createError } = await admin.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
      });
      if (createError || !created?.user) {
        return jsonResponse({ error: "auth_create_failed", detail: createError?.message }, 400);
      }
      authUserId = created.user.id;
    }

    const newId = uid("acc");
    const { data: inserted, error: insertError } = await admin
      .from("accounts")
      .insert({
        id: newId,
        role,
        name: String(body.name || "").trim(),
        masp: String(body.masp || "").trim(),
        telefone: String(body.telefone || "").trim(),
        cargo: String(body.cargo || "").trim(),
        email,
        auth_email: email,
        setor_id: setorId,
        auth_user_id: authUserId,
      })
      .select()
      .single();
    if (insertError) {
      await admin.auth.admin.deleteUser(authUserId);
      return jsonResponse({ error: "insert_failed", detail: insertError.message }, 400);
    }

    if (body.request_id) {
      await admin.from("solicitacoes_acesso").delete().eq("id", body.request_id as string);
    }
    return jsonResponse({ account: inserted });
  }

  // Auto-cadastro: a própria pessoa preenche os dados e escolhe a própria
  // senha na tela de login (sem estar logada — daí "caller" não importa
  // aqui). Cria o usuário no Auth já com essa senha e guarda um pedido em
  // "solicitacoes_acesso" ligado a ele; o diretor só confere e aprova
  // (ação "create" acima, que reaproveita esse usuário em vez de criar de
  // novo) — a senha nunca fica em texto puro em lugar nenhum.
  if (body.action === "register") {
    const email = String(body.email || "").trim().toLowerCase();
    const name = String(body.name || "").trim();
    const setorId = (body.setor_id as string) || null;
    const password = String(body.password || "");
    if (!email || !EMAIL_DOMAIN_RE.test(email) || !name || !setorId || !password) {
      return jsonResponse({ error: "missing_fields" }, 400);
    }

    const { data: existingAccount } = await admin.from("accounts").select("id").eq("email", email).maybeSingle();
    if (existingAccount) return jsonResponse({ error: "email_taken" }, 400);
    const { data: existingRequest } = await admin.from("solicitacoes_acesso").select("id").eq("email", email).maybeSingle();
    if (existingRequest) return jsonResponse({ error: "request_pending" }, 400);

    const { data: created, error: createError } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    });
    if (createError || !created?.user) {
      return jsonResponse({ error: "auth_create_failed", detail: createError?.message }, 400);
    }

    const { error: insertError } = await admin.from("solicitacoes_acesso").insert({
      id: uid("req"),
      email,
      name,
      masp: String(body.masp || "").trim(),
      telefone: String(body.telefone || "").trim(),
      cargo: String(body.cargo || "").trim(),
      setor_id: setorId,
      auth_user_id: created.user.id,
    });
    if (insertError) {
      await admin.auth.admin.deleteUser(created.user.id);
      return jsonResponse({ error: "insert_failed", detail: insertError.message }, 400);
    }
    return jsonResponse({ ok: true });
  }

  // Recusar um pedido: se veio de auto-cadastro, apaga o usuário órfão no
  // Auth (o pedido some sozinho, é "on delete cascade" — assim o e-mail
  // fica livre pra pessoa tentar de novo); se for um pedido do formato
  // antigo (só e-mail, sem usuário no Auth), apaga o pedido direto.
  if (body.action === "reject_request") {
    if (!isDiretorLike(caller)) return jsonResponse({ error: "forbidden" }, 403);
    const requestId = String(body.request_id || "");
    const { data: request } = await admin.from("solicitacoes_acesso").select("*").eq("id", requestId).maybeSingle();
    if (!request) return jsonResponse({ error: "not_found" }, 404);

    if (request.auth_user_id) {
      const { error: deleteError } = await admin.auth.admin.deleteUser(request.auth_user_id);
      if (deleteError) return jsonResponse({ error: "delete_failed", detail: deleteError.message }, 400);
    } else {
      await admin.from("solicitacoes_acesso").delete().eq("id", requestId);
    }
    return jsonResponse({ ok: true });
  }

  // Tela "Gerenciar acessos": promove servidor -> coordenador ou revoga
  // coordenador -> servidor. Mesma permissão de "delete" (diretor em
  // qualquer setor, coordenador só no próprio) — novidade aqui é que o
  // coordenador passa a poder mudar o papel de alguém do próprio setor,
  // não só criar/remover. Nunca toca em diretor: isso continua sendo só
  // um passo manual no SQL, de propósito (ver README).
  if (body.action === "set_role") {
    const newRole = String(body.role || "");
    if (newRole !== "admin" && newRole !== "viewer") {
      return jsonResponse({ error: "invalid_role" }, 400);
    }
    const targetId = String(body.account_id || "");
    const { data: target } = await admin.from("accounts").select("*").eq("id", targetId).maybeSingle();
    if (!target) return jsonResponse({ error: "not_found" }, 404);
    if (target.role !== "admin" && target.role !== "viewer") {
      return jsonResponse({ error: "forbidden" }, 403);
    }
    if (!canManage(caller, target.setor_id)) return jsonResponse({ error: "forbidden" }, 403);

    const { data: updated, error: updateError } = await admin
      .from("accounts")
      .update({ role: newRole })
      .eq("id", targetId)
      .select()
      .single();
    if (updateError) return jsonResponse({ error: "update_failed", detail: updateError.message }, 400);
    return jsonResponse({ account: updated });
  }

  if (body.action === "delete") {
    const targetId = String(body.account_id || "");
    const { data: target } = await admin.from("accounts").select("*").eq("id", targetId).maybeSingle();
    if (!target) return jsonResponse({ error: "not_found" }, 404);
    if (!canManage(caller, target.setor_id)) return jsonResponse({ error: "forbidden" }, 403);

    if (target.auth_user_id) {
      // apaga o usuário do Auth — a linha em "accounts" some sozinha
      // (on delete cascade), não precisa de um segundo passo.
      const { error: deleteError } = await admin.auth.admin.deleteUser(target.auth_user_id);
      if (deleteError) return jsonResponse({ error: "delete_failed", detail: deleteError.message }, 400);
    } else {
      await admin.from("accounts").delete().eq("id", targetId);
    }
    return jsonResponse({ ok: true });
  }

  return jsonResponse({ error: "unknown_action" }, 400);
});
