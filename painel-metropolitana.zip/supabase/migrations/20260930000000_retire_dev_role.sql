-- Aposenta o papel "dev" (acesso temporário usado só durante o
-- desenvolvimento do site, ver conta "dev-davi" na migração inicial):
-- remove essa conta de vez e tira "dev" da definição de
-- is_diretor_like() — a partir de agora só "diretor" tem esse poder
-- (hoje, na prática, davi.zicker e o Kelson). Idempotente como as
-- outras migrações: roda sem erro mesmo se já tiver sido aplicada.

-- Remove a conta "dev" por completo. Se ela já migrou pro Auth de
-- verdade (auth_user_id preenchido, porque alguém logou com ela depois
-- da autenticação real entrar em vigor), apaga pelo auth.users — a linha
-- em "accounts" some sozinha (on delete cascade, ver
-- 20260929010000_add_auth_columns.sql). Se nunca migrou, o delete em
-- auth.users não acha nada e o delete direto em "accounts" abaixo cobre
-- esse caso.
delete from auth.users
where id = (select auth_user_id from accounts where id = 'dev-davi' and auth_user_id is not null);
delete from accounts where id = 'dev-davi';

-- is_diretor_like() sem "dev": nenhuma conta pode mais ter esse papel
-- (a Edge Function "manage-account" nunca aceitou criar uma com esse
-- papel, e a única que existia de fábrica acabou de ser apagada acima)
-- — manter o "or role = 'dev'" aqui seria uma porta aberta sem motivo
-- pra qualquer linha que um dia ganhasse esse valor por engano.
create or replace function is_diretor_like()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce((select role from accounts where auth_user_id = auth.uid()) = 'diretor', false);
$$;
