-- Auto-cadastro: em vez do diretor digitar nome/MASP/telefone/cargo/setor
-- à mão pra cada pedido de acesso, a própria pessoa preenche tudo (e já
-- escolhe a própria senha) na tela de login — "Ainda não tem conta?
-- Cadastre-se". O diretor só confere e aprova. Ver README e a Edge
-- Function "manage-account" (ações "register" e "reject_request").

alter table solicitacoes_acesso add column if not exists name text;
alter table solicitacoes_acesso add column if not exists masp text;
alter table solicitacoes_acesso add column if not exists telefone text;
alter table solicitacoes_acesso add column if not exists cargo text;
alter table solicitacoes_acesso add column if not exists setor_id text references setores(id) on delete cascade;

-- Liga o pedido ao usuário já criado no Auth no momento do auto-cadastro
-- (com a senha que a própria pessoa escolheu) — aprovar o pedido não cria
-- um usuário novo, só liga esse aqui numa conta de verdade. Fica nulo nos
-- pedidos antigos (só e-mail, de antes dessa mudança) e nos que o diretor
-- ainda cadastra à mão sem passar por auto-cadastro.
alter table solicitacoes_acesso add column if not exists auth_user_id uuid unique references auth.users(id) on delete cascade;

-- Setor precisa ser legível por quem ainda nem tem conta (o formulário de
-- auto-cadastro mostra a lista de setores pra pessoa escolher o próprio) —
-- nada sensível nessa tabela (só nome/cor/ícone), então liberar select
-- geral é seguro; escrever continua só com diretor/dev (setores_write).
drop policy if exists setores_select on setores;
create policy setores_select on setores for select using (true);
