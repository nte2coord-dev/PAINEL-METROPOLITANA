-- Leitor do Diário: guarda os registros já extraídos (um por servidor),
-- pra sobreviver a sair/voltar e pra mais de uma pessoa do mesmo setor ver
-- o mesmo lote processado. "setor_id" é de qual setor processou — igual
-- groups/systems, cada setor só vê/edita o próprio; diretor vê todos.
-- "lote_id" agrupa os registros de um mesmo clique em "Processar
-- arquivos" (usado pelo botão "Limpar dados do fluxo atual", que some só
-- com o lote mais recente, sem mexer em lotes antigos já revisados).
create table if not exists leitor_diario_registros (
  id bigint generated always as identity primary key,
  setor_id text not null references setores(id) on delete cascade,
  lote_id text not null,
  nome_servidor text,
  masp text,
  cargo text,
  admissao text,
  municipio text,
  localidade_escola text,
  tipo_ato text,
  tipo_label text,
  numero_ato text,
  confianca text,
  problemas_validacao jsonb not null default '[]'::jsonb,
  fonte_arquivo text,
  fonte_pagina integer,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
create index if not exists leitor_diario_registros_setor_idx on leitor_diario_registros (setor_id);
create index if not exists leitor_diario_registros_lote_idx on leitor_diario_registros (lote_id);

alter table leitor_diario_registros enable row level security;

-- Leitura: qualquer um do próprio setor (servidor incluso, só visualiza)
-- ou diretor/dev, igual groups_select.
drop policy if exists leitor_diario_registros_select on leitor_diario_registros;
create policy leitor_diario_registros_select on leitor_diario_registros for select using (
  is_diretor_like() or setor_id = my_setor_id()
);

-- Escrita (processar, editar, excluir): coordenador do próprio setor ou
-- diretor/dev, igual groups_write.
drop policy if exists leitor_diario_registros_write on leitor_diario_registros;
create policy leitor_diario_registros_write on leitor_diario_registros for all using (
  is_diretor_like() or (my_role() = 'admin' and setor_id = my_setor_id())
) with check (
  is_diretor_like() or (my_role() = 'admin' and setor_id = my_setor_id())
);
