-- Migração "inicial" do Portal SRE Metropolitana A no Supabase.
--
-- Isso não é o schema "do zero": é a cópia exata do supabase/schema.sql
-- que, até essa data, vínhamos colando manualmente no SQL Editor a cada
-- rodada de mudanças — reunido aqui como a primeira migração pra dar
-- lugar ao deploy automático via integração do Supabase com o GitHub
-- (ver README). Continua idempotente de propósito ("if not exists",
-- "on conflict do nothing", "drop function if exists" antes de recriar):
-- roda sem erro tanto num banco novo em folha quanto no banco de produção
-- já em uso, sem duplicar nem sobrescrever dados. A partir de agora,
-- toda mudança nova entra como um arquivo de migração novo (não editamos
-- mais este arquivo).

create table if not exists setores (
  id text primary key,
  nome text not null,
  color text not null default 'blue',
  icon_image text,
  "order" integer not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists groups (
  id text primary key,
  name text not null,
  color text not null default 'blue',
  icon_image text,
  "order" integer not null default 0,
  updated_at timestamptz not null default now()
);
alter table groups add column if not exists setor_id text references setores(id) on delete cascade;

create table if not exists systems (
  id text primary key,
  name text not null,
  tag text not null default '??',
  color text not null default 'blue',
  icon_image text,
  group_id text references groups(id) on delete cascade,
  documents jsonb not null default '[]'::jsonb,
  internal_tool text,
  updated_at timestamptz not null default now()
);

-- "accounts" guarda usuario/senha de todos os acessos (diretor, coordenador
-- e visualizador de cada setor). Ninguem le essa tabela diretamente (nem
-- com a chave anon) — só as funções abaixo tocam nela, e nenhuma delas
-- devolve a senha de volta pro navegador. setor_id = null é o diretor
-- (acesso a todos os setores); os demais ficam presos a um setor só.
create table if not exists accounts (
  id text primary key,
  role text not null,
  name text not null,
  password text not null,
  updated_at timestamptz not null default now()
);
alter table accounts add column if not exists setor_id text references setores(id) on delete cascade;

-- email/masp/telefone/cargo: preenchidos só pra contas criadas pelo
-- cadastro de servidor (direto ou por solicitação de acesso — ver
-- "solicitacoes_acesso" abaixo). Contas antigas (diretor, admin, viewer)
-- continuam com email null e login pelo "usuario" de sempre — verify_login
-- aceita os dois formatos (ver função abaixo).
alter table accounts add column if not exists email text;
alter table accounts add column if not exists masp text;
alter table accounts add column if not exists telefone text;
alter table accounts add column if not exists cargo text;
alter table accounts drop column if exists cpf;
alter table accounts drop constraint if exists accounts_email_domain_check;
alter table accounts add constraint accounts_email_domain_check
  check (email is null or email ~* '@educacao\.mg\.gov\.br$');
create unique index if not exists accounts_email_unique on accounts (lower(email)) where email is not null;

-- Quando uma conta com e-mail ainda não verificou o próprio e-mail (nunca
-- fez login antes), verify_login avisa isso (needs_email_verification) e
-- o site pede um código de verificação enviado pro e-mail (via Auth OTP
-- do próprio Supabase, ver mark_email_verified abaixo) antes de liberar o
-- acesso — só na primeira vez; depois disso fica marcado pra sempre.
alter table accounts add column if not exists email_verified_at timestamptz;

-- Pedidos de acesso: qualquer um digita o próprio e-mail institucional na
-- tela de login (sem precisar estar logado) e o pedido cai aqui. Só o
-- diretor cadastra (nome, CPF, setor, papel e senha) e o pedido some,
-- virando uma conta de verdade em "accounts". Aberta pela mesma RLS de
-- setores/groups/systems — não guarda senha nem nada sensível, só o e-mail
-- pedido.
create table if not exists solicitacoes_acesso (
  id text primary key,
  email text not null check (email ~* '@educacao\.mg\.gov\.br$'),
  created_at timestamptz not null default now()
);
alter table solicitacoes_acesso enable row level security;
drop policy if exists "solicitacoes_acesso_all" on solicitacoes_acesso;
create policy "solicitacoes_acesso_all" on solicitacoes_acesso for all using (true) with check (true);

insert into accounts (id, role, name, password) values
  ('admin', 'admin', 'everton', '12345'),
  ('viewer', 'viewer', 'pagamento', '54321')
on conflict (id) do nothing;

-- Seed de grupos e sistemas (gerado a partir de js/data.js — o "estado de
-- fabrica" que ate agora so existia em localStorage). So preenche se a
-- linha ainda nao existir (on conflict do nothing), pra nao sobrescrever
-- o que o coordenador ja tiver editado.
insert into groups (id, name, color, "order") values
  ('grp-principais', 'Principais', 'blue', 0),
  ('grp-frequencia-e-pagamentos', 'Frequência e Pagamentos', 'teal', 1),
  ('grp-controles-e-processos', 'Controles e Processos', 'indigo', 2),
  ('grp-processos-e-saude', 'Processos e Saúde', 'green', 3),
  ('grp-relatorios-e-aposentadoria', 'Relatórios e Aposentadoria', 'amber', 4),
  ('grp-folgas-e-gestao', 'Folgas e Gestão', 'violet', 5),
  ('grp-anulacao-de-aposentadoria', 'Anulação de Aposentadoria', 'slate', 6),
  ('grp-cessao-e-servidores', 'Cessão e Servidores', 'pink', 7),
  ('grp-ferramentas', 'Ferramentas', 'orange', 8)
on conflict (id) do nothing;

insert into systems (id, name, tag, color, group_id, documents, internal_tool) values
  ('sys-biblioteca', 'BIBLIOTECA', 'BI', 'blue', 'grp-principais', '[{"id":"sys-biblioteca-doc1","label":"Acessar","url":"https://drive.google.com/drive/folders/1N8ocNm5iPlabYN-x-P86Od0xubNSL4W-"}]'::jsonb, NULL),
  ('sys-ponto-digital', 'PONTO DIGITAL', 'PD', 'blue', 'grp-principais', '[{"id":"sys-ponto-digital-doc1","label":"Acessar","url":"https://www.pontodigital.mg.gov.br/Publica"}]'::jsonb, NULL),
  ('sys-sei', 'SEI', 'SEI', 'blue', 'grp-principais', '[{"id":"sys-sei-doc1","label":"Acessar","url":"https://www.sei.mg.gov.br/sip/login.php?sigla_orgao_sistema=GOVMG&sigla_sistema=SEI"}]'::jsonb, NULL),
  ('sys-conecta-rh', 'CONECTA RH', 'RH', 'blue', 'grp-principais', '[{"id":"sys-conecta-rh-doc1","label":"Acessar","url":"https://www.conectarh.mg.gov.br/"}]'::jsonb, NULL),
  ('sys-calculo-de-provento-media', 'CÁLCULO DE PROVENTO/MÉDIA', 'CP', 'blue', 'grp-principais', '[{"id":"sys-calculo-de-provento-media-doc1","label":"Acessar","url":"https://wwws.seplag.mg.gov.br/index.php"}]'::jsonb, NULL),
  ('sys-sisap-web-fipa', 'SISAP WEB FIPA', 'SF', 'blue', 'grp-principais', '[{"id":"sys-sisap-web-fipa-doc1","label":"Acessar","url":"http://www.sisapweb.mg.gov.br/fipa/telaacesso.htm"}]'::jsonb, NULL),
  ('sys-guias-de-ocorrencia', 'GUIAS DE OCORRÊNCIA', 'GO', 'teal', 'grp-frequencia-e-pagamentos', '[{"id":"sys-guias-de-ocorrencia-doc1","label":"Acessar","url":"https://drive.google.com/drive/folders/1-y5s41bdxTTlMkIcZud68rMjKy_gpkks"}]'::jsonb, NULL),
  ('sys-contagem-de-tempo', 'CONTAGEM DE TEMPO', 'CT', 'teal', 'grp-frequencia-e-pagamentos', '[{"id":"sys-contagem-de-tempo-doc1","label":"Acessar","url":"https://drive.google.com/drive/folders/1x8goAn9bE9U1HpC4p8aOhEn4FhT74Kk3"}]'::jsonb, NULL),
  ('sys-liberacao-falta-tipo-2', 'LIBERAÇÃO FALTA - TIPO 2', 'LF', 'teal', 'grp-frequencia-e-pagamentos', '[{"id":"sys-liberacao-falta-tipo-2-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1yAZFJiAa0PWL1Bp6EL1-vGCLqeMfgR3ILrYsAi_Lbz0/edit?gid=794802376"}]'::jsonb, NULL),
  ('sys-vencimentos-deixados', 'VENCIMENTOS DEIXADOS', 'VD', 'teal', 'grp-frequencia-e-pagamentos', '[{"id":"sys-vencimentos-deixados-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1yjXFn_R6RTmeBLhHj3_H-KfrOhnSPAYEpDAehSf51gA/edit?gid=509616479"}]'::jsonb, NULL),
  ('sys-diario-de-pagamento', 'DIÁRIO DE PAGAMENTO', 'DP', 'teal', 'grp-frequencia-e-pagamentos', '[{"id":"sys-diario-de-pagamento-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1zF6K74HtCtxiZXFgcmG1uJ0NIHXG8pxo_lXu6BiUrAA/edit?gid=1739041770"}]'::jsonb, NULL),
  ('sys-acerto-11-36', 'ACERTO 11,36%', 'AC', 'teal', 'grp-frequencia-e-pagamentos', '[{"id":"sys-acerto-11-36-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1o4m5qEGUsQe76U_F-_h-MPzEEMpz99E0t3TLbaez-xE/edit?gid=438498586"}]'::jsonb, NULL),
  ('sys-controle-interno-de-ia', 'CONTROLE INTERNO DE IA', 'IA', 'indigo', 'grp-controles-e-processos', '[{"id":"sys-controle-interno-de-ia-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1pGCqPQxYQO2oGxA7gFjJGEGK4sbx6fj_U6H4G1eHSFo/edit?gid=489829030"}]'::jsonb, NULL),
  ('sys-correcao-i-a-s', 'CORREÇÃO I.A.s', 'CO', 'indigo', 'grp-controles-e-processos', '[{"id":"sys-correcao-i-a-s-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1uzBGJsOzBvRVEO25B4rkufXGB_LqEXtj/edit?pli=1&gid=797829345"}]'::jsonb, NULL),
  ('sys-informativo-de-alteracao-dipe', 'INFORMATIVO DE ALTERAÇÃO - DIPE', 'IA', 'indigo', 'grp-controles-e-processos', '[{"id":"sys-informativo-de-alteracao-dipe-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1TGKZsvx9c1T01PKZXw8gLtRpjuWH6JEiC1pA_lg_Y8U/edit?gid=685574746"}]'::jsonb, NULL),
  ('sys-arquivo-consolidado', 'ARQUIVO CONSOLIDADO', 'AC', 'indigo', 'grp-controles-e-processos', '[{"id":"sys-arquivo-consolidado-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/17k-YxtkMcH-spkk7UCvfrPEwl4Pv5304ayx8VO3c5-w/edit?gid=894487392"}]'::jsonb, NULL),
  ('sys-planilha-52-490', 'PLANILHA 52-490', 'PL', 'indigo', 'grp-controles-e-processos', '[{"id":"sys-planilha-52-490-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1DtaE6--J2SM7yCI3XoncNhONuearMEqAnzLUEEqR_II/edit?gid=50123981"}]'::jsonb, NULL),
  ('sys-processos-sei', 'PROCESSOS SEI', 'SEI', 'green', 'grp-processos-e-saude', '[{"id":"sys-processos-sei-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1ZEyldRZyVqgfzI01g-IBsmRkVoLzJ5Y246pFKCJyXwM/edit?gid=229512721"}]'::jsonb, NULL),
  ('sys-e-social', 'E - SOCIAL', 'ES', 'green', 'grp-processos-e-saude', '[{"id":"sys-e-social-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1ddK22DVM65rBHW-nnjvxOXOwhrkNzpKr/edit?pli=1&gid=1107740878"}]'::jsonb, NULL),
  ('sys-saude', 'SAÚDE', 'SA', 'green', 'grp-processos-e-saude', '[{"id":"sys-saude-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/19Ffq4yqFIac7rFp9roLQIR_uu78mEYIhgUl1PygXh34/edit?gid=1219913832"}]'::jsonb, NULL),
  ('sys-isencao-tributaria', 'ISENÇÃO TRIBUTÁRIA', 'IT', 'green', 'grp-processos-e-saude', '[{"id":"sys-isencao-tributaria-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1zQyNtFwmTNAAFEoac8d-5iBtFBUDf94R/edit?gid=1556910683"}]'::jsonb, NULL),
  ('sys-relatorio-acerto-manual-03-04-24', 'RELATÓRIO - Acerto Manual - 03/04/24', 'RA', 'amber', 'grp-relatorios-e-aposentadoria', '[{"id":"sys-relatorio-acerto-manual-03-04-24-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1SuK803uGdt5vCVInrkFKijcck7MVdzckUMRuEooTZuk/edit?gid=923097412"}]'::jsonb, NULL),
  ('sys-relatorio-acerto-13', 'RELATÓRIO - Acerto 13º', 'RA', 'amber', 'grp-relatorios-e-aposentadoria', '[{"id":"sys-relatorio-acerto-13-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1jZU6M7BWrDQkr1pU9bimrpAYI6qJUllr8DgSFlKUvt8/edit?gid=1384655041"}]'::jsonb, NULL),
  ('sys-cargos-aposentados-aposentadoria-migracao', 'CARGOS APOSENTADOS - APOSENTADORIA/MIGRACAO', 'CA', 'amber', 'grp-relatorios-e-aposentadoria', '[]'::jsonb, NULL),
  ('sys-folga-compensatoria', 'FOLGA COMPENSATÓRIA', 'FC', 'violet', 'grp-folgas-e-gestao', '[{"id":"sys-folga-compensatoria-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1WiVnmko5PA4amlUADRqhOG04BRRcSvqe2NOpEpesneo/edit?gid=1142259615"}]'::jsonb, NULL),
  ('sys-sisap-web', 'SISAP WEB', 'SW', 'violet', 'grp-folgas-e-gestao', '[]'::jsonb, NULL),
  ('sys-relacao-escolas-taxadores', 'RELAÇÃO ESCOLAS-TAXADORES', 'RE', 'violet', 'grp-folgas-e-gestao', '[{"id":"sys-relacao-escolas-taxadores-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1b9hA5_y9xGNwwNsrQiu9Y6FCP467XE_373r5zOmmJJc/edit?gid=1216202471"}]'::jsonb, NULL),
  ('sys-gestao', 'GESTÃO', 'GE', 'violet', 'grp-folgas-e-gestao', '[{"id":"sys-gestao-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1AedSH8xF-BWVOUR1-G438SZltnurBfEkeUoCsPP5udk/edit?gid=654263000"}]'::jsonb, NULL),
  ('sys-anul-apos-ec103-19', 'ANUL.APOS. EC103/19', 'EC', 'slate', 'grp-anulacao-de-aposentadoria', '[{"id":"sys-anul-apos-ec103-19-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1T-QW6m78HqlmSRCmi4pZ6KW0xpa7hYPg9I3_x1mfiWc/edit?gid=1045359958"}]'::jsonb, NULL),
  ('sys-cessao', 'CESSÃO', 'CE', 'pink', 'grp-cessao-e-servidores', '[{"id":"sys-cessao-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1RRJIiptPxUScQpbWtNXN53d8GbwvZAmNUDySy5SbPPQ/edit?gid=1649548333"}]'::jsonb, NULL),
  ('sys-servidores-cedidos', 'SERVIDORES CEDIDOS', 'SC', 'pink', 'grp-cessao-e-servidores', '[{"id":"sys-servidores-cedidos-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1m9axJiayx7K6FXHj1gfvl9J5Wjdi2a7Y3QLchVWPTzE/edit?gid=1740967758"}]'::jsonb, NULL),
  ('sys-acompanhamento-judicial', 'ACOMPANHAMENTO JUDICIAL', 'AJ', 'pink', 'grp-cessao-e-servidores', '[]'::jsonb, NULL),
  ('sys-controle-de-dae', 'CONTROLE DE DAE', 'DAE', 'pink', 'grp-cessao-e-servidores', '[{"id":"sys-controle-de-dae-doc1","label":"Acessar","url":"https://docs.google.com/spreadsheets/d/1XAL2T_pGkoFq_YRmAb0UDcnTH5Rf_jl-FHI97oaulwc/edit?gid=1852532253"}]'::jsonb, NULL),
  ('sys-sicalc-calc', 'Calculadora de Pagamento', 'SI', 'orange', 'grp-ferramentas', '[]'::jsonb, 'sicalc')
on conflict (id) do nothing;

-- Migração pro modelo de setores: cria o primeiro setor ("Setor de
-- Pagamento", que é tudo que já existia) e prende nele quem ainda não
-- tiver setor — nunca move quem já foi atribuído a outro setor depois.
insert into setores (id, nome, color, "order") values
  ('setor-pagamento', 'Setor de Pagamento', 'blue', 0)
on conflict (id) do nothing;

update groups set setor_id = 'setor-pagamento' where setor_id is null;
update accounts set setor_id = 'setor-pagamento' where id in ('admin', 'viewer') and setor_id is null;

-- Conta do diretor (acesso a todos os setores). Troque a senha assim que
-- possível pela tela de Configurações — essa é só a senha inicial.
insert into accounts (id, role, name, password, setor_id) values
  ('diretor', 'diretor', 'diretor', 'diretor123', null)
on conflict (id) do nothing;

-- Kelson passa a logar pelo e-mail institucional, mantendo a senha
-- inicial "diretor123" (ele troca depois, em Configurações). Só roda uma
-- vez — se o e-mail já tiver sido preenchido (ou trocado por ele), essa
-- linha não faz nada.
update accounts set email = 'sre.metropa.dipe@educacao.mg.gov.br'
  where id = 'diretor' and email is null;

-- Conta "dev" (acesso geral, igual ao diretor) só enquanto o site está em
-- desenvolvimento — login por usuário (não por e-mail, então nunca pede
-- verificação). Fica guardada do mesmo jeito que qualquer outra conta
-- (tabela "accounts" fechada, só as funções abaixo tocam nela) — não é
-- exposta em nenhum arquivo além deste. Apague essa conta (delete from
-- accounts where id = 'dev-davi') antes de considerar o site pronto pra
-- valer.
insert into accounts (id, role, name, password, setor_id) values
  ('dev-davi', 'dev', 'davi', '1234', null)
on conflict (id) do nothing;

alter table setores enable row level security;
alter table groups enable row level security;
alter table systems enable row level security;
alter table accounts enable row level security;

-- setores/groups/systems: qualquer um com a chave publica (anon) do
-- projeto pode ler e editar — é o mesmo nivel de proteção que existia
-- antes dos setores (o navegador decide quem pode ver o botão de editar),
-- só que agora em mais de um setor ao mesmo tempo.
drop policy if exists "setores_all" on setores;
create policy "setores_all" on setores for all using (true) with check (true);

drop policy if exists "groups_all" on groups;
create policy "groups_all" on groups for all using (true) with check (true);

drop policy if exists "systems_all" on systems;
create policy "systems_all" on systems for all using (true) with check (true);

-- accounts: nenhuma policy = ninguem consegue ler/editar essa tabela direto
-- pela API publica. So as functions "security definer" abaixo tocam nela.

-- Confere usuario+senha e devolve id/role/name/setor_id (nunca a senha).
-- setor_id vem null pro diretor (acesso a todos os setores). O "usuario"
-- digitado pode ser o nome de usuário de sempre (contas antigas) ou o
-- e-mail (contas criadas por solicitação de acesso) — compara com
-- coalesce(email, name), então cada conta só aceita um dos dois formatos,
-- nunca os dois. needs_email_verification: true só quando a conta tem
-- e-mail E ainda não verificou (primeiro login) — o site usa isso pra
-- decidir se pede o código antes de liberar.
-- "drop function" antes: a versão anterior devolvia menos colunas, e o
-- Postgres não deixa um "create or replace" mudar o tipo de retorno de
-- uma função que já existe — precisa apagar e recriar.
drop function if exists verify_login(text, text);
create or replace function verify_login(p_name text, p_password text)
returns table (id text, role text, name text, setor_id text, email text, needs_email_verification boolean)
language sql
security definer
set search_path = public
as $$
  select id, role, name, setor_id, email, (email is not null and email_verified_at is null)
  from accounts
  where lower(coalesce(email, name)) = lower(p_name) and password = p_password;
$$;

-- Troca nome/senha de uma conta (usada tanto pelo coordenador editando seu
-- proprio setor quanto pelo diretor editando qualquer conta, inclusive a
-- dele mesmo). Nao ha como restringir por usuario aqui porque o login e da
-- aplicação, nao do Supabase Auth — mesma proteção "client-side" de sempre.
drop function if exists update_account(text, text, text);
create or replace function update_account(p_id text, p_name text, p_password text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update accounts set
    name = coalesce(nullif(trim(p_name), ''), name),
    password = coalesce(nullif(p_password, ''), password),
    updated_at = now()
  where id = p_id;
end;
$$;

-- Nomes de todas as contas (sem senha) — usado pra pre-preencher a tela de
-- Configurações e a lista de servidores de cada setor, sem cachear senha
-- nenhuma no navegador. "drop function" pelo mesmo motivo do verify_login
-- acima.
drop function if exists get_account_names();
create or replace function get_account_names()
returns table (id text, role text, name text, setor_id text, email text, masp text, telefone text, cargo text)
language sql
security definer
set search_path = public
as $$
  select id, role, name, setor_id, email, masp, telefone, cargo from accounts order by id;
$$;

-- create_setor existiu numa versão anterior (criava o setor junto com um
-- coordenador/visualizador de senha escolhida na hora). Foi substituída
-- por approve_access_request, que é hoje o único jeito de criar essas
-- contas — o setor em si agora nasce vazio (insert direto na tabela
-- setores, sem função). Apagamos a função pra fechar esse caminho antigo:
-- enquanto ela existisse e continuasse liberada pra "anon", qualquer um
-- com a chave pública ainda conseguiria criar contas por fora da fila de
-- aprovação do diretor.
drop function if exists create_setor(text, text, text, text, text, text, text, text);

-- Aprova um pedido de acesso: cria a conta de verdade (com e-mail/senha
-- escolhidos pelo diretor) e apaga o pedido, os dois de uma vez. Só o
-- diretor tem esse botão na tela — protegido do mesmo jeito client-side
-- de sempre.
drop function if exists approve_access_request(text, text, text, text, text, text, text, text);
drop function if exists approve_access_request(text, text, text, text, text, text, text, text, text, text);
create or replace function approve_access_request(
  p_request_id text, p_account_id text, p_role text,
  p_name text, p_masp text, p_telefone text, p_cargo text,
  p_email text, p_setor_id text, p_password text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into accounts (id, role, name, password, email, masp, telefone, cargo, setor_id) values
    (p_account_id, p_role, p_name, p_password, p_email, p_masp, p_telefone, p_cargo, p_setor_id);
  delete from solicitacoes_acesso where id = p_request_id;
end;
$$;

-- Cadastro direto de servidor (coordenador ou servidor comum), sem
-- precisar de um pedido de acesso antes — o diretor (ou o coordenador, no
-- próprio setor) preenche tudo de uma vez na aba "Servidores" e já manda
-- usuário/senha inicial pra pessoa.
drop function if exists create_servidor(text, text, text, text, text, text, text, text, text);
create or replace function create_servidor(
  p_account_id text, p_role text, p_name text, p_masp text, p_telefone text, p_cargo text,
  p_email text, p_setor_id text, p_password text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into accounts (id, role, name, password, email, masp, telefone, cargo, setor_id) values
    (p_account_id, p_role, p_name, p_password, p_email, p_masp, p_telefone, p_cargo, p_setor_id);
end;
$$;

-- Remove uma conta (usado na lista de servidores, pra tirar alguém
-- cadastrado por engano ou que saiu do setor).
drop function if exists delete_account(text);
create or replace function delete_account(p_id text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  delete from accounts where id = p_id;
end;
$$;

-- Marca o e-mail de uma conta como verificado (depois que o código de
-- verificação, enviado via Auth OTP do Supabase, foi confirmado no
-- navegador). A partir daqui essa conta nunca mais pede o código de novo.
drop function if exists mark_email_verified(text);
create or replace function mark_email_verified(p_id text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update accounts set email_verified_at = now() where id = p_id;
end;
$$;

grant execute on function verify_login(text, text) to anon;
grant execute on function update_account(text, text, text) to anon;
grant execute on function get_account_names() to anon;
grant execute on function approve_access_request(text, text, text, text, text, text, text, text, text, text) to anon;
grant execute on function create_servidor(text, text, text, text, text, text, text, text, text) to anon;
grant execute on function delete_account(text) to anon;
grant execute on function mark_email_verified(text) to anon;
