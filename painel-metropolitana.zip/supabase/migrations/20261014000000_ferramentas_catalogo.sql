-- Aba "Ferramentas" global: em vez de cada ferramenta interna (Calculadora
-- de Pagamento, Leitor do Diário) ser um "sistema" dentro de um grupo/setor
-- específico, agora existe um catálogo fixo (definido no próprio código,
-- ver TOOL_MODULES em app.js) e o diretor concede acesso por setor — um
-- mesmo setor pode ter acesso a várias ferramentas, e uma mesma ferramenta
-- pode ser liberada pra vários setores ao mesmo tempo (o que o modelo
-- antigo, de 1 sistema = 1 dono, não permitia).
create table if not exists ferramenta_acessos (
  ferramenta_id text not null,
  setor_id text not null references setores(id) on delete cascade,
  concedido_em timestamptz not null default now(),
  primary key (ferramenta_id, setor_id)
);

alter table ferramenta_acessos enable row level security;

-- Leitura: o próprio setor vê se tem acesso (pra aparecer no menu
-- Ferramentas dele) ou diretor vê tudo (pra gerenciar).
drop policy if exists ferramenta_acessos_select on ferramenta_acessos;
create policy ferramenta_acessos_select on ferramenta_acessos for select using (
  is_diretor_like() or setor_id = my_setor_id()
);

-- Escrita (conceder/revogar acesso): só o diretor.
drop policy if exists ferramenta_acessos_write on ferramenta_acessos;
create policy ferramenta_acessos_write on ferramenta_acessos for all using (
  is_diretor_like()
) with check (
  is_diretor_like()
);

-- Migra o acesso que já existia implicitamente (o setor que tinha o
-- "sistema" da ferramenta dentro de um grupo) pra uma concessão explícita,
-- e então remove esses sistemas — a partir de agora o único jeito de abrir
-- essas ferramentas é pela aba Ferramentas, não mais um card dentro de um
-- grupo qualquer.
insert into ferramenta_acessos (ferramenta_id, setor_id)
select s.internal_tool, g.setor_id
from systems s
join groups g on g.id = s.group_id
where s.internal_tool is not null and g.setor_id is not null
on conflict (ferramenta_id, setor_id) do nothing;

delete from systems where internal_tool is not null;

-- A escrita do SICALC (sicalc_vencimentos/previd_faixas/ipsemg) dependia de
-- sicalc_setor_id(), que achava o setor "dono" procurando um systems com
-- internal_tool = 'sicalc' — essa linha acabou de ser apagada acima, então
-- a função teria que ser reescrita de qualquer jeito. Agora o acesso é
-- "qualquer setor com acesso concedido à ferramenta sicalc, igual
-- ferramenta_acessos" — um coordenador só edita os parâmetros se o próprio
-- setor tiver sido liberado pelo diretor pra essa ferramenta.
create or replace function sicalc_setor_tem_acesso()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from ferramenta_acessos
    where ferramenta_id = 'sicalc' and setor_id = my_setor_id()
  );
$$;

drop policy if exists sicalc_vencimentos_write on sicalc_vencimentos;
create policy sicalc_vencimentos_write on sicalc_vencimentos for all using (
  is_diretor_like() or (my_role() = 'admin' and sicalc_setor_tem_acesso())
) with check (
  is_diretor_like() or (my_role() = 'admin' and sicalc_setor_tem_acesso())
);

drop policy if exists sicalc_previd_faixas_write on sicalc_previd_faixas;
create policy sicalc_previd_faixas_write on sicalc_previd_faixas for all using (
  is_diretor_like() or (my_role() = 'admin' and sicalc_setor_tem_acesso())
) with check (
  is_diretor_like() or (my_role() = 'admin' and sicalc_setor_tem_acesso())
);

drop policy if exists sicalc_ipsemg_write on sicalc_ipsemg;
create policy sicalc_ipsemg_write on sicalc_ipsemg for all using (
  is_diretor_like() or (my_role() = 'admin' and sicalc_setor_tem_acesso())
) with check (
  is_diretor_like() or (my_role() = 'admin' and sicalc_setor_tem_acesso())
);

drop function if exists sicalc_setor_id();
