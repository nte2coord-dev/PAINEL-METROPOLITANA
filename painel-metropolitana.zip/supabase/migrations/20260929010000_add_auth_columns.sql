-- Passo 1 da migração pra autenticação de verdade (Supabase Auth) + RLS
-- por papel/setor. Ver README pra explicação completa do modelo novo.
--
-- Esse arquivo só ADICIONA colunas — não apaga "password" ainda (isso só
-- acontece numa migração posterior, depois que TODAS as contas já
-- tiverem migrado pro Auth de verdade; ver a Edge Function
-- "legacy-login", que faz essa migração sozinha, uma conta por vez, no
-- primeiro login de cada uma, usando a senha que a própria pessoa digitar
-- — ninguém precisa trocar de senha nem fazer nada manual).

-- auth_user_id: liga cada conta a um usuário real do Supabase Auth. Fica
-- nulo até a conta "migrar" (ver Edge Function legacy-login). Uma vez
-- preenchido, o login dessa conta passa a ser 100% via Auth de verdade.
alter table accounts add column if not exists auth_user_id uuid unique references auth.users(id) on delete cascade;

-- Conta nova (criada pela Edge Function "manage-account") nunca preenche
-- "password" — a senha mora só no Auth agora. A coluna precisa deixar de
-- ser obrigatória pra isso funcionar (continua existindo, só até todo
-- mundo migrar — ver comentário no topo do arquivo).
alter table accounts alter column password drop not null;

-- auth_email: o e-mail usado pra falar com o Auth do Supabase (que exige
-- formato de e-mail sempre). Pra quem já tem "email" institucional
-- (diretor, coordenador/servidor cadastrado por e-mail), é o mesmo valor.
-- Pra quem só tinha "usuário" (everton, pagamento, davi), é um e-mail
-- interno sintético — a pessoa continua digitando só o usuário de sempre
-- na tela de login; o site resolve esse e-mail por conta própria (ver
-- resolve_login_email abaixo).
alter table accounts add column if not exists auth_email text;
update accounts set auth_email = email where auth_email is null and email is not null;
update accounts set auth_email = lower(regexp_replace(name, '[^a-z0-9]+', '-', 'g')) || '@login.interno'
  where auth_email is null;
alter table accounts alter column auth_email set not null;
create unique index if not exists accounts_auth_email_unique on accounts (lower(auth_email));

-- Resolve o que a pessoa digitou (usuário OU e-mail institucional, exatamente
-- como aceita hoje) pro e-mail real usado no Auth. Não devolve nada sensível
-- (não é senha, é só "esse nome corresponde a esse e-mail interno") — é
-- security definer só pra poder ler "accounts" mesmo com RLS ativado nela.
drop function if exists resolve_login_email(text);
create or replace function resolve_login_email(p_login text)
returns text
language sql
stable
security definer
set search_path = public
as $$
  select auth_email from accounts
  where lower(coalesce(email, name)) = lower(p_login) or lower(auth_email) = lower(p_login)
  limit 1;
$$;
grant execute on function resolve_login_email(text) to anon;
grant execute on function resolve_login_email(text) to service_role;

-- Diz se essa conta ainda não migrou pro Auth de verdade (ainda depende da
-- senha antiga em texto puro) — o site usa isso pra decidir se chama a
-- Edge Function "legacy-login" (que faz a migração) ou o login normal do
-- Auth. Não devolve nada sensível, só um verdadeiro/falso.
drop function if exists login_needs_migration(text);
create or replace function login_needs_migration(p_login text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select auth_user_id is null from accounts
  where lower(coalesce(email, name)) = lower(p_login) or lower(auth_email) = lower(p_login)
  limit 1;
$$;
grant execute on function login_needs_migration(text) to anon;
