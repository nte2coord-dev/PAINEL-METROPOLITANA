-- Passo 2 da migração pra autenticação de verdade: troca as regras de
-- acesso de "using(true)" (todo mundo com a chave pública pode tudo) por
-- checagem real de quem está logado — diretor/dev vê e edita tudo,
-- coordenador só o próprio setor, servidor só lê o próprio setor.
--
-- Apaga também as funções antigas que criavam/apagavam/trocavam senha de
-- conta sem checar quem estava chamando (verify_login, update_account,
-- get_account_names, approve_access_request, create_servidor,
-- delete_account) — eram o ponto fraco de tudo isso: qualquer um com a
-- chave pública conseguia chamá-las direto, sem passar pela tela. A
-- criação/remoção de conta agora exige a Edge Function "manage-account"
-- (só ela tem a chave secreta que fala com o Auth do Supabase); o resto
-- (ler o próprio nome, trocar o próprio nome) passa a ser select/update
-- comum, liberado pelas políticas abaixo.

-- ---------- funções auxiliares (usadas dentro das políticas) ----------
-- security definer só pra poder ler "accounts" (que tem RLS) de dentro de
-- uma política de OUTRA tabela sem cair em recursão — sempre devolvem só
-- o papel/setor de quem está chamando (auth.uid()), nunca de outra conta.

drop function if exists my_role();
create or replace function my_role()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role from accounts where auth_user_id = auth.uid();
$$;

drop function if exists my_setor_id();
create or replace function my_setor_id()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select setor_id from accounts where auth_user_id = auth.uid();
$$;

drop function if exists is_diretor_like();
create or replace function is_diretor_like()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce((select role from accounts where auth_user_id = auth.uid()) in ('diretor', 'dev'), false);
$$;

-- ---------- setores: qualquer logado lê; só diretor/dev edita ----------

drop policy if exists "setores_all" on setores;
drop policy if exists setores_select on setores;
create policy setores_select on setores for select using (auth.uid() is not null);
drop policy if exists setores_write on setores;
create policy setores_write on setores for all using (is_diretor_like()) with check (is_diretor_like());

-- ---------- groups: lê quem é do setor (ou diretor/dev); edita diretor/dev
-- ou coordenador do próprio setor ----------

drop policy if exists "groups_all" on groups;
drop policy if exists groups_select on groups;
create policy groups_select on groups for select using (
  is_diretor_like() or setor_id = my_setor_id()
);
drop policy if exists groups_write on groups;
create policy groups_write on groups for all using (
  is_diretor_like() or (my_role() = 'admin' and setor_id = my_setor_id())
) with check (
  is_diretor_like() or (my_role() = 'admin' and setor_id = my_setor_id())
);

-- ---------- systems: mesma regra de groups, só que o setor vem do group
-- (systems não guarda setor_id direto) ----------

drop policy if exists "systems_all" on systems;
drop policy if exists systems_select on systems;
create policy systems_select on systems for select using (
  is_diretor_like() or exists (select 1 from groups g where g.id = systems.group_id and g.setor_id = my_setor_id())
);
drop policy if exists systems_write on systems;
create policy systems_write on systems for all using (
  is_diretor_like() or (my_role() = 'admin' and exists (select 1 from groups g where g.id = systems.group_id and g.setor_id = my_setor_id()))
) with check (
  is_diretor_like() or (my_role() = 'admin' and exists (select 1 from groups g where g.id = systems.group_id and g.setor_id = my_setor_id()))
);

-- ---------- solicitacoes_acesso: qualquer um (logado ou não) pode pedir;
-- só diretor/dev vê e processa a fila ----------

drop policy if exists "solicitacoes_acesso_all" on solicitacoes_acesso;
drop policy if exists solicitacoes_insert on solicitacoes_acesso;
create policy solicitacoes_insert on solicitacoes_acesso for insert with check (true);
drop policy if exists solicitacoes_manage on solicitacoes_acesso;
create policy solicitacoes_manage on solicitacoes_acesso for all using (is_diretor_like()) with check (is_diretor_like());

-- ---------- accounts: cada um só vê/edita a própria conta; diretor/dev
-- vê todo mundo; coordenador vê o roster do próprio setor. Criar/remover
-- conta continua fechado pra qualquer um com a chave pública — só a Edge
-- Function (com a chave secreta) faz isso. ----------

drop policy if exists accounts_select_own on accounts;
create policy accounts_select_own on accounts for select using (auth_user_id = auth.uid());

drop policy if exists accounts_select_roster on accounts;
create policy accounts_select_roster on accounts for select using (
  is_diretor_like() or (my_role() = 'admin' and setor_id = my_setor_id())
);

drop policy if exists accounts_update_own on accounts;
create policy accounts_update_own on accounts for update using (auth_user_id = auth.uid()) with check (auth_user_id = auth.uid());

-- RLS só decide QUAL linha — sem isto, a policy "própria linha" acima
-- deixaria um coordenador logado mandar um PATCH direto pra accounts
-- trocando o próprio "role" pra "diretor" (a linha continua sendo a
-- dele, então using()/with check() acima deixariam passar). "name" é a
-- única coluna editável direto (é só o que Configurações muda); trocar
-- papel/setor só é possível pela Edge Function.
revoke update on accounts from authenticated, anon;
grant update (name) on accounts to authenticated;

-- Idem pro select: "password" (ainda existe, só até a migração de todo
-- mundo terminar — ver legacy-login) nunca pode ser lido pela API, nem
-- da própria conta, e MENOS AINDA da conta de outra pessoa no mesmo
-- setor (a policy accounts_select_roster deixaria ver a linha inteira
-- sem essa restrição de coluna).
revoke select on accounts from authenticated, anon;
grant select (id, role, name, setor_id, email, masp, telefone, cargo, email_verified_at, auth_email, auth_user_id) on accounts to authenticated;

-- ---------- fecha os caminhos antigos que não checavam quem chamava ----------

drop function if exists verify_login(text, text);
drop function if exists update_account(text, text, text);
drop function if exists get_account_names();
drop function if exists approve_access_request(text, text, text, text, text, text, text, text, text, text);
drop function if exists create_servidor(text, text, text, text, text, text, text, text, text);
drop function if exists delete_account(text);

-- Continua existindo, só que sem parâmetro: cada conta só marca a
-- própria (auth.uid()), nunca a de outra pessoa. security definer porque
-- "authenticated" só tem GRANT de UPDATE na coluna "name" (ver acima) —
-- essa função precisa rodar com o dono pra poder tocar
-- email_verified_at; continua seguro porque só atualiza auth.uid(), que
-- reflete sempre quem chamou, nunca um id arbitrário.
drop function if exists mark_email_verified(text);
create or replace function mark_email_verified()
returns void
language sql
security definer
set search_path = public
as $$
  update accounts set email_verified_at = now() where auth_user_id = auth.uid();
$$;
grant execute on function mark_email_verified() to authenticated;
