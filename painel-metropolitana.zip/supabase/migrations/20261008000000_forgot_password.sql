-- "Esqueci a senha" (sem precisar estar logado): a pessoa digita o
-- e-mail, recebe um código de 6 dígitos (mesmo mecanismo de OTP por
-- e-mail do Supabase Auth já usado na verificação do primeiro login —
-- ver sendLoginOtp/verifyLoginOtp em store.js), confirma o código e
-- escolhe uma senha nova. Confirmar o código já estabelece uma sessão de
-- verdade (client.auth.setSession) — o suficiente pra chamar
-- updateUser({password}) e trocar a senha, sem precisar da senha antiga
-- (que é exatamente o problema: a pessoa esqueceu).
--
-- Only problema: pra uma conta que nunca logou desde a migração pro Auth
-- de verdade (accounts.auth_user_id ainda null, mas já tem e-mail real
-- cadastrado — por exemplo quem nunca precisou trocar senha antes), o
-- código acima cria/usa um usuário no Auth, mas ninguém liga esse usuário
-- de volta à linha de "accounts" (só o login antigo, com a senha que a
-- pessoa esqueceu, fazia essa ligação). Essa função resolve isso: depois
-- de confirmar o código (e estar autenticada por essa sessão temporária),
-- a pessoa mesma "se liga" à própria conta — só se ainda não tinha
-- ligação nenhuma, e só na linha cujo e-mail é exatamente o e-mail
-- autenticado (nunca o de outra pessoa). Idempotente: se já estava
-- ligada (caso comum, de quem já logou antes), não faz nada.
drop function if exists link_auth_after_password_reset();
create or replace function link_auth_after_password_reset()
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  my_email text;
begin
  select email into my_email from auth.users where id = auth.uid();
  if my_email is null then
    return;
  end if;
  update accounts
  set auth_user_id = auth.uid()
  where auth_user_id is null and lower(email) = lower(my_email);
end;
$$;
grant execute on function link_auth_after_password_reset() to authenticated;
