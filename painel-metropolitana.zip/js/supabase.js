// Cliente pro Supabase — agora usando a biblioteca oficial (carregada via
// CDN em index.html, sem precisar de build/npm), porque o login passou a
// ser autenticação de verdade (Supabase Auth): cada pessoa logada manda
// seu próprio token nas chamadas, não mais só a chave pública (anon) do
// projeto pra tudo. As regras de quem pode ver/editar o quê agora vivem
// no próprio banco (RLS), não só na tela — ver supabase/migrations/ e o
// README.
//
// A sessão fica salva no sessionStorage (não localStorage): some ao
// fechar a aba/janela, do mesmo jeito que o site sempre se comportou.
(function (global) {
  "use strict";

  var SUPABASE_URL = "https://xpuomayzaylwfeuruyka.supabase.co";
  var SUPABASE_KEY = "sb_publishable_nNEYd92hkZKsilMRVcAxSA_FI5crs4n";

  var client = global.supabase.createClient(SUPABASE_URL, SUPABASE_KEY, {
    auth: { storage: global.sessionStorage, persistSession: true, autoRefreshToken: true },
  });

  function unwrap(promise) {
    return promise.then(function (result) {
      if (result.error) throw result.error;
      return result.data;
    });
  }

  // Chamadas às Edge Functions vão de fetch puro (não client.functions.invoke)
  // pra poder ler o status HTTP e o corpo do erro exatamente como a função
  // devolve — importante pra diferenciar "senha errada" (login normal, sem
  // alarme) de "banco fora do ar" (erro de verdade).
  function callFunction(name, body, accessToken) {
    return fetch(SUPABASE_URL + "/functions/v1/" + name, {
      method: "POST",
      headers: {
        "apikey": SUPABASE_KEY,
        "Authorization": "Bearer " + (accessToken || SUPABASE_KEY),
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body || {}),
    }).then(function (res) {
      return res.text().then(function (text) {
        var parsed = text ? JSON.parse(text) : null;
        if (!res.ok) {
          var err = new Error((parsed && parsed.error) || ("Edge Function " + name + ": " + res.status));
          err.status = res.status;
          err.body = parsed;
          throw err;
        }
        return parsed;
      });
    });
  }

  var SupabaseClient = {
    select: function (table, query) {
      var builder = client.from(table).select("*");
      return unwrap(applyQueryString(builder, query));
    },
    // Usados só pra "accounts" — nunca "select *" nela: a coluna
    // "password" (ainda existe até todo mundo migrar pro Auth, ver
    // legacy-login) não tem GRANT de leitura pra ninguém além do dono da
    // função, então "*" daria erro de permissão em vez de simplesmente
    // omitir a coluna. Lista explícita evita isso e, de propósito, nunca
    // inclui "password".
    ACCOUNTS_SAFE_COLUMNS: "id,role,name,setor_id,email,masp,telefone,cargo,email_verified_at,auth_email,auth_user_id",
    selectOne: function (table, column, value) {
      var cols = table === "accounts" ? this.ACCOUNTS_SAFE_COLUMNS : "*";
      return unwrap(client.from(table).select(cols).eq(column, value).maybeSingle());
    },
    selectEq: function (table, column, value) {
      var cols = table === "accounts" ? this.ACCOUNTS_SAFE_COLUMNS : "*";
      return unwrap(client.from(table).select(cols).eq(column, value));
    },
    // Sem filtro de setor de propósito: quem decide quais linhas voltam é
    // a RLS (accounts_select_roster) — diretor/dev recebe todo mundo,
    // coordenador já volta só com o próprio setor, sem precisar pedir
    // explicitamente. Usado pela tela "Gerenciar acessos".
    selectAllAccounts: function () {
      return unwrap(client.from("accounts").select(this.ACCOUNTS_SAFE_COLUMNS));
    },
    insert: function (table, row) {
      return unwrap(client.from(table).insert(row).select());
    },
    // "row" pode ser um array (upsert em lote) — usado pra importar uma
    // vigência nova inteira do SICALC de uma vez. Sem ".select()" no
    // retorno de propósito: num lote de ~1200 linhas não precisamos do
    // eco de volta, só saber se deu certo (unwrap já lança se "error").
    upsert: function (table, rows, conflictColumns) {
      var opts = conflictColumns ? { onConflict: conflictColumns } : undefined;
      return unwrap(client.from(table).upsert(rows, opts));
    },
    updateById: function (table, id, patch) {
      var cols = table === "accounts" ? this.ACCOUNTS_SAFE_COLUMNS : "*";
      return unwrap(client.from(table).update(patch).eq("id", id).select(cols));
    },
    deleteById: function (table, id) {
      return unwrap(client.from(table).delete().eq("id", id));
    },
    // Apaga TODAS as linhas onde "column" = "value" — diferente de
    // deleteById (sempre 1 linha, pela chave), usado quando a exclusão é
    // "todo um lote"/"todo um setor" de uma vez (ver Leitor do Diário).
    deleteByColumn: function (table, column, value) {
      return unwrap(client.from(table).delete().eq(column, value));
    },
    // Igual acima, mas filtrando por duas colunas ao mesmo tempo — usado
    // pra revogar o acesso de UM setor a UMA ferramenta (chave composta de
    // ferramenta_acessos), sem mexer no acesso desse setor às outras
    // ferramentas nem no de outros setores a essa mesma ferramenta.
    deleteByColumns: function (table, filters) {
      var builder = client.from(table).delete();
      for (var col in filters) builder = builder.eq(col, filters[col]);
      return unwrap(builder);
    },
    rpc: function (fn, args) {
      return unwrap(client.rpc(fn, args || {}));
    },

    // ---------- sessão (Auth de verdade) ----------
    signInWithPassword: function (email, password) {
      return unwrap(client.auth.signInWithPassword({ email: email, password: password }));
    },
    // Conta antiga (senha ainda em texto puro, nunca logou desde a
    // migração pro Auth): a Edge Function confere a senha antiga e já
    // devolve uma sessão de verdade, pra próxima vez já entrar direto.
    legacyLogin: function (login, password) {
      return callFunction("legacy-login", { login: login, password: password }).then(function (data) {
        return client.auth.setSession({
          access_token: data.session.access_token,
          refresh_token: data.session.refresh_token,
        }).then(function (result) {
          if (result.error) throw result.error;
          return result.data;
        });
      });
    },
    needsMigration: function (login) {
      return unwrap(client.rpc("login_needs_migration", { p_login: login }));
    },
    resolveLoginEmail: function (login) {
      return unwrap(client.rpc("resolve_login_email", { p_login: login }));
    },
    signOut: function () {
      return unwrap(client.auth.signOut());
    },
    updatePassword: function (password) {
      return unwrap(client.auth.updateUser({ password: password }));
    },
    getSession: function () {
      return client.auth.getSession().then(function (result) { return result.data.session; });
    },
    getAccessToken: function () {
      return client.auth.getSession().then(function (result) {
        return result.data.session ? result.data.session.access_token : null;
      });
    },

    // ---------- criar/remover conta (exige a chave secreta do outro lado) ----------
    // Manda o token de quem está chamando (não a chave pública) — a Edge
    // Function usa esse token pra saber quem é e decidir se pode ou não.
    createAccount: function (payload) {
      return this.getAccessToken().then(function (token) {
        return callFunction("manage-account", Object.assign({ action: "create" }, payload), token);
      });
    },
    deleteAccount: function (accountId) {
      return this.getAccessToken().then(function (token) {
        return callFunction("manage-account", { action: "delete", account_id: accountId }, token);
      });
    },
    setAccountRole: function (accountId, role) {
      return this.getAccessToken().then(function (token) {
        return callFunction("manage-account", { action: "set_role", account_id: accountId, role: role }, token);
      });
    },
    // Auto-cadastro: ninguém está logado ainda, então vai sem token (a
    // própria Edge Function decide se aceita, sem precisar saber quem
    // está chamando — ver manage-account, ação "register").
    registerRequest: function (payload) {
      return callFunction("manage-account", Object.assign({ action: "register" }, payload));
    },
    rejectAccessRequest: function (requestId) {
      return this.getAccessToken().then(function (token) {
        return callFunction("manage-account", { action: "reject_request", request_id: requestId }, token);
      });
    },

    // Auth do próprio Supabase, usado só como "envie um código pra esse
    // e-mail e confirme": nunca vira o mecanismo de sessão/login do site
    // — isso é sempre signInWithPassword/legacyLogin acima. Vai por fetch
    // puro (chave pública, não a sessão atual) porque não deve afetar a
    // sessão de ninguém.
    sendOtp: function (email) {
      return request("/auth/v1/otp", { method: "POST", body: { email: email, create_user: true } });
    },
    verifyOtp: function (email, token) {
      return request("/auth/v1/verify", { method: "POST", body: { email: email, token: token, type: "email" } });
    },

    // ---------- "Esqueci a senha" (sem estar logado) ----------
    // Mesmo /auth/v1/otp acima (sendOtp) é reaproveitado pra mandar o
    // código — a diferença começa na confirmação: aqui, confirmar o
    // código PRECISA virar uma sessão de verdade (setSession), porque é
    // isso que vai autorizar o updateUser({password}) depois. Nunca
    // confirma a existência da conta pro chamador (sempre "mandamos o
    // código, se a conta existir") — evita dar pra alguém de fora
    // descobrir quais e-mails têm conta só tentando "esqueci a senha".
    verifyPasswordResetOtp: function (email, token) {
      return request("/auth/v1/verify", { method: "POST", body: { email: email, token: token, type: "email" } })
        .then(function (data) {
          return client.auth.setSession({ access_token: data.access_token, refresh_token: data.refresh_token });
        }).then(function (result) {
          if (result.error) throw result.error;
          return result.data;
        });
    },
    // Só funciona depois de verifyPasswordResetOtp (precisa da sessão
    // temporária que ele estabelece). link_auth_after_password_reset é
    // idempotente e só liga a própria conta (ver migração) — chamado
    // sempre, de propósito, pra cobrir também quem nunca tinha logado
    // antes (accounts.auth_user_id ainda null) e só agora, com o e-mail
    // confirmado por código, ganha essa ligação.
    finishPasswordReset: function (newPassword) {
      return unwrap(client.rpc("link_auth_after_password_reset", {})).then(function () {
        return client.auth.updateUser({ password: newPassword });
      }).then(function (result) {
        if (result.error) throw result.error;
        return result.data;
      });
    },
  };

  function applyQueryString(builder, query) {
    // As chamadas antigas passavam algo como "?select=*&order=name" — só
    // o "order=" importa continuar suportando (select=* já é o padrão).
    var m = /(?:^|&)order=([^&]+)/.exec(query || "");
    if (m) {
      var col = decodeURIComponent(m[1]);
      var asc = true;
      if (col.indexOf(".") !== -1) {
        var parts = col.split(".");
        col = parts[0];
        asc = parts[1] !== "desc";
      }
      builder = builder.order(col, { ascending: asc });
    }
    return builder;
  }

  function request(path, options) {
    options = options || {};
    var headers = {
      "apikey": SUPABASE_KEY,
      "Authorization": "Bearer " + SUPABASE_KEY,
      "Content-Type": "application/json",
    };
    if (options.headers) {
      for (var k in options.headers) headers[k] = options.headers[k];
    }
    return fetch(SUPABASE_URL + path, {
      method: options.method || "GET",
      headers: headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
    }).then(function (res) {
      if (!res.ok) {
        return res.text().then(function (text) {
          throw new Error("Supabase " + res.status + ": " + text);
        });
      }
      if (res.status === 204) return null;
      var contentLength = res.headers.get("content-length");
      if (contentLength === "0") return null;
      return res.text().then(function (text) { return text ? JSON.parse(text) : null; });
    });
  }

  global.SupabaseClient = SupabaseClient;
})(window);
