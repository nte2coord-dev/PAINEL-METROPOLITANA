(function () {
  "use strict";

  var PENCIL_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"></path><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"></path></svg>';
  var FOLDER_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"></path></svg>';
  var BUILDING_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 21V7a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v14"></path><path d="M14 21V11a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v10"></path><path d="M9 9h.01M9 12h.01M9 15h.01M9 18h.01"></path></svg>';
  var PLUS_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"></path></svg>';
  var BACK_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"></path></svg>';
  var PAPERCLIP_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path></svg>';
  var MAX_DOC_FILE_BYTES = 4 * 1024 * 1024;

  var viewState = { type: "home" };
  var editingSystemId = null;
  var editingGroupId = null;
  var editingSetorId = null;
  var selectedSystemColor = "blue";
  var selectedGroupColor = "blue";
  var selectedSetorColor = "blue";
  var pendingDocuments = [];
  var pendingSystemIcon = null;
  var pendingGroupIcon = null;
  var pendingSetorIcon = null;
  // Filtro de setor da tela "Gerenciar acessos" (só o diretor vê esse
  // filtro — null é "todos os setores"). Fica fora do viewState porque
  // sobrevive a um back-and-forth pra dentro/fora dessa tela.
  var acessosFilterSetorId = null;
  // Id do card de setor sendo arrastado no Painel de Setores (drag-and-drop
  // pra reordenar) — null quando não tem nenhum arraste em andamento.
  var draggedSetorId = null;
  // currentRole/currentAccountId não vêm mais do sessionStorage: quem
  // mantém a pessoa logada entre uma recarregada e outra agora é a
  // sessão de verdade do Auth (guardada pela própria biblioteca, também
  // no sessionStorage, mas por baixo) — no boot, Store.getMyAccount()
  // busca a conta de novo a partir dessa sessão real. Essas duas
  // variáveis só guardam o que já foi confirmado nesta execução da
  // página.
  var currentRole = null;
  var currentAccountId = null;
  // Só uma preferência de navegação (qual setor a pessoa tinha aberto) —
  // não tem nada a ver com autenticação, então continua no sessionStorage
  // direto.
  var savedSetorId = (function () {
    try { return sessionStorage.getItem("portal-setor") || null; } catch (e) { return null; }
  })();

  function isDiretorRole() { return currentRole === "diretor"; }

  // Coordenador: sempre admin do próprio setor. Diretor: só tem os
  // mesmos poderes de edição quando "entrou" num setor específico
  // (Painel de Setores é só leitura/gestão de setores, não edita grupos/
  // sistemas).
  function isAdmin() {
    if (currentRole === "admin") return true;
    if (isDiretorRole()) return Store.getCurrentSetor() !== null;
    return false;
  }

  function isPainelMode() { return isDiretorRole() && Store.getCurrentSetor() === null; }

  // Quem pode abrir "Gerenciar acessos": coordenador (no próprio setor) e
  // diretor (em qualquer setor, mesmo no Painel de Setores) — por isso
  // não reaproveita isAdmin() aqui (que exige o diretor ter "entrado"
  // num setor antes).
  function canManageAccess() { return currentRole === "admin" || isDiretorRole(); }

  function saveSession() {
    try {
      sessionStorage.setItem("portal-setor", Store.getCurrentSetor() || "");
    } catch (err) { /* indisponível */ }
  }

  // ---------- helpers ----------

  function normalize(str) {
    return (str || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  }

  function normalizeUrl(url) {
    url = (url || "").trim();
    if (!url) return "";
    if (!/^https?:\/\//i.test(url)) return "https://" + url;
    return url;
  }

  function shortenUrl(url) {
    try {
      return new URL(url).hostname.replace(/^www\./, "");
    } catch (e) {
      return url.length > 44 ? url.slice(0, 44) + "…" : url;
    }
  }

  function fallbackTag(name) {
    var letters = (name || "").replace(/[^A-Za-zÀ-ÿ0-9]/g, "");
    return (letters.slice(0, 2) || "??").toUpperCase();
  }

  // Lê o arquivo escolhido, recorta ao quadrado central e reduz pra um
  // ícone pequeno (evita linhas gigantes no banco com fotos grandes).
  function readImageAsSquareDataUrl(file, size) {
    size = size || 128;
    return new Promise(function (resolve, reject) {
      if (!file || file.type.indexOf("image/") !== 0) {
        reject(new Error("Selecione um arquivo de imagem."));
        return;
      }
      var reader = new FileReader();
      reader.onerror = function () { reject(new Error("Não foi possível ler o arquivo.")); };
      reader.onload = function () {
        var img = new Image();
        img.onerror = function () { reject(new Error("Não foi possível abrir essa imagem.")); };
        img.onload = function () {
          var side = Math.min(img.width, img.height);
          var sx = (img.width - side) / 2;
          var sy = (img.height - side) / 2;
          var canvas = document.createElement("canvas");
          canvas.width = size;
          canvas.height = size;
          var ctx = canvas.getContext("2d");
          ctx.drawImage(img, sx, sy, side, side, 0, 0, size, size);
          resolve(canvas.toDataURL("image/png"));
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  function formatFileSize(bytes) {
    if (!bytes) return "0 KB";
    if (bytes < 1024 * 1024) return Math.max(1, Math.round(bytes / 1024)) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1).replace(".", ",") + " MB";
  }

  // Lê um arquivo qualquer (não precisa ser imagem) como data URL, pra
  // anexar como documento. Fica salvo dentro do próprio banco (Supabase) —
  // por isso o limite de tamanho, pra não estourar uma linha da tabela.
  function readFileAsDataUrl(file) {
    return new Promise(function (resolve, reject) {
      if (!file) { reject(new Error("Nenhum arquivo selecionado.")); return; }
      if (file.size > MAX_DOC_FILE_BYTES) {
        reject(new Error("Arquivo muito grande (" + formatFileSize(file.size) + "). O limite é 4 MB."));
        return;
      }
      var reader = new FileReader();
      reader.onerror = function () { reject(new Error("Não foi possível ler o arquivo.")); };
      reader.onload = function () { resolve(reader.result); };
      reader.readAsDataURL(file);
    });
  }

  function triggerDownload(url, fileName) {
    var a = document.createElement("a");
    a.href = url;
    a.download = fileName || "arquivo";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function checkStorageWarning() {
    document.getElementById("storage-warning").hidden = Store.isPersistent();
  }

  function el(tag, className, html) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (html !== undefined) node.innerHTML = html;
    return node;
  }

  function buildExternalIcon() {
    var ns = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(ns, "svg");
    svg.setAttribute("class", "tool-external-icon");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("fill", "none");
    svg.setAttribute("stroke", "currentColor");
    svg.setAttribute("stroke-width", "2");
    svg.setAttribute("stroke-linecap", "round");
    svg.setAttribute("stroke-linejoin", "round");
    svg.setAttribute("aria-hidden", "true");
    var path = document.createElementNS(ns, "path");
    path.setAttribute("d", "M17 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h5");
    svg.appendChild(path);
    var poly = document.createElementNS(ns, "polyline");
    poly.setAttribute("points", "14 3 20 3 20 9");
    svg.appendChild(poly);
    var line = document.createElementNS(ns, "line");
    line.setAttribute("x1", "10"); line.setAttribute("y1", "14");
    line.setAttribute("x2", "20"); line.setAttribute("y2", "4");
    svg.appendChild(line);
    return svg;
  }

  function gradient(colorName) {
    var c = Store.PALETTE[colorName] || Store.PALETTE.blue;
    return "linear-gradient(135deg, " + c.from + ", " + c.to + ")";
  }

  // ---------- dialog plumbing ----------

  // "Clique fora fecha": dialog nativo nao tem isso pronto, por isso
  // detectamos manualmente. Só fecha se o mousedown E o click caírem fora
  // do card — não só o click. Isso evita um bug real: ao escolher um
  // arquivo no explorador do sistema (input file), o navegador às vezes
  // dispara um click "fantasma" na página quando o seletor nativo fecha;
  // sem o mousedown correspondente (que aconteceu dentro do seletor do
  // sistema, não na página), esse clique fantasma não fecha mais o modal.
  function setupBackdropClose(dialog) {
    var mousedownOutside = false;
    function isOutside(e) {
      var rect = dialog.getBoundingClientRect();
      return !(e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom);
    }
    dialog.addEventListener("mousedown", function (e) { mousedownOutside = isOutside(e); });
    dialog.addEventListener("click", function (e) {
      if (mousedownOutside && isOutside(e)) dialog.close();
      mousedownOutside = false;
    });
  }

  function setupModalCloseButtons() {
    document.querySelectorAll("[data-close]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var dialog = btn.closest("dialog");
        if (dialog) dialog.close();
      });
    });
  }

  function confirmDialog(message, opts) {
    opts = opts || {};
    var modal = document.getElementById("confirm-modal");
    document.getElementById("confirm-title").textContent = opts.title || "Confirmar";
    document.getElementById("confirm-message").textContent = message;
    var okBtn = document.getElementById("confirm-ok");
    okBtn.textContent = opts.okLabel || "Confirmar";

    return new Promise(function (resolve) {
      var resolved = false;
      function onOk() { resolved = true; modal.close(); }
      function onClose() {
        okBtn.removeEventListener("click", onOk);
        resolve(resolved);
      }
      okBtn.addEventListener("click", onOk);
      modal.addEventListener("close", onClose, { once: true });
      modal.showModal();
    });
  }

  // ---------- login / configurações ----------

  var selectedLoginRole = null;
  var pendingVerifyAccount = null;

  function loginRoleLabel(role) {
    if (role === "diretor") return "diretor";
    if (role === "admin") return "coordenador";
    return "servidor";
  }

  function completeLogin(account) {
    currentRole = account.role;
    currentAccountId = account.id;
    saveSession();
    document.getElementById("login-modal").close();
    unlockPortal();
    updateChromeForRole();
    render();
  }

  // Só entra aqui quando a conta tem e-mail e ainda não verificou (ver
  // needs_email_verification em verify_login) — pede o código que o
  // Supabase Auth acabou de mandar pra esse e-mail, só dessa vez.
  function showLoginOtpStep(email) {
    document.getElementById("login-otp-email-display").textContent = email;
    document.getElementById("login-otp-code").value = "";
    document.getElementById("login-otp-error").hidden = true;
    document.getElementById("login-otp-hint").hidden = true;
    document.getElementById("login-form").hidden = true;
    document.getElementById("login-otp-form").hidden = false;
    document.getElementById("login-otp-code").focus();
  }

  // Login em 2 passos: primeiro a pessoa diz que tipo de conta é (diretor/
  // coordenador/servidor), só depois entra com usuário-ou-e-mail + senha.
  // O papel escolhido aqui é conferido contra o papel real da conta depois
  // que verify_login responde (ver wireAuth) — evita alguém cair na tela
  // errada por engano, sem ser a proteção de verdade (essa continua sendo
  // a senha).
  function showLoginRoleStep() {
    selectedLoginRole = null;
    pendingVerifyAccount = null;
    document.getElementById("login-form").hidden = false;
    document.getElementById("login-otp-form").hidden = true;
    document.getElementById("forgot-pass-email-form").hidden = true;
    document.getElementById("forgot-pass-reset-form").hidden = true;
    document.getElementById("login-heading").textContent = "Acesso restrito";
    document.getElementById("login-back").hidden = true;
    document.getElementById("login-role-step").hidden = false;
    document.getElementById("login-credentials-step").hidden = true;
    document.getElementById("login-footer-credentials").hidden = true;
    document.getElementById("login-user").value = "";
    document.getElementById("login-pass").value = "";
    document.getElementById("login-error").hidden = true;
    hideLoginResetSuccessHint();
  }

  function showLoginCredentialsStep(role) {
    selectedLoginRole = role;
    document.getElementById("login-heading").textContent = "Entrar como " + loginRoleLabel(role);
    document.getElementById("login-form").hidden = false;
    document.getElementById("forgot-pass-email-form").hidden = true;
    document.getElementById("forgot-pass-reset-form").hidden = true;
    document.getElementById("login-back").hidden = false;
    document.getElementById("login-role-step").hidden = true;
    document.getElementById("login-credentials-step").hidden = false;
    document.getElementById("login-footer-credentials").hidden = false;
    document.getElementById("login-error").hidden = true;
    hideLoginResetSuccessHint();
    document.getElementById("login-user").focus();
  }

  // Esconde o aviso de "senha alterada" assim que a pessoa sai da tela de
  // credenciais por qualquer outro caminho (voltar pro seletor de papel,
  // trocar de aba) — ele só deve aparecer logo depois de um reset bem
  // sucedido, nunca sobrar visível depois.
  function hideLoginResetSuccessHint() {
    document.getElementById("login-reset-success-hint").hidden = true;
  }

  // "Esqueci a senha": dois passos (e-mail -> código + senha nova), os
  // dois sem precisar estar logado. Fica guardado o e-mail digitado no
  // passo 1 pra usar no passo 2 (confirmar código) e no reenviar.
  var pendingResetEmail = null;
  function showForgotPassEmailStep() {
    pendingResetEmail = null;
    document.getElementById("login-form").hidden = true;
    document.getElementById("forgot-pass-reset-form").hidden = true;
    document.getElementById("forgot-pass-email").value = "";
    document.getElementById("forgot-pass-email-error").hidden = true;
    document.getElementById("forgot-pass-email-form").hidden = false;
    document.getElementById("forgot-pass-email").focus();
  }
  function showForgotPassResetStep(email) {
    pendingResetEmail = email;
    document.getElementById("forgot-pass-email-display").textContent = email;
    document.getElementById("forgot-pass-code").value = "";
    document.getElementById("forgot-pass-new").value = "";
    document.getElementById("forgot-pass-confirm").value = "";
    document.getElementById("forgot-pass-reset-error").hidden = true;
    document.getElementById("forgot-pass-reset-hint").hidden = true;
    document.getElementById("forgot-pass-email-form").hidden = true;
    document.getElementById("forgot-pass-reset-form").hidden = false;
    document.getElementById("forgot-pass-code").focus();
  }

  function openLoginModal() {
    showLoginRoleStep();
    var initError = Store.hasInitError();
    document.getElementById("login-init-error").hidden = !initError;
    document.querySelectorAll(".role-picker-btn").forEach(function (btn) { btn.disabled = !!initError; });
    var modal = document.getElementById("login-modal");
    if (!modal.open) modal.showModal();
  }

  // Configurações é sempre a própria conta de quem está logado — nome e
  // senha. Antes tentava adivinhar "o admin/viewer desse setor", o que
  // dava errado quando um setor tinha mais de um coordenador ou servidor;
  // agora usa o id salvo no login (currentAccountId), sem ambiguidade.
  // pendingSettingsAccount guarda essa conta (com e-mail) pro passo de
  // verificação abaixo, sem precisar buscar de novo na hora de salvar.
  var pendingSettingsAccount = null;
  function openSettingsModal() {
    document.getElementById("settings-pass").value = "";
    document.getElementById("settings-name").value = "";
    document.getElementById("settings-error").hidden = true;
    document.getElementById("settings-form").hidden = false;
    document.getElementById("settings-otp-form").hidden = true;
    pendingSettingsAccount = null;
    document.getElementById("settings-modal").showModal();
    Store.getAccount(currentAccountId).then(function (myAccount) {
      pendingSettingsAccount = myAccount;
      document.getElementById("settings-name").value = myAccount ? myAccount.name : "";
      document.getElementById("settings-name").focus();
    });
  }

  // Passo extra só pro diretor trocando a própria senha (ver
  // Store.passwordChangeNeedsVerification) — mesmo mecanismo do código de
  // e-mail do primeiro login, mas sem afetar a sessão atual.
  function showSettingsOtpStep(email) {
    document.getElementById("settings-otp-email-display").textContent = email;
    document.getElementById("settings-otp-code").value = "";
    document.getElementById("settings-otp-error").hidden = true;
    document.getElementById("settings-otp-hint").hidden = true;
    document.getElementById("settings-form").hidden = true;
    document.getElementById("settings-otp-form").hidden = false;
    document.getElementById("settings-otp-code").focus();
  }

  function applySettingsChange() {
    var name = document.getElementById("settings-name").value.trim();
    var settingsErrorEl = document.getElementById("settings-error");
    var submitBtn = document.querySelector("#settings-form button[type=submit]");
    settingsErrorEl.hidden = true;
    submitBtn.disabled = true;
    return Store.updateMyAccount(currentAccountId, { name: name, password: document.getElementById("settings-pass").value })
      .then(function () {
        submitBtn.disabled = false;
        document.getElementById("settings-modal").close();
        checkStorageWarning();
      })
      .catch(function (err) {
        submitBtn.disabled = false;
        settingsErrorEl.textContent = /password/i.test(err.message || "")
          ? "Senha muito curta — use pelo menos 6 caracteres."
          : "Não foi possível salvar. Tente de novo.";
        settingsErrorEl.hidden = false;
        console.error(err);
      });
  }

  // Mostra/esconde o menu (qualquer papel logado) e, dentro dele, os itens
  // só do diretor (Gerenciar setores/acessos) — Configurações, tema e
  // Sair ficam visíveis pra qualquer um que tiver o menu.
  function updateChromeForRole() {
    document.getElementById("main-menu-btn").hidden = !currentRole;
    document.getElementById("ferramentas-btn").hidden = !currentRole;
    var showDiretorItems = isDiretorRole();
    document.getElementById("diretor-menu-setores").hidden = !showDiretorItems;
    document.getElementById("diretor-menu-acessos").hidden = !showDiretorItems;
    document.getElementById("menu-diretor-sep").hidden = !showDiretorItems;
  }

  // O portal inteiro fica escondido até o login — só o cabeçalho (logo,
  // relógio, tema) continua visível por trás do modal, que é obrigatório
  // (sem fechar por ESC, clique fora ou botão de cancelar).
  function lockPortal() {
    document.getElementById("conteudo").hidden = true;
    updateChromeForRole();
    openLoginModal();
  }

  function unlockPortal() {
    document.getElementById("conteudo").hidden = false;
  }

  function doLogout() {
    currentRole = null;
    currentAccountId = null;
    Store.setCurrentSetor(null);
    saveSession();
    var settingsModal = document.getElementById("settings-modal");
    if (settingsModal.open) settingsModal.close();
    document.getElementById("main-menu-panel").hidden = true;
    lockPortal();
    Store.logout().catch(function (err) { console.error("Falha ao sair:", err); });
  }

  function wireAuth() {
    document.getElementById("login-modal").addEventListener("cancel", function (e) {
      e.preventDefault();
    });

    document.querySelectorAll(".role-picker-btn").forEach(function (btn) {
      btn.addEventListener("click", function () { showLoginCredentialsStep(btn.getAttribute("data-role")); });
    });
    document.getElementById("login-back").addEventListener("click", showLoginRoleStep);

    document.getElementById("main-menu-btn").addEventListener("click", function () {
      document.getElementById("main-menu-panel").hidden = !document.getElementById("main-menu-panel").hidden;
    });
    document.getElementById("ferramentas-btn").addEventListener("click", function () {
      document.getElementById("main-menu-panel").hidden = true;
      viewState = { type: "ferramentas" };
      render();
    });
    document.addEventListener("click", function (e) {
      var wrap = document.getElementById("main-menu-wrap");
      if (!wrap.contains(e.target)) document.getElementById("main-menu-panel").hidden = true;
    });
    document.getElementById("diretor-menu-setores").addEventListener("click", function () {
      document.getElementById("main-menu-panel").hidden = true;
      Store.setCurrentSetor(null);
      saveSession();
      render();
    });
    document.getElementById("diretor-menu-acessos").addEventListener("click", function () {
      document.getElementById("main-menu-panel").hidden = true;
      viewState = { type: "acessos" };
      render();
    });
    document.getElementById("menu-settings").addEventListener("click", function () {
      document.getElementById("main-menu-panel").hidden = true;
      openSettingsModal();
    });
    document.getElementById("menu-theme-toggle").addEventListener("click", function () {
      document.getElementById("main-menu-panel").hidden = true;
      toggleTheme();
    });
    document.getElementById("menu-logout").addEventListener("click", function () {
      document.getElementById("main-menu-panel").hidden = true;
      doLogout();
    });

    document.getElementById("login-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var user = document.getElementById("login-user").value;
      var pass = document.getElementById("login-pass").value;
      var submitBtn = document.getElementById("login-submit");
      var errorEl = document.getElementById("login-error");
      submitBtn.disabled = true;
      errorEl.hidden = true;
      Store.verifyLogin(user, pass).then(function (account) {
        submitBtn.disabled = false;
        if (account && account.role !== selectedLoginRole) {
          errorEl.textContent = "Essa conta não é de " + loginRoleLabel(selectedLoginRole) + ". Verifique o tipo de acesso escolhido.";
          errorEl.hidden = false;
          document.getElementById("login-pass").value = "";
          return;
        }
        if (!account) {
          errorEl.textContent = "Usuário ou senha incorretos.";
          errorEl.hidden = false;
          document.getElementById("login-pass").value = "";
          document.getElementById("login-pass").focus();
          return;
        }
        if (account.needs_email_verification) {
          pendingVerifyAccount = account;
          showLoginOtpStep(account.email);
          Store.sendLoginOtp(account.email).catch(function (err) {
            var otpErrorEl = document.getElementById("login-otp-error");
            otpErrorEl.textContent = "Não foi possível enviar o código. Tente \"Reenviar código\".";
            otpErrorEl.hidden = false;
            console.error(err);
          });
          return;
        }
        completeLogin(account);
      }).catch(function (err) {
        submitBtn.disabled = false;
        errorEl.textContent = "Não foi possível conectar ao banco de dados. Verifique sua internet e tente de novo.";
        errorEl.hidden = false;
        console.error(err);
      });
    });

    document.getElementById("login-otp-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var code = document.getElementById("login-otp-code").value.trim();
      var otpSubmitBtn = document.getElementById("login-otp-submit");
      var otpErrorEl = document.getElementById("login-otp-error");
      otpSubmitBtn.disabled = true;
      otpErrorEl.hidden = true;
      Store.verifyLoginOtp(pendingVerifyAccount.email, code).then(function (ok) {
        otpSubmitBtn.disabled = false;
        if (!ok) {
          otpErrorEl.textContent = "Código incorreto ou expirado. Tente de novo ou peça \"Reenviar código\".";
          otpErrorEl.hidden = false;
          document.getElementById("login-otp-code").value = "";
          document.getElementById("login-otp-code").focus();
          return;
        }
        Store.markEmailVerified();
        completeLogin(pendingVerifyAccount);
      }).catch(function (err) {
        otpSubmitBtn.disabled = false;
        otpErrorEl.textContent = "Não foi possível conferir o código. Verifique sua internet e tente de novo.";
        otpErrorEl.hidden = false;
        console.error(err);
      });
    });

    document.getElementById("login-otp-resend").addEventListener("click", function () {
      if (!pendingVerifyAccount) return;
      var otpErrorEl = document.getElementById("login-otp-error");
      var otpHintEl = document.getElementById("login-otp-hint");
      otpErrorEl.hidden = true;
      otpHintEl.hidden = true;
      Store.sendLoginOtp(pendingVerifyAccount.email).then(function () {
        otpHintEl.hidden = false;
      }).catch(function (err) {
        otpErrorEl.textContent = "Não foi possível reenviar o código.";
        otpErrorEl.hidden = false;
        console.error(err);
      });
    });

    // ---------- "Esqueci a senha" ----------

    document.getElementById("open-forgot-pass").addEventListener("click", showForgotPassEmailStep);
    document.getElementById("forgot-pass-email-back").addEventListener("click", function () {
      showLoginCredentialsStep(selectedLoginRole);
    });

    document.getElementById("forgot-pass-email-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var email = document.getElementById("forgot-pass-email").value.trim();
      var errorEl = document.getElementById("forgot-pass-email-error");
      var submitBtn = document.getElementById("forgot-pass-email-submit");
      errorEl.hidden = true;
      if (!email) {
        errorEl.textContent = "Digite o e-mail da conta.";
        errorEl.hidden = false;
        return;
      }
      submitBtn.disabled = true;
      // Sempre avança pro passo do código, dê ou não dê conta pra esse
      // e-mail — é assim que não dá pra descobrir, só tentando aqui,
      // quais e-mails têm acesso ao portal (ver requestPasswordReset).
      Store.requestPasswordReset(email).then(function () {
        submitBtn.disabled = false;
        showForgotPassResetStep(email);
      }).catch(function (err) {
        submitBtn.disabled = false;
        errorEl.textContent = "Não foi possível conectar ao banco de dados. Verifique sua internet e tente de novo.";
        errorEl.hidden = false;
        console.error(err);
      });
    });

    document.getElementById("forgot-pass-reset-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var code = document.getElementById("forgot-pass-code").value.trim();
      var newPass = document.getElementById("forgot-pass-new").value;
      var confirmPass = document.getElementById("forgot-pass-confirm").value;
      var errorEl = document.getElementById("forgot-pass-reset-error");
      var submitBtn = document.getElementById("forgot-pass-reset-submit");
      errorEl.hidden = true;
      if (newPass.length < 6) {
        errorEl.textContent = "A senha nova precisa ter pelo menos 6 caracteres.";
        errorEl.hidden = false;
        return;
      }
      if (newPass !== confirmPass) {
        errorEl.textContent = "As duas senhas digitadas são diferentes.";
        errorEl.hidden = false;
        return;
      }
      submitBtn.disabled = true;
      Store.confirmPasswordReset(pendingResetEmail, code, newPass).then(function (ok) {
        submitBtn.disabled = false;
        if (!ok) {
          errorEl.textContent = "Código incorreto ou expirado. Tente de novo ou peça \"Reenviar código\".";
          errorEl.hidden = false;
          document.getElementById("forgot-pass-code").value = "";
          document.getElementById("forgot-pass-code").focus();
          return;
        }
        showLoginCredentialsStep(selectedLoginRole);
        document.getElementById("login-reset-success-hint").hidden = false;
      }).catch(function (err) {
        submitBtn.disabled = false;
        errorEl.textContent = /password/i.test(err.message || "")
          ? "Senha muito curta — use pelo menos 6 caracteres."
          : "Não foi possível redefinir a senha. Verifique sua internet e tente de novo.";
        errorEl.hidden = false;
        console.error(err);
      });
    });

    document.getElementById("forgot-pass-resend").addEventListener("click", function () {
      if (!pendingResetEmail) return;
      var errorEl = document.getElementById("forgot-pass-reset-error");
      var hintEl = document.getElementById("forgot-pass-reset-hint");
      errorEl.hidden = true;
      hintEl.hidden = true;
      Store.requestPasswordReset(pendingResetEmail).then(function () {
        hintEl.hidden = false;
      }).catch(function (err) {
        errorEl.textContent = "Não foi possível reenviar o código.";
        errorEl.hidden = false;
        console.error(err);
      });
    });

    var settingsForm = document.getElementById("settings-form");
    settingsForm.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!settingsForm.checkValidity()) { settingsForm.reportValidity(); return; }
      if (!currentAccountId) { document.getElementById("settings-modal").close(); return; }
      var password = document.getElementById("settings-pass").value;
      if (password && Store.passwordChangeNeedsVerification(pendingSettingsAccount)) {
        showSettingsOtpStep(pendingSettingsAccount.email);
        Store.sendLoginOtp(pendingSettingsAccount.email).catch(function (err) {
          var otpErrorEl = document.getElementById("settings-otp-error");
          otpErrorEl.textContent = "Não foi possível enviar o código. Tente \"Reenviar código\".";
          otpErrorEl.hidden = false;
          console.error(err);
        });
        return;
      }
      applySettingsChange();
    });

    document.getElementById("settings-otp-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var code = document.getElementById("settings-otp-code").value.trim();
      var otpSubmitBtn = document.getElementById("settings-otp-submit");
      var otpErrorEl = document.getElementById("settings-otp-error");
      otpSubmitBtn.disabled = true;
      otpErrorEl.hidden = true;
      Store.verifyLoginOtp(pendingSettingsAccount.email, code).then(function (ok) {
        otpSubmitBtn.disabled = false;
        if (!ok) {
          otpErrorEl.textContent = "Código incorreto ou expirado. Tente de novo ou peça \"Reenviar código\".";
          otpErrorEl.hidden = false;
          document.getElementById("settings-otp-code").value = "";
          document.getElementById("settings-otp-code").focus();
          return;
        }
        document.getElementById("settings-otp-form").hidden = true;
        document.getElementById("settings-form").hidden = false;
        applySettingsChange();
      }).catch(function (err) {
        otpSubmitBtn.disabled = false;
        otpErrorEl.textContent = "Não foi possível conferir o código. Verifique sua internet e tente de novo.";
        otpErrorEl.hidden = false;
        console.error(err);
      });
    });

    document.getElementById("settings-otp-resend").addEventListener("click", function () {
      if (!pendingSettingsAccount) return;
      var otpErrorEl = document.getElementById("settings-otp-error");
      var otpHintEl = document.getElementById("settings-otp-hint");
      otpErrorEl.hidden = true;
      otpHintEl.hidden = true;
      Store.sendLoginOtp(pendingSettingsAccount.email).then(function () {
        otpHintEl.hidden = false;
      }).catch(function (err) {
        otpErrorEl.textContent = "Não foi possível reenviar o código.";
        otpErrorEl.hidden = false;
        console.error(err);
      });
    });
  }

  // ---------- color swatches ----------

  function renderColorSwatches(container, selected, onPick) {
    container.innerHTML = "";
    Store.PALETTE_ORDER.forEach(function (name) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "color-swatch" + (name === selected ? " is-selected" : "");
      btn.style.background = gradient(name);
      btn.setAttribute("aria-label", name);
      btn.addEventListener("click", function () {
        container.querySelectorAll(".color-swatch").forEach(function (s) { s.classList.remove("is-selected"); });
        btn.classList.add("is-selected");
        onPick(name);
      });
      container.appendChild(btn);
    });
  }

  // ---------- ícone (imagem customizada) ----------

  function renderIconPreview(prefix, imageDataUrl, color, opts) {
    var preview = document.getElementById(prefix + "-icon-preview");
    var clearBtn = document.getElementById(prefix + "-icon-clear");
    preview.innerHTML = "";
    clearBtn.hidden = !imageDataUrl;
    if (imageDataUrl) {
      var img = document.createElement("img");
      img.src = imageDataUrl;
      img.alt = "";
      preview.appendChild(img);
      return;
    }
    var badge = el("div", "icon-preview-badge", opts.svg || "");
    badge.style.background = gradient(color);
    if (!opts.svg) badge.textContent = opts.text || "";
    preview.appendChild(badge);
  }

  function refreshSystemIconPreview() {
    var tagValue = document.getElementById("sm-tag").value.trim() || fallbackTag(document.getElementById("sm-name").value);
    renderIconPreview("sm", pendingSystemIcon, selectedSystemColor, { text: tagValue });
  }

  function refreshGroupIconPreview() {
    renderIconPreview("gm", pendingGroupIcon, selectedGroupColor, { svg: FOLDER_SVG });
  }

  function refreshSetorIconPreview() {
    renderIconPreview("stm", pendingSetorIcon, selectedSetorColor, { svg: BUILDING_SVG });
  }

  function setupIconPicker(fileId, pickId, clearId, onChange, onClear) {
    var fileInput = document.getElementById(fileId);
    document.getElementById(pickId).addEventListener("click", function () { fileInput.click(); });
    fileInput.addEventListener("change", function (e) {
      var file = e.target.files && e.target.files[0];
      e.target.value = "";
      if (!file) return;
      readImageAsSquareDataUrl(file, 128).then(onChange).catch(function (err) { alert(err.message); });
    });
    document.getElementById(clearId).addEventListener("click", onClear);
  }

  function populateGroupSelect(select, selectedId) {
    select.innerHTML = "";
    Store.getGroups().forEach(function (g) {
      var opt = document.createElement("option");
      opt.value = g.id;
      opt.textContent = g.name;
      if (g.id === selectedId) opt.selected = true;
      select.appendChild(opt);
    });
  }

  // ---------- system modal ----------

  function openSystemModal(systemId, presetGroupId) {
    if (!systemId && Store.getGroups().length === 0) {
      openGroupModal(null);
      return;
    }
    editingSystemId = systemId || null;
    var system = systemId ? Store.getSystem(systemId) : null;

    document.getElementById("system-modal-title").textContent = system ? "Editar sistema" : "Novo sistema";
    document.getElementById("sm-save").textContent = system ? "Salvar alterações" : "Criar sistema";
    document.getElementById("sm-name").value = system ? system.name : "";
    document.getElementById("sm-tag").value = system ? system.tag : "";
    populateGroupSelect(document.getElementById("sm-group"), system ? system.groupId : (presetGroupId || Store.getGroups()[0].id));

    selectedSystemColor = system ? system.color : "blue";
    renderColorSwatches(document.getElementById("sm-colors"), selectedSystemColor, function (c) { selectedSystemColor = c; refreshSystemIconPreview(); });

    pendingSystemIcon = system ? (system.iconImage || null) : null;
    refreshSystemIconPreview();

    pendingDocuments = system ? system.documents.map(function (d) { return { id: d.id, label: d.label, url: d.url, fileName: d.fileName || null, fileSize: d.fileSize || null }; }) : [];
    renderDocumentEditor();

    document.getElementById("sm-delete").hidden = !system;

    var modal = document.getElementById("system-modal");
    modal.showModal();
    document.getElementById("sm-name").focus();
  }

  function renderDocumentEditor() {
    var container = document.getElementById("sm-documents");
    container.innerHTML = "";
    if (pendingDocuments.length === 0) {
      container.appendChild(el("p", "doc-editor-empty", "Nenhum documento ainda. Clique em “+ Adicionar documento”."));
    }
    pendingDocuments.forEach(function (doc, index) {
      var row = el("div", "doc-editor-row");

      var labelInput = document.createElement("input");
      labelInput.type = "text";
      labelInput.className = "field-input doc-editor-label";
      labelInput.placeholder = "Nome (ex: Planilha principal)";
      labelInput.value = doc.label || "";
      labelInput.addEventListener("input", function () { doc.label = labelInput.value; });
      row.appendChild(labelInput);

      if (doc.fileName) {
        var chip = el("div", "doc-editor-file-chip");
        var fileNameSpan = chip.appendChild(el("span", "doc-editor-file-name", ""));
        fileNameSpan.textContent = doc.fileName + " · " + formatFileSize(doc.fileSize);
        fileNameSpan.title = fileNameSpan.textContent;
        var clearFileBtn = document.createElement("button");
        clearFileBtn.type = "button";
        clearFileBtn.className = "btn-link";
        clearFileBtn.textContent = "Remover arquivo";
        clearFileBtn.addEventListener("click", function () {
          doc.url = ""; doc.fileName = null; doc.fileSize = null;
          renderDocumentEditor();
        });
        chip.appendChild(clearFileBtn);
        row.appendChild(chip);
      } else {
        var urlInput = document.createElement("input");
        urlInput.type = "text";
        urlInput.className = "field-input doc-editor-url";
        urlInput.placeholder = "https://... ou anexe um arquivo";
        urlInput.value = doc.url || "";
        urlInput.addEventListener("input", function () { doc.url = urlInput.value; });
        row.appendChild(urlInput);
      }

      var fileInput = document.createElement("input");
      fileInput.type = "file";
      fileInput.hidden = true;

      var attachBtn = document.createElement("button");
      attachBtn.type = "button";
      attachBtn.className = "doc-editor-attach";
      attachBtn.innerHTML = PAPERCLIP_SVG;
      attachBtn.title = "Anexar arquivo";
      attachBtn.setAttribute("aria-label", "Anexar arquivo");
      attachBtn.addEventListener("click", function () { fileInput.click(); });

      // Enquanto o arquivo esta sendo lido (pode demorar um instante em
      // arquivos maiores), o botao fica visivelmente "carregando" — sem
      // isso, a pessoa pode achar que travou e clicar em outro lugar (o
      // que fecha o modal sem querer, parecendo que o anexo "desapareceu").
      fileInput.addEventListener("change", function (e) {
        var file = e.target.files && e.target.files[0];
        if (!file) return;
        attachBtn.disabled = true;
        attachBtn.classList.add("is-loading");
        readFileAsDataUrl(file).then(function (dataUrl) {
          doc.url = dataUrl;
          doc.fileName = file.name;
          doc.fileSize = file.size;
          renderDocumentEditor();
        }).catch(function (err) {
          attachBtn.disabled = false;
          attachBtn.classList.remove("is-loading");
          alert(err.message);
        });
      });

      row.appendChild(attachBtn);
      row.appendChild(fileInput);

      var removeBtn = document.createElement("button");
      removeBtn.type = "button";
      removeBtn.className = "doc-editor-remove";
      removeBtn.setAttribute("aria-label", "Remover documento");
      removeBtn.textContent = "×";
      removeBtn.addEventListener("click", function () {
        pendingDocuments.splice(index, 1);
        renderDocumentEditor();
      });
      row.appendChild(removeBtn);

      container.appendChild(row);
    });
  }

  function saveSystemFromForm() {
    var name = document.getElementById("sm-name").value.trim();
    var tag = document.getElementById("sm-tag").value.trim() || fallbackTag(name);
    var groupId = document.getElementById("sm-group").value;
    var docs = pendingDocuments
      .map(function (d) {
        var url = d.fileName ? d.url : normalizeUrl(d.url);
        return { id: d.id, label: (d.label || "").trim() || "Acessar", url: url, fileName: d.fileName || null, fileSize: d.fileSize || null };
      })
      .filter(function (d) { return d.url; });

    var payload = { name: name, tag: tag, color: selectedSystemColor, iconImage: pendingSystemIcon, groupId: groupId, documents: docs };
    if (editingSystemId) {
      Store.updateSystem(editingSystemId, payload);
    } else {
      Store.createSystem(payload);
    }

    document.getElementById("system-modal").close();
    checkStorageWarning();
    render();
  }

  function wireSystemForm() {
    var form = document.getElementById("system-form");
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      saveSystemFromForm();
    });

    document.getElementById("sm-add-doc").addEventListener("click", function () {
      pendingDocuments.push({ id: Store.uid("doc"), label: "", url: "" });
      renderDocumentEditor();
      var rows = document.querySelectorAll("#sm-documents .doc-editor-label");
      if (rows.length) rows[rows.length - 1].focus();
    });

    document.getElementById("sm-name").addEventListener("input", refreshSystemIconPreview);
    document.getElementById("sm-tag").addEventListener("input", refreshSystemIconPreview);
    setupIconPicker("sm-icon-file", "sm-icon-pick", "sm-icon-clear",
      function (dataUrl) { pendingSystemIcon = dataUrl; refreshSystemIconPreview(); },
      function () { pendingSystemIcon = null; refreshSystemIconPreview(); });

    document.getElementById("sm-delete").addEventListener("click", function () {
      if (!editingSystemId) return;
      var system = Store.getSystem(editingSystemId);
      confirmDialog("Excluir o sistema “" + system.name + "”? Essa ação não pode ser desfeita.", { title: "Excluir sistema", okLabel: "Excluir" })
        .then(function (ok) {
          if (!ok) return;
          var res = Store.deleteSystem(editingSystemId);
          if (!res.ok) return;
          document.getElementById("system-modal").close();
          render();
        });
    });
  }

  // ---------- group modal ----------

  function openGroupModal(groupId) {
    editingGroupId = groupId || null;
    var group = groupId ? Store.getGroup(groupId) : null;

    document.getElementById("group-modal-title").textContent = group ? "Editar grupo" : "Novo grupo";
    document.getElementById("gm-save").textContent = group ? "Salvar alterações" : "Criar grupo";
    document.getElementById("gm-name").value = group ? group.name : "";

    selectedGroupColor = group ? group.color : "blue";
    renderColorSwatches(document.getElementById("gm-colors"), selectedGroupColor, function (c) { selectedGroupColor = c; refreshGroupIconPreview(); });

    pendingGroupIcon = group ? (group.iconImage || null) : null;
    refreshGroupIconPreview();

    var count = group ? Store.countByGroup(group.id) : 0;
    document.getElementById("gm-delete").hidden = !group;
    document.getElementById("gm-hint").hidden = count === 0;

    var modal = document.getElementById("group-modal");
    modal.showModal();
    document.getElementById("gm-name").focus();
  }

  function wireGroupForm() {
    var form = document.getElementById("group-form");
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      var name = document.getElementById("gm-name").value.trim();
      var payload = { name: name, color: selectedGroupColor, iconImage: pendingGroupIcon };

      if (editingGroupId) {
        Store.updateGroup(editingGroupId, payload);
      } else {
        var created = Store.createGroup(payload);
        viewState = { type: "group", groupId: created.id };
      }
      document.getElementById("group-modal").close();
      render();
    });

    document.getElementById("gm-delete").addEventListener("click", function () {
      if (!editingGroupId) return;
      var group = Store.getGroup(editingGroupId);
      confirmDialog("Excluir o grupo “" + group.name + "”?", { title: "Excluir grupo", okLabel: "Excluir" })
        .then(function (ok) {
          if (!ok) return;
          var res = Store.deleteGroup(editingGroupId);
          if (!res.ok) {
            document.getElementById("gm-hint").hidden = false;
            return;
          }
          document.getElementById("group-modal").close();
          if (viewState.type === "group" && viewState.groupId === editingGroupId) viewState = { type: "home" };
          render();
        });
    });

    setupIconPicker("gm-icon-file", "gm-icon-pick", "gm-icon-clear",
      function (dataUrl) { pendingGroupIcon = dataUrl; refreshGroupIconPreview(); },
      function () { pendingGroupIcon = null; refreshGroupIconPreview(); });
  }

  // ---------- setor modal (Painel de Setores, só diretor) ----------

  function openSetorModal(setorId) {
    editingSetorId = setorId || null;
    var setor = setorId ? Store.getSetor(setorId) : null;

    document.getElementById("setor-modal-title").textContent = setor ? "Editar setor" : "Novo setor";
    document.getElementById("stm-save").textContent = setor ? "Salvar alterações" : "Criar setor";
    document.getElementById("stm-nome").value = setor ? setor.nome : "";

    selectedSetorColor = setor ? setor.color : "blue";
    renderColorSwatches(document.getElementById("stm-colors"), selectedSetorColor, function (c) { selectedSetorColor = c; refreshSetorIconPreview(); });

    pendingSetorIcon = setor ? (setor.iconImage || null) : null;
    refreshSetorIconPreview();

    var count = setor ? Store.countGroupsBySetor(setor.id) : 0;
    document.getElementById("stm-delete").hidden = !setor;
    document.getElementById("stm-hint").hidden = count === 0;

    var modal = document.getElementById("setor-modal");
    modal.showModal();
    document.getElementById("stm-nome").focus();
  }

  function wireSetorForm() {
    var form = document.getElementById("setor-form");
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      var nome = document.getElementById("stm-nome").value.trim();

      if (editingSetorId) {
        Store.updateSetor(editingSetorId, { nome: nome, color: selectedSetorColor, iconImage: pendingSetorIcon });
        document.getElementById("setor-modal").close();
        render();
        return;
      }

      // Setor novo nasce sem nenhuma conta — coordenador e visualização só
      // entram depois de o diretor aprovar um pedido de acesso (ver
      // Solicitações de acesso, no Painel de Setores).
      var created = Store.createSetor({ nome: nome, color: selectedSetorColor, iconImage: pendingSetorIcon });
      document.getElementById("setor-modal").close();
      Store.setCurrentSetor(created.id);
      viewState = { type: "home" };
      saveSession();
      render();
    });

    document.getElementById("stm-delete").addEventListener("click", function () {
      if (!editingSetorId) return;
      var setor = Store.getSetor(editingSetorId);
      confirmDialog("Excluir o setor “" + setor.nome + "”? As contas de coordenador e visualização desse setor também serão excluídas.", { title: "Excluir setor", okLabel: "Excluir" })
        .then(function (ok) {
          if (!ok) return;
          var res = Store.deleteSetor(editingSetorId);
          if (!res.ok) {
            document.getElementById("stm-hint").hidden = false;
            return;
          }
          document.getElementById("setor-modal").close();
          render();
        });
    });

    setupIconPicker("stm-icon-file", "stm-icon-pick", "stm-icon-clear",
      function (dataUrl) { pendingSetorIcon = dataUrl; refreshSetorIconPreview(); },
      function () { pendingSetorIcon = null; refreshSetorIconPreview(); });
  }

  // ---------- solicitação de acesso (auto-cadastro, sem precisar estar logado) ----------

  var approvingRequestId = null;

  function openApproveRequestModal(request) {
    approvingRequestId = request.id;
    document.getElementById("arm-email-display").textContent = request.email;
    // A pessoa já preencheu tudo isso no próprio cadastro — só confere
    // (dá pra corrigir um erro de digitação antes de aprovar).
    document.getElementById("arm-name").value = request.name || "";
    document.getElementById("arm-masp").value = request.masp || "";
    document.getElementById("arm-telefone").value = request.telefone || "";
    document.getElementById("arm-cargo").value = request.cargo || "";
    document.getElementById("arm-role").value = "admin";
    document.getElementById("arm-error").hidden = true;

    var setorSelect = document.getElementById("arm-setor");
    setorSelect.innerHTML = "";
    Store.getSetores().forEach(function (s) {
      var opt = document.createElement("option");
      opt.value = s.id;
      opt.textContent = s.nome;
      setorSelect.appendChild(opt);
    });
    if (request.setor_id) setorSelect.value = request.setor_id;

    document.getElementById("approve-request-modal").showModal();
    document.getElementById("arm-name").focus();
  }

  function buildAccessRequestsSection(requests) {
    var section = el("div", "access-requests");
    section.appendChild(el("h3", "access-requests-title", "")).textContent =
      "Solicitações de acesso (" + requests.length + ")";
    var list = el("div", "access-requests-list");
    requests.forEach(function (request) {
      var row = el("div", "access-request-row");
      var label = request.name ? (request.name + " — " + request.email) : request.email;
      row.appendChild(el("span", "access-request-email", "")).textContent = label;

      var actions = el("div", "access-request-actions");
      var approveBtn = document.createElement("button");
      approveBtn.type = "button";
      approveBtn.className = "btn btn-primary";
      approveBtn.textContent = "Cadastrar";
      approveBtn.addEventListener("click", function () { openApproveRequestModal(request); });
      actions.appendChild(approveBtn);

      var dismissBtn = document.createElement("button");
      dismissBtn.type = "button";
      dismissBtn.className = "btn-link";
      dismissBtn.textContent = "Dispensar";
      dismissBtn.addEventListener("click", function () {
        confirmDialog("Dispensar o pedido de acesso de “" + label + "”?", { title: "Dispensar pedido", okLabel: "Dispensar" })
          .then(function (ok) {
            if (!ok) return;
            return Store.dismissAccessRequest(request.id).then(render);
          })
          .catch(function (err) { console.error("Falha ao dispensar pedido:", err); });
      });
      actions.appendChild(dismissBtn);

      row.appendChild(actions);
      list.appendChild(row);
    });
    section.appendChild(list);
    return section;
  }

  // Erros que a Edge Function devolve (ver manage-account, ação
  // "register") — mensagem específica pra cada um, o resto cai no genérico.
  var REGISTER_ERROR_MESSAGES = {
    domain: "O e-mail precisa terminar em @educacao.mg.gov.br.",
    email_taken: "Esse e-mail já tem uma conta cadastrada.",
    request_pending: "Já existe um cadastro pendente com esse e-mail. Aguarde o diretor avaliar.",
    auth_create_failed: "Não foi possível concluir o cadastro (verifique a senha escolhida). Tente de novo.",
  };

  function wireAccessRequests() {
    document.getElementById("open-request-access").addEventListener("click", function () {
      document.getElementById("request-access-form").reset();
      document.getElementById("ram-error").hidden = true;
      document.getElementById("ram-form-body").hidden = false;
      document.getElementById("ram-success-body").hidden = true;
      document.getElementById("ram-submit").hidden = false;
      var setorSelect = document.getElementById("ram-setor");
      setorSelect.innerHTML = "<option value=\"\">Carregando…</option>";
      Store.getSetoresPublic().then(function (setores) {
        setorSelect.innerHTML = "";
        setores.forEach(function (s) {
          var opt = document.createElement("option");
          opt.value = s.id;
          opt.textContent = s.nome;
          setorSelect.appendChild(opt);
        });
      }).catch(function (err) {
        setorSelect.innerHTML = "<option value=\"\">Não foi possível carregar os setores</option>";
        console.error("Falha ao carregar setores:", err);
      });
      document.getElementById("request-access-modal").showModal();
    });

    var requestForm = document.getElementById("request-access-form");
    requestForm.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!requestForm.checkValidity()) { requestForm.reportValidity(); return; }
      var ramErrorEl = document.getElementById("ram-error");
      var submitBtn = document.getElementById("ram-submit");
      var pass = document.getElementById("ram-pass").value;
      var passConfirm = document.getElementById("ram-pass-confirm").value;
      if (pass !== passConfirm) {
        ramErrorEl.textContent = "As senhas não conferem.";
        ramErrorEl.hidden = false;
        return;
      }
      ramErrorEl.hidden = true;
      submitBtn.disabled = true;
      Store.requestAccess({
        name: document.getElementById("ram-name").value,
        masp: document.getElementById("ram-masp").value,
        telefone: document.getElementById("ram-telefone").value,
        cargo: document.getElementById("ram-cargo").value,
        email: document.getElementById("ram-email").value,
        setorId: document.getElementById("ram-setor").value,
        password: pass,
      }).then(function () {
        submitBtn.disabled = false;
        document.getElementById("ram-form-body").hidden = true;
        document.getElementById("ram-success-body").hidden = false;
        submitBtn.hidden = true;
      }).catch(function (err) {
        submitBtn.disabled = false;
        ramErrorEl.textContent = REGISTER_ERROR_MESSAGES[err.message] || "Não foi possível enviar o cadastro. Tente de novo.";
        ramErrorEl.hidden = false;
        console.error(err);
      });
    });

    var approveForm = document.getElementById("approve-request-form");
    approveForm.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!approveForm.checkValidity()) { approveForm.reportValidity(); return; }
      if (!approvingRequestId) return;
      var armErrorEl = document.getElementById("arm-error");
      var submitBtn = approveForm.querySelector("button[type=submit]");
      armErrorEl.hidden = true;
      submitBtn.disabled = true;
      Store.approveAccessRequest(approvingRequestId, {
        name: document.getElementById("arm-name").value.trim(),
        masp: document.getElementById("arm-masp").value.trim(),
        telefone: document.getElementById("arm-telefone").value.trim(),
        cargo: document.getElementById("arm-cargo").value.trim(),
        email: document.getElementById("arm-email-display").textContent,
        setorId: document.getElementById("arm-setor").value,
        role: document.getElementById("arm-role").value,
      }).then(function () {
        submitBtn.disabled = false;
        document.getElementById("approve-request-modal").close();
        render();
      }).catch(function (err) {
        submitBtn.disabled = false;
        armErrorEl.textContent = "Não foi possível cadastrar (talvez esse e-mail já tenha conta). Tente de novo.";
        armErrorEl.hidden = false;
        console.error(err);
      });
    });
  }

  // ---------- servidores do setor (cadastro direto + lista) ----------

  function openAddServidorModal() {
    document.getElementById("asm-name").value = "";
    document.getElementById("asm-masp").value = "";
    document.getElementById("asm-telefone").value = "";
    document.getElementById("asm-cargo").value = "";
    document.getElementById("asm-email").value = "";
    document.getElementById("asm-role").value = "admin";
    document.getElementById("asm-pass").value = "";
    document.getElementById("asm-error").hidden = true;
    document.getElementById("add-servidor-modal").showModal();
    document.getElementById("asm-name").focus();
  }

  function wireAddServidorForm() {
    var form = document.getElementById("add-servidor-form");
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      var email = document.getElementById("asm-email").value.trim();
      var errorEl = document.getElementById("asm-error");
      if (!Store.isInstitutionalEmail(email)) {
        errorEl.textContent = "O e-mail precisa terminar em @educacao.mg.gov.br.";
        errorEl.hidden = false;
        return;
      }
      errorEl.hidden = true;
      var submitBtn = form.querySelector("button[type=submit]");
      submitBtn.disabled = true;
      Store.createServidor({
        name: document.getElementById("asm-name").value.trim(),
        masp: document.getElementById("asm-masp").value.trim(),
        telefone: document.getElementById("asm-telefone").value.trim(),
        cargo: document.getElementById("asm-cargo").value.trim(),
        email: email,
        setorId: Store.getCurrentSetor(),
        role: document.getElementById("asm-role").value,
        password: document.getElementById("asm-pass").value,
      }).then(function () {
        submitBtn.disabled = false;
        document.getElementById("add-servidor-modal").close();
        render();
      }).catch(function (err) {
        submitBtn.disabled = false;
        errorEl.textContent = "Não foi possível cadastrar (talvez esse e-mail já tenha conta). Tente de novo.";
        errorEl.hidden = false;
        console.error(err);
      });
    });
  }

  function buildServidorRow(account) {
    var row = el("div", "servidor-row");
    var info = el("div", "servidor-info");
    info.appendChild(el("div", "servidor-name", "")).textContent = account.name || "(sem nome)";
    var detailBits = [];
    if (account.cargo) detailBits.push(account.cargo);
    detailBits.push(account.email || account.id);
    if (account.masp) detailBits.push("MASP " + account.masp);
    if (account.telefone) detailBits.push(account.telefone);
    info.appendChild(el("div", "servidor-detail", "")).textContent = detailBits.join(" · ");
    row.appendChild(info);

    var removeBtn = document.createElement("button");
    removeBtn.type = "button";
    removeBtn.className = "btn-link";
    removeBtn.textContent = "Remover";
    removeBtn.addEventListener("click", function () {
      confirmDialog("Remover o acesso de “" + (account.name || account.email || account.id) + "”?", { title: "Remover servidor", okLabel: "Remover" })
        .then(function (ok) {
          if (!ok) return;
          return Store.deleteAccount(account.id).then(render);
        })
        .catch(function (err) { console.error("Falha ao remover conta:", err); });
    });
    row.appendChild(removeBtn);
    return row;
  }

  // Busca a lista ao vivo no banco (não é mais um cache local) — devolve
  // o "wrap" na hora, com um aviso de carregando, e preenche assim que a
  // resposta chegar. É a mesma troca feita em toda a autenticação: só
  // vem dados de quem o RLS deixar (o próprio coordenador do setor, ou
  // diretor), então não dá mais pra montar isso de forma síncrona a
  // partir de um estado já carregado.
  function renderServidoresView() {
    var wrap = el("div", "servidores-view");
    wrap.appendChild(el("p", "tools-empty", "Carregando…"));
    var setorId = Store.getCurrentSetor();
    Store.getSectorAccounts(setorId).then(function (accounts) {
      wrap.innerHTML = "";
      var coordenadores = accounts.filter(function (a) { return a.role === "admin"; });
      var servidores = accounts.filter(function (a) { return a.role === "viewer"; });

      wrap.appendChild(el("h3", "servidores-group-title", "")).textContent = "Coordenador" + (coordenadores.length === 1 ? "" : "es");
      var coordList = el("div", "servidores-list");
      if (coordenadores.length === 0) coordList.appendChild(el("p", "tools-empty", "Nenhum coordenador cadastrado ainda."));
      coordenadores.forEach(function (a) { coordList.appendChild(buildServidorRow(a)); });
      wrap.appendChild(coordList);

      wrap.appendChild(el("h3", "servidores-group-title", "")).textContent = "Servidores";
      var servList = el("div", "servidores-list");
      if (servidores.length === 0) servList.appendChild(el("p", "tools-empty", "Nenhum servidor cadastrado ainda."));
      servidores.forEach(function (a) { servList.appendChild(buildServidorRow(a)); });
      wrap.appendChild(servList);

      var addBtn = document.createElement("button");
      addBtn.type = "button";
      addBtn.className = "btn btn-primary";
      addBtn.textContent = "+ Cadastrar servidor";
      addBtn.addEventListener("click", openAddServidorModal);
      wrap.appendChild(addBtn);
    }).catch(function (err) {
      wrap.innerHTML = "";
      wrap.appendChild(el("p", "field-error", "Não foi possível carregar os servidores."));
      console.error(err);
    });
    return wrap;
  }

  // ---------- Gerenciar acessos (promover/revogar coordenador) ----------

  function acessoRoleLabel(role) {
    if (role === "diretor") return "Diretor";
    if (role === "admin") return "Coordenador";
    return "Servidor";
  }

  // Confirma e aplica a troca de papel (servidor <-> coordenador) — usada
  // tanto pelo botão da coluna Ação quanto pela própria "caixinha" do
  // papel (clicar nela faz a mesma coisa, é só um atalho).
  function triggerRoleChange(account, setor, promoting) {
    var nomeOuEmail = account.name || account.email || account.id;
    var novoPapel = promoting ? "admin" : "viewer";
    var pergunta = promoting
      ? "Tornar “" + nomeOuEmail + "” coordenador" + (setor ? " do " + setor.nome : "") + "?"
      : "Revogar o acesso de coordenador de “" + nomeOuEmail + "”? A conta passa a ser servidor (visualização).";
    confirmDialog(pergunta, { title: promoting ? "Tornar coordenador" : "Revogar coordenador", okLabel: promoting ? "Tornar coordenador" : "Revogar" })
      .then(function (ok) {
        if (!ok) return;
        return Store.setAccountRole(account.id, novoPapel).then(render);
      })
      .catch(function (err) { console.error("Falha ao trocar o papel da conta:", err); });
  }

  // Diretor não aparece com botão de ação aqui (nem a caixinha de papel
  // fica clicável): trocar pra/de diretor continua sendo só um passo
  // manual no SQL (ver README) — a Edge Function nem aceita isso
  // (set_role recusa qualquer conta que não seja admin/viewer). Só monta
  // os controles pros outros dois papéis.
  function buildAcessoRow(account) {
    var row = document.createElement("tr");
    row.className = "acessos-row";

    var tdNome = document.createElement("td");
    tdNome.textContent = account.name || "(sem nome)";
    row.appendChild(tdNome);

    var tdEmail = document.createElement("td");
    tdEmail.textContent = account.email || account.auth_email || account.id;
    row.appendChild(tdEmail);

    var setor = Store.getSetor(account.setor_id);
    var tdSetor = document.createElement("td");
    tdSetor.textContent = setor ? setor.nome : "—";
    row.appendChild(tdSetor);

    var canChangeRole = account.role === "admin" || account.role === "viewer";
    var promoting = account.role === "viewer";

    var tdPapel = document.createElement("td");
    var papelNode;
    if (canChangeRole) {
      papelNode = document.createElement("button");
      papelNode.type = "button";
      papelNode.title = promoting ? "Tornar coordenador" : "Revogar coordenador";
      papelNode.addEventListener("click", function () { triggerRoleChange(account, setor, promoting); });
    } else {
      papelNode = document.createElement("span");
    }
    papelNode.className = "role-badge role-badge-" + account.role;
    papelNode.textContent = acessoRoleLabel(account.role);
    tdPapel.appendChild(papelNode);
    row.appendChild(tdPapel);

    var tdAcao = document.createElement("td");
    tdAcao.className = "acessos-col-acao";
    if (canChangeRole) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "btn-link";
      btn.textContent = promoting ? "Tornar coordenador" : "Revogar coordenador";
      btn.addEventListener("click", function () { triggerRoleChange(account, setor, promoting); });
      tdAcao.appendChild(btn);
    } else {
      tdAcao.textContent = "—";
    }
    row.appendChild(tdAcao);

    return row;
  }

  // Busca ao vivo, sem filtro de setor (ver Store.getAllAccounts) — a RLS
  // já devolve só o que cada papel pode ver, então o mesmo fetch serve
  // tanto pro diretor (todo mundo, com filtro opcional por setor) quanto
  // pro coordenador (só o próprio setor, sem filtro nenhum).
  function renderAcessosView() {
    var wrap = el("div", "acessos-view");
    var diretorWide = isDiretorRole();

    if (diretorWide) {
      var filterField = el("label", "field acessos-filter-field");
      filterField.appendChild(el("span", "field-label", "")).textContent = "Setor";
      var select = document.createElement("select");
      select.className = "field-input";
      select.id = "acessos-setor-filter";
      var allOpt = document.createElement("option");
      allOpt.value = "";
      allOpt.textContent = "Todos os setores";
      select.appendChild(allOpt);
      Store.getSetores().forEach(function (s) {
        var opt = document.createElement("option");
        opt.value = s.id;
        opt.textContent = s.nome;
        select.appendChild(opt);
      });
      select.value = acessosFilterSetorId || "";
      select.addEventListener("change", function () {
        acessosFilterSetorId = select.value || null;
        render();
      });
      filterField.appendChild(select);
      wrap.appendChild(filterField);
    }

    var tableWrap = el("div", "acessos-table-wrap");
    tableWrap.appendChild(el("p", "tools-empty", "Carregando…"));
    wrap.appendChild(tableWrap);

    Store.getAllAccounts().then(function (accounts) {
      tableWrap.innerHTML = "";
      var rows = accounts.filter(function (a) {
        return !diretorWide || !acessosFilterSetorId || a.setor_id === acessosFilterSetorId;
      });
      rows.sort(function (a, b) {
        var setorA = (Store.getSetor(a.setor_id) || {}).nome || "";
        var setorB = (Store.getSetor(b.setor_id) || {}).nome || "";
        if (setorA !== setorB) return setorA.localeCompare(setorB, "pt-BR");
        return (a.name || "").localeCompare(b.name || "", "pt-BR");
      });

      if (rows.length === 0) {
        tableWrap.appendChild(el("p", "tools-empty", "Nenhuma conta encontrada."));
        return;
      }

      var table = document.createElement("table");
      table.className = "acessos-table";
      var thead = document.createElement("thead");
      var headRow = document.createElement("tr");
      ["Nome", "E-mail", "Setor", "Papel", "Ação"].forEach(function (label) {
        var th = document.createElement("th");
        th.textContent = label;
        headRow.appendChild(th);
      });
      thead.appendChild(headRow);
      table.appendChild(thead);

      var tbody = document.createElement("tbody");
      rows.forEach(function (a) { tbody.appendChild(buildAcessoRow(a)); });
      table.appendChild(tbody);

      tableWrap.appendChild(table);
    }).catch(function (err) {
      tableWrap.innerHTML = "";
      tableWrap.appendChild(el("p", "field-error", "Não foi possível carregar as contas."));
      console.error(err);
    });

    return wrap;
  }

  // ---------- doc picker ----------

  function openDocPicker(system) {
    document.getElementById("doc-picker-title").textContent = system.name;
    var list = document.getElementById("doc-picker-list");
    list.innerHTML = "";
    var modal = document.getElementById("doc-picker-modal");

    system.documents.forEach(function (doc) {
      var link = document.createElement("a");
      link.className = "doc-picker-item";
      link.href = doc.url;
      if (doc.fileName) {
        link.download = doc.fileName;
      } else {
        link.target = "_blank";
        link.rel = "noopener noreferrer";
      }
      link.addEventListener("click", function () { setTimeout(function () { modal.close(); }, 30); });

      link.appendChild(el("span", "doc-picker-label", "")).textContent = doc.label || "Acessar";
      link.appendChild(el("span", "doc-picker-url", "")).textContent = doc.fileName ? (doc.fileName + " · " + formatFileSize(doc.fileSize)) : shortenUrl(doc.url);
      list.appendChild(link);
    });

    modal.showModal();
  }

  function openDocument(doc) {
    if (doc.fileName) triggerDownload(doc.url, doc.fileName);
    else window.open(doc.url, "_blank", "noopener,noreferrer");
  }

  function openSystem(system) {
    if (system.internalTool) { viewState = { type: "tool", toolId: system.internalTool }; render(); return; }
    var docs = system.documents || [];
    if (docs.length === 0) { if (isAdmin()) openSystemModal(system.id); return; }
    if (docs.length === 1) { openDocument(docs[0]); return; }
    openDocPicker(system);
  }

  // ---------- tile builders ----------

  function buildSystemTile(system, opts) {
    opts = opts || {};
    var isTool = !!system.internalTool;
    var card = el("div", "tool-card" + (!isTool && system.documents.length === 0 ? " is-empty-doc" : ""));
    card.tabIndex = 0;
    card.setAttribute("role", "button");
    card.title = isTool || system.documents.length
      ? "Abrir " + system.name
      : (isAdmin() ? "Adicionar link em " + system.name : "Link não disponível");

    var badge = el("div", "tool-badge", "");
    if (system.iconImage) {
      var badgeImg = document.createElement("img");
      badgeImg.src = system.iconImage;
      badgeImg.alt = "";
      badge.appendChild(badgeImg);
    } else {
      badge.style.background = gradient(system.color);
      badge.textContent = system.tag;
    }
    card.appendChild(badge);

    card.appendChild(el("div", "tool-name", "")).textContent = system.name;

    if (opts.showGroup) {
      var group = Store.getGroup(system.groupId);
      if (group) card.appendChild(el("div", "tool-group-label", "")).textContent = group.name;
    }

    if (isTool) {
      card.appendChild(el("span", "tool-doc-count", "")).textContent = "Ferramenta";
    } else if (system.documents.length === 0) {
      card.appendChild(el("span", "tool-pending-pill", "Sem link"));
    } else if (system.documents.length > 1) {
      card.appendChild(el("span", "tool-doc-count", "")).textContent = system.documents.length + " links";
    } else {
      card.appendChild(buildExternalIcon());
    }

    if (isAdmin()) {
      var editBtn = el("button", "tile-edit-btn", PENCIL_SVG);
      editBtn.type = "button";
      editBtn.setAttribute("aria-label", "Editar " + system.name);
      editBtn.addEventListener("click", function (e) { e.stopPropagation(); openSystemModal(system.id); });
      card.appendChild(editBtn);
    }

    card.addEventListener("click", function () { openSystem(system); });
    card.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openSystem(system); }
    });

    return card;
  }

  function buildGroupTile(group) {
    var count = Store.countByGroup(group.id);
    var card = el("div", "group-card");
    card.tabIndex = 0;
    card.setAttribute("role", "button");
    card.title = "Abrir grupo " + group.name;
    card.style.setProperty("--group-accent", (Store.PALETTE[group.color] || Store.PALETTE.blue).from);

    var badge = el("div", "group-badge", group.iconImage ? "" : FOLDER_SVG);
    if (group.iconImage) {
      var badgeImg = document.createElement("img");
      badgeImg.src = group.iconImage;
      badgeImg.alt = "";
      badge.appendChild(badgeImg);
    } else {
      badge.style.background = gradient(group.color);
    }
    card.appendChild(badge);

    card.appendChild(el("div", "group-name", "")).textContent = group.name;
    card.appendChild(el("div", "group-count", "")).textContent = count + (count === 1 ? " sistema" : " sistemas");

    if (isAdmin()) {
      var editBtn = el("button", "tile-edit-btn", PENCIL_SVG);
      editBtn.type = "button";
      editBtn.setAttribute("aria-label", "Editar grupo " + group.name);
      editBtn.addEventListener("click", function (e) { e.stopPropagation(); openGroupModal(group.id); });
      card.appendChild(editBtn);
    }

    card.addEventListener("click", function () { viewState = { type: "group", groupId: group.id }; render(); });
    card.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); viewState = { type: "group", groupId: group.id }; render(); }
    });

    return card;
  }

  // Arrastar e soltar um card de setor sobre outro no Painel: o arrastado
  // entra na posição de quem recebeu o drop (empurrando o resto) — persiste
  // via Store.reorderSetores e redesenha com a ordem nova.
  //
  // O render() (que apaga e reconstrói todo #view-root) só acontece depois
  // de um setTimeout(0), nunca direto dentro do "drop": o navegador ainda
  // não disparou "dragend" no card arrastado nesse momento (drop vem antes
  // de dragend) — apagar esse card do DOM enquanto o drag nativo dele
  // ainda está "em andamento" deixa a imagem fantasma do arraste solta na
  // tela (o próprio Chrome perde a referência do elemento origem). Dar essa
  // folga de um tick deixa o navegador terminar o ciclo nativo primeiro.
  function reorderSetorCards(draggedId, targetId) {
    var ids = Store.getSetores().map(function (s) { return s.id; });
    var fromIndex = ids.indexOf(draggedId);
    if (fromIndex === -1) return;
    ids.splice(fromIndex, 1);
    var toIndex = ids.indexOf(targetId);
    ids.splice(toIndex, 0, draggedId);
    Store.reorderSetores(ids);
    setTimeout(render, 0);
  }

  function buildSetorTile(setor) {
    var count = Store.countGroupsBySetor(setor.id);
    var card = el("div", "group-card setor-tile");
    card.tabIndex = 0;
    card.setAttribute("role", "button");
    card.title = "Abrir setor " + setor.nome + " (clique e arraste pra reordenar)";
    card.style.setProperty("--group-accent", (Store.PALETTE[setor.color] || Store.PALETTE.blue).from);

    card.draggable = true;
    card.addEventListener("dragstart", function (e) {
      draggedSetorId = setor.id;
      card.classList.add("is-dragging");
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", setor.id);
    });
    card.addEventListener("dragend", function () {
      card.classList.remove("is-dragging");
      draggedSetorId = null;
    });
    card.addEventListener("dragover", function (e) {
      if (!draggedSetorId || draggedSetorId === setor.id) return;
      e.preventDefault();
      card.classList.add("drag-over");
    });
    card.addEventListener("dragleave", function () { card.classList.remove("drag-over"); });
    card.addEventListener("drop", function (e) {
      e.preventDefault();
      card.classList.remove("drag-over");
      if (!draggedSetorId || draggedSetorId === setor.id) return;
      reorderSetorCards(draggedSetorId, setor.id);
    });

    var badge = el("div", "group-badge", setor.iconImage ? "" : BUILDING_SVG);
    if (setor.iconImage) {
      var badgeImg = document.createElement("img");
      badgeImg.src = setor.iconImage;
      badgeImg.alt = "";
      badge.appendChild(badgeImg);
    } else {
      badge.style.background = gradient(setor.color);
    }
    card.appendChild(badge);

    card.appendChild(el("div", "group-name", "")).textContent = setor.nome;
    card.appendChild(el("div", "group-count", "")).textContent = count + (count === 1 ? " grupo" : " grupos");

    var editBtn = el("button", "tile-edit-btn", PENCIL_SVG);
    editBtn.type = "button";
    editBtn.setAttribute("aria-label", "Editar setor " + setor.nome);
    editBtn.addEventListener("click", function (e) { e.stopPropagation(); openSetorModal(setor.id); });
    card.appendChild(editBtn);

    function enter() {
      Store.setCurrentSetor(setor.id);
      viewState = { type: "home" };
      saveSession();
      render();
    }
    card.addEventListener("click", enter);
    card.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); enter(); }
    });

    return card;
  }

  function buildAddTile(label, onClick) {
    var card = document.createElement("button");
    card.type = "button";
    card.className = "add-tile";
    card.innerHTML = PLUS_SVG + '<span>' + label + '</span>';
    card.addEventListener("click", onClick);
    return card;
  }

  // ---------- views ----------

  function searchSystems(query) {
    var norm = normalize(query);
    return Store.getSystems().filter(function (s) { return normalize(s.name).indexOf(norm) !== -1; });
  }

  function renderHomeView() {
    var wrap = el("div");
    var grid = el("div", "groups-grid");
    Store.getGroups().forEach(function (g) { grid.appendChild(buildGroupTile(g)); });
    if (isAdmin()) grid.appendChild(buildAddTile("Novo grupo", function () { openGroupModal(null); }));
    wrap.appendChild(grid);
    return wrap;
  }

  function renderPainelView() {
    var wrap = el("div");
    var requests = Store.getAccessRequests();
    if (requests.length > 0) wrap.appendChild(buildAccessRequestsSection(requests));
    var grid = el("div", "groups-grid");
    Store.getSetores().forEach(function (s) { grid.appendChild(buildSetorTile(s)); });
    wrap.appendChild(grid);
    return wrap;
  }

  // Cabeçalho mostra o nome do setor atual (ou "Painel de Setores" pro
  // diretor sem nenhum setor aberto) no lugar do subtítulo fixo, já que o
  // mesmo portal agora atende setores diferentes.
  function updateBrandSubtitle() {
    var subEl = document.getElementById("brand-org-sub");
    if (!subEl) return;
    if (isPainelMode()) { subEl.textContent = "Painel de Setores"; return; }
    var setor = Store.getSetor(Store.getCurrentSetor());
    subEl.textContent = setor ? setor.nome : "";
  }

  function renderGroupView(group) {
    var wrap = el("div");
    var grid = el("div", "tools-grid");
    Store.getSystemsByGroup(group.id).forEach(function (s) { grid.appendChild(buildSystemTile(s, {})); });
    if (isAdmin()) grid.appendChild(buildAddTile("Adicionar sistema", function () { openSystemModal(null, group.id); }));
    wrap.appendChild(grid);
    return wrap;
  }

  function renderResultsView(results) {
    var wrap = el("div");
    if (results.length === 0) {
      wrap.appendChild(el("p", "tools-empty", "Nenhum sistema encontrado para essa busca."));
      return wrap;
    }
    var grid = el("div", "tools-grid");
    results.forEach(function (s) { grid.appendChild(buildSystemTile(s, { showGroup: true })); });
    wrap.appendChild(grid);
    return wrap;
  }

  function renderToolbar(mode, payload) {
    var toolbar = document.getElementById("toolbar-title");
    toolbar.innerHTML = "";
    document.getElementById("btn-add-system").hidden = mode !== "group" || !isAdmin();
    document.getElementById("btn-add-setor").hidden = mode !== "painel";
    document.getElementById("btn-servidores").hidden = mode !== "home" || !isAdmin();
    // Botão só pro coordenador — o diretor chega em "Gerenciar acessos"
    // pelo menu ☰ (visível em qualquer setor, ou no Painel).
    document.getElementById("btn-acessos").hidden = mode !== "home" || currentRole !== "admin";

    if (mode === "painel") {
      toolbar.appendChild(el("span", "toolbar-heading", "")).textContent = "Painel de Setores";
      var setorCount = Store.getSetores().length;
      toolbar.appendChild(el("span", "toolbar-count", "")).textContent = setorCount + (setorCount === 1 ? " setor" : " setores");
      return;
    }

    if (mode === "search") {
      toolbar.appendChild(el("span", "toolbar-heading", "")).textContent = "Resultados da busca";
      toolbar.appendChild(el("span", "toolbar-count", "")).textContent = payload + (payload === 1 ? " sistema" : " sistemas");
      return;
    }

    if (mode === "group") {
      var back = document.createElement("button");
      back.type = "button";
      back.className = "btn-back";
      back.innerHTML = BACK_SVG + "Todos os grupos";
      back.addEventListener("click", function () { viewState = { type: "home" }; render(); });
      toolbar.appendChild(back);
      toolbar.appendChild(el("span", "toolbar-sep", "/"));
      toolbar.appendChild(el("span", "toolbar-heading", "")).textContent = payload.name;

      if (isAdmin()) {
        var editBtn = el("button", "icon-btn", PENCIL_SVG);
        editBtn.type = "button";
        editBtn.setAttribute("aria-label", "Editar grupo");
        editBtn.addEventListener("click", function () { openGroupModal(payload.id); });
        toolbar.appendChild(editBtn);
      }

      var count = Store.countByGroup(payload.id);
      toolbar.appendChild(el("span", "toolbar-count", "")).textContent = count + (count === 1 ? " sistema" : " sistemas");
      return;
    }

    if (mode === "tool") {
      var toolInfo = FERRAMENTAS_CATALOGO.filter(function (f) { return f.id === payload; })[0];
      var toolBack = document.createElement("button");
      toolBack.type = "button";
      toolBack.className = "btn-back";
      toolBack.innerHTML = BACK_SVG + "Ferramentas";
      toolBack.addEventListener("click", function () { viewState = { type: "ferramentas" }; render(); });
      toolbar.appendChild(toolBack);
      toolbar.appendChild(el("span", "toolbar-sep", "/"));
      toolbar.appendChild(el("span", "toolbar-heading", "")).textContent = toolInfo ? toolInfo.nome : "Ferramenta";
      return;
    }

    if (mode === "ferramentas") {
      var fBack = document.createElement("button");
      fBack.type = "button";
      fBack.className = "btn-back";
      fBack.innerHTML = BACK_SVG + "Voltar";
      fBack.addEventListener("click", function () { viewState = { type: "home" }; render(); });
      toolbar.appendChild(fBack);
      toolbar.appendChild(el("span", "toolbar-sep", "/"));
      toolbar.appendChild(el("span", "toolbar-heading", "")).textContent = "Ferramentas";
      return;
    }

    if (mode === "servidores") {
      var servBack = document.createElement("button");
      servBack.type = "button";
      servBack.className = "btn-back";
      servBack.innerHTML = BACK_SVG + "Voltar";
      servBack.addEventListener("click", function () { viewState = { type: "home" }; render(); });
      toolbar.appendChild(servBack);
      toolbar.appendChild(el("span", "toolbar-sep", "/"));
      toolbar.appendChild(el("span", "toolbar-heading", "")).textContent = "Servidores";
      return;
    }

    if (mode === "acessos") {
      var acessosBack = document.createElement("button");
      acessosBack.type = "button";
      acessosBack.className = "btn-back";
      acessosBack.innerHTML = BACK_SVG + "Voltar";
      acessosBack.addEventListener("click", function () { viewState = { type: "home" }; render(); });
      toolbar.appendChild(acessosBack);
      toolbar.appendChild(el("span", "toolbar-sep", "/"));
      toolbar.appendChild(el("span", "toolbar-heading", "")).textContent = "Gerenciar acessos";
      return;
    }

    var groups = Store.getGroups().length;
    var systems = Store.getSystems().length;

    if (isDiretorRole() && Store.getCurrentSetor() !== null) {
      var backToPainel = document.createElement("button");
      backToPainel.type = "button";
      backToPainel.className = "btn-back";
      backToPainel.innerHTML = BACK_SVG + "Painel de Setores";
      backToPainel.addEventListener("click", function () { Store.setCurrentSetor(null); saveSession(); render(); });
      toolbar.appendChild(backToPainel);
      toolbar.appendChild(el("span", "toolbar-sep", "/"));
      var currentSetor = Store.getSetor(Store.getCurrentSetor());
      toolbar.appendChild(el("span", "toolbar-heading", "")).textContent = currentSetor ? currentSetor.nome : "Setor";
      toolbar.appendChild(el("span", "toolbar-count", "")).textContent =
        groups + (groups === 1 ? " grupo" : " grupos") + " · " + systems + (systems === 1 ? " sistema" : " sistemas");
      return;
    }

    toolbar.appendChild(el("span", "toolbar-heading", "")).textContent =
      groups + (groups === 1 ? " grupo" : " grupos") + " · " + systems + (systems === 1 ? " sistema" : " sistemas");
  }

  // Catálogo fixo da aba Ferramentas — crescer esse catálogo é só
  // adicionar uma entrada aqui (e no TOOL_MODULES logo abaixo) com o
  // módulo que expõe buildView(canEdit); não depende mais de nenhum
  // "sistema" criado num grupo (ver migração 20261014000000).
  var WRENCH_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76Z"></path></svg>';
  var FERRAMENTAS_CATALOGO = [
    { id: "sicalc", nome: "Calculadora de Pagamento", descricao: "Calcula vencimento, contribuição previdenciária (INSS/RPPS) e desconto IPSEMG a partir dos parâmetros do ano." },
    { id: "leitor-diario", nome: "Leitor do Diário", descricao: "Lê PDFs do Diário do Executivo de MG e extrai os atos de pessoal (férias-prêmio, licenças, afastamentos, designações etc)." },
  ];

  var TOOL_MODULES = {
    sicalc: function () { return typeof Sicalc !== "undefined" ? Sicalc : null; },
    // LeitorDiario carrega como <script type="module"> (ver index.html) —
    // pode ainda não existir no "window" se o navegador ainda não acabou
    // de avaliar aquele módulo; buildToolView trata isso como "ferramenta
    // indisponível" até carregar, igual qualquer outro módulo ausente.
    "leitor-diario": function () { return typeof LeitorDiario !== "undefined" ? LeitorDiario : null; },
  };

  function buildToolView(toolId) {
    var mod = TOOL_MODULES[toolId] && TOOL_MODULES[toolId]();
    if (mod && mod.buildView) return mod.buildView(isAdmin());
    return el("p", "tools-empty", "Essa ferramenta não está disponível.");
  }

  // Setor atual tem acesso concedido a essa ferramenta? Diretor "dentro"
  // de um setor sempre tem (mesmo poder de admin que já tem em tudo mais
  // dentro de um setor) — só o Painel (nenhum setor aberto) não conta como
  // "dentro", porque aí não tem setor nenhum pra checar.
  function setorAtualTemAcesso(toolId, acessos) {
    var setorId = Store.getCurrentSetor();
    if (!setorId) return false;
    if (isDiretorRole()) return true;
    return acessos.some(function (a) { return a.ferramentaId === toolId && a.setorId === setorId; });
  }

  function renderFerramentasView() {
    var wrap = el("div", "ferramentas-view");
    var acessos = Store.getFerramentaAcessos();
    var gerenciar = isDiretorRole() && Store.getCurrentSetor() === null;

    if (!gerenciar) {
      wrap.appendChild(renderFerramentasAbertas(acessos));
      return wrap;
    }

    var loading = el("p", "tools-empty", "Carregando…");
    wrap.appendChild(loading);
    Store.getAllAccounts().then(function (accounts) {
      wrap.innerHTML = "";
      wrap.appendChild(renderFerramentasGerenciar(acessos, accounts));
    }).catch(function (err) {
      wrap.innerHTML = "";
      wrap.appendChild(el("p", "field-error", "Não foi possível carregar quem tem acesso. Verifique sua internet e recarregue a página."));
      console.error("Falha ao carregar accounts pra Ferramentas:", err);
    });

    return wrap;
  }

  // Visão de quem usa (coordenador/servidor sempre; diretor quando está
  // "dentro" de um setor) — só os cards das ferramentas liberadas pro
  // setor atual, clicáveis pra abrir.
  function renderFerramentasAbertas(acessos) {
    var grid = el("div", "ferramentas-grid");
    var liberadas = FERRAMENTAS_CATALOGO.filter(function (f) { return setorAtualTemAcesso(f.id, acessos); });
    if (liberadas.length === 0) {
      grid.appendChild(el("p", "tools-empty", "Nenhuma ferramenta foi liberada pra esse setor ainda. Fale com o diretor."));
      return grid;
    }
    liberadas.forEach(function (f) {
      var card = el("div", "ferramenta-card");
      card.tabIndex = 0;
      card.setAttribute("role", "button");
      card.appendChild(el("div", "ferramenta-card-icon", WRENCH_SVG));
      card.appendChild(el("h3", "ferramenta-card-nome", "")).textContent = f.nome;
      card.appendChild(el("p", "ferramenta-card-desc", "")).textContent = f.descricao;
      card.addEventListener("click", function () { viewState = { type: "tool", toolId: f.id }; render(); });
      card.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); viewState = { type: "tool", toolId: f.id }; render(); }
      });
      grid.appendChild(card);
    });
    return grid;
  }

  // Visão de gerenciamento (diretor no Painel, sem nenhum setor aberto) —
  // pra cada ferramenta, lista de setores com checkbox de acesso e quantas
  // pessoas (coordenador + servidores daquele setor) isso libera.
  function renderFerramentasGerenciar(acessos, accounts) {
    var list = el("div", "ferramentas-gerenciar-list");
    var setores = Store.getSetores();

    FERRAMENTAS_CATALOGO.forEach(function (f) {
      var card = el("div", "ferramenta-gerenciar-card");
      card.appendChild(el("div", "ferramenta-card-icon", WRENCH_SVG));
      var header = card.appendChild(el("div", "ferramenta-gerenciar-header"));
      header.appendChild(el("h3", "ferramenta-card-nome", "")).textContent = f.nome;
      header.appendChild(el("p", "ferramenta-card-desc", "")).textContent = f.descricao;

      var grantedIds = acessos.filter(function (a) { return a.ferramentaId === f.id; }).map(function (a) { return a.setorId; });
      var pessoas = accounts.filter(function (a) { return a.role !== "diretor" && grantedIds.indexOf(a.setor_id) !== -1; });

      var countLine = card.appendChild(el("p", "ferramenta-acesso-count", ""));
      countLine.textContent = pessoas.length + (pessoas.length === 1 ? " pessoa tem acesso" : " pessoas têm acesso");
      if (pessoas.length > 0) {
        var toggleNomes = document.createElement("button");
        toggleNomes.type = "button";
        toggleNomes.className = "btn-link";
        toggleNomes.textContent = "ver quem";
        var nomesList = el("ul", "ferramenta-acesso-nomes");
        nomesList.hidden = true;
        pessoas.forEach(function (p) {
          var setorNome = (Store.getSetor(p.setor_id) || {}).nome || "?";
          nomesList.appendChild(el("li", "", "")).textContent = p.name + " — " + setorNome;
        });
        toggleNomes.addEventListener("click", function () { nomesList.hidden = !nomesList.hidden; });
        countLine.appendChild(document.createTextNode(" · "));
        countLine.appendChild(toggleNomes);
        card.appendChild(nomesList);
      }

      var setoresList = card.appendChild(el("ul", "ferramenta-setores-lista"));
      setores.forEach(function (setor) {
        var item = setoresList.appendChild(el("li", "ferramenta-setor-item"));
        var label = document.createElement("label");
        var checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.checked = grantedIds.indexOf(setor.id) !== -1;
        checkbox.addEventListener("change", function () {
          checkbox.disabled = true;
          var acao = checkbox.checked ? Store.concederFerramentaAcesso(f.id, setor.id) : Store.revogarFerramentaAcesso(f.id, setor.id);
          acao.then(function () { viewState = { type: "ferramentas" }; render(); })
            .catch(function (err) {
              checkbox.checked = !checkbox.checked;
              checkbox.disabled = false;
              alert("Não foi possível salvar: " + ((err && err.message) || "erro desconhecido"));
            });
        });
        label.appendChild(checkbox);
        label.appendChild(document.createTextNode(" " + setor.nome));
        item.appendChild(label);
      });

      list.appendChild(card);
    });

    return list;
  }

  function render() {
    checkStorageWarning();
    updateBrandSubtitle();
    var root = document.getElementById("view-root");
    root.innerHTML = "";
    var hero = document.getElementById("hero-compact");

    // Checado antes do Painel de Setores de propósito: o diretor precisa
    // conseguir abrir "Gerenciar acessos" a partir do Painel (setor atual
    // null), onde isPainelMode() normalmente "vence" e nunca deixaria o
    // viewState ser olhado.
    if (viewState.type === "acessos" && !canManageAccess()) {
      viewState = { type: "home" };
    }
    if (viewState.type === "acessos") {
      hero.hidden = true;
      renderToolbar("acessos", null);
      root.appendChild(renderAcessosView());
      return;
    }

    // Mesmo motivo do "acessos" acima: Ferramentas também precisa abrir a
    // partir do Painel de Setores (diretor sem nenhum setor aberto), onde
    // é o modo de gerenciar quem tem acesso a cada uma.
    if (viewState.type === "ferramentas") {
      hero.hidden = true;
      renderToolbar("ferramentas", null);
      root.appendChild(renderFerramentasView());
      return;
    }
    if (viewState.type === "tool") {
      hero.hidden = true;
      if (!setorAtualTemAcesso(viewState.toolId, Store.getFerramentaAcessos())) {
        viewState = { type: "ferramentas" };
        renderToolbar("ferramentas", null);
        root.appendChild(renderFerramentasView());
      } else {
        renderToolbar("tool", viewState.toolId);
        root.appendChild(buildToolView(viewState.toolId));
      }
      return;
    }

    if (isPainelMode()) {
      hero.hidden = true;
      renderToolbar("painel", null);
      root.appendChild(renderPainelView());
      return;
    }
    hero.hidden = false;

    var query = document.getElementById("search-input").value.trim();

    if (query) {
      var results = searchSystems(query);
      renderToolbar("search", results.length);
      root.appendChild(renderResultsView(results));
      return;
    }

    if (viewState.type === "group" && !Store.getGroup(viewState.groupId)) {
      viewState = { type: "home" };
    }
    if (viewState.type === "servidores" && !isAdmin()) {
      viewState = { type: "home" };
    }

    if (viewState.type === "group") {
      var group = Store.getGroup(viewState.groupId);
      renderToolbar("group", group);
      root.appendChild(renderGroupView(group));
    } else if (viewState.type === "servidores") {
      renderToolbar("servidores", null);
      root.appendChild(renderServidoresView());
    } else {
      renderToolbar("home", null);
      root.appendChild(renderHomeView());
    }
  }

  // ---------- search box, clock, theme (infra) ----------

  function setupSearch() {
    var input = document.getElementById("search-input");
    var clearBtn = document.getElementById("search-clear");

    input.addEventListener("input", function () {
      clearBtn.hidden = input.value.length === 0;
      render();
    });
    clearBtn.addEventListener("click", function () {
      input.value = "";
      clearBtn.hidden = true;
      input.focus();
      render();
    });
    input.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && input.value) {
        input.value = "";
        clearBtn.hidden = true;
        render();
      }
    });
    document.addEventListener("keydown", function (e) {
      if (e.key !== "/") return;
      var active = document.activeElement;
      var tag = active && active.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || (active && active.isContentEditable)) return;
      e.preventDefault();
      input.focus();
      input.select();
    });
  }

  function setupClock() {
    var greetingEl = document.getElementById("clock-greeting");
    var timeEl = document.getElementById("clock-time");
    if (!greetingEl || !timeEl) return;
    function tick() {
      var now = new Date();
      var hours = now.getHours();
      var greeting = "Boa noite";
      if (hours >= 5 && hours < 12) greeting = "Bom dia";
      else if (hours >= 12 && hours < 18) greeting = "Boa tarde";
      greetingEl.textContent = greeting;
      timeEl.textContent = String(hours).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0");
    }
    tick();
    setInterval(tick, 15000);
  }

  // Chamado pelo item "Tema claro/escuro" do menu ☰ (ver wireAuth) — antes
  // era um botão próprio no cabeçalho, com os dois ícones (sol/lua).
  function toggleTheme() {
    var current = document.documentElement.getAttribute("data-theme");
    var isDark = current ? current === "dark" : window.matchMedia("(prefers-color-scheme: dark)").matches;
    var next = isDark ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    try { localStorage.setItem("portal-theme", next); } catch (e) { /* localStorage indisponível */ }
  }

  function setupFooterYear() {
    var elYear = document.getElementById("footer-year");
    if (elYear) elYear.textContent = new Date().getFullYear();
  }

  document.addEventListener("DOMContentLoaded", function () {
    setupClock();
    setupFooterYear();
    setupSearch();
    setupModalCloseButtons();
    ["system-modal", "group-modal", "setor-modal", "doc-picker-modal", "confirm-modal", "settings-modal", "request-access-modal", "approve-request-modal", "add-servidor-modal"].forEach(function (id) {
      setupBackdropClose(document.getElementById(id));
    });
    wireSystemForm();
    wireGroupForm();
    wireSetorForm();
    wireAccessRequests();
    wireAddServidorForm();
    wireAuth();
    Store.onPersistChange = checkStorageWarning;

    document.getElementById("btn-add-system").addEventListener("click", function () {
      if (Store.getGroups().length === 0) { openGroupModal(null); return; }
      var presetGroup = viewState.type === "group" ? viewState.groupId : null;
      openSystemModal(null, presetGroup);
    });
    document.getElementById("btn-add-setor").addEventListener("click", function () { openSetorModal(null); });
    document.getElementById("btn-servidores").addEventListener("click", function () {
      viewState = { type: "servidores" };
      render();
    });
    document.getElementById("btn-acessos").addEventListener("click", function () {
      viewState = { type: "acessos" };
      render();
    });

    // No boot, Store.ready já carregou os dados SE já existia uma sessão
    // de verdade (sobrevive a recarregar a página na mesma aba). Busca a
    // própria conta a partir dessa sessão — se não achar (sessão caiu, ou
    // a conta foi removida enquanto isso), desloga e pede login de novo.
    Store.ready.then(function () {
      return Store.getMyAccount();
    }).then(function (account) {
      if (Store.accountNeedsEmailVerification(account)) {
        // Sessão real existe (usuário/senha certos), mas a verificação
        // por e-mail (ver accountNeedsEmailVerification em store.js)
        // ainda não foi concluída — sem isto, recarregar a página no
        // meio da tela de código dava acesso direto, pulando essa etapa.
        // Desloga e força entrar de novo (pede um código novo, dessa vez
        // até o fim).
        Store.logout().catch(function (err) { console.error("Falha ao sair:", err); });
        lockPortal();
        return;
      }
      if (account) {
        currentRole = account.role;
        currentAccountId = account.id;
        Store.setCurrentSetor(account.role === "diretor" ? savedSetorId : account.setor_id);
        updateChromeForRole();
        unlockPortal();
        render();
      } else {
        lockPortal();
      }
    }).catch(function (err) {
      console.error("Falha ao restaurar sessão:", err);
      lockPortal();
    });
  });
})();
