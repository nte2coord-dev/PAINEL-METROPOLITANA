// Tela da ferramenta "Leitor do Diário" (ver internalTool "leitor-diario",
// roteado em js/app.js igual a Sicalc). A lógica de extração/validação em
// si (js/leitor-diario/) não é mexida aqui — isso aqui é só a interface:
// escolher tipos de ato, escolher PDFs, chamar extrairPaginasDiario +
// parsearAtosDiario, mostrar/editar/excluir o resultado numa tabela
// salva no banco (sobrevive a sair/voltar — ver Store.*LeitorDiario*),
// e exportar pra CSV.
//
// Carregado como <script type="module"> (precisa de import/export) — por
// isso fica fora do padrão IIFE "(function (global) {...})(window)" do
// resto do site, mas o resultado final (window.LeitorDiario) é um objeto
// global comum, consumido por js/app.js exatamente como Sicalc.
import { extrairPaginasDiario, parsearAtosDiario, TIPOS_ATO_DIARIO } from "./leitor-diario/index.js";
import * as pdfjsLib from "pdfjs-dist";

// js/leitor-diario/utils/pdfExtraction.js já aponta o worker do pdf.js pra
// um CDN (cdnjs) sozinho, mas usando a URL deduzida de pdfjsLib.version —
// garante funcionar só se o cdnjs já tiver espelhado essa versão exata.
// Aqui apontamos de novo, pro MESMO host (jsDelivr) de onde pdfjs-dist
// está vindo (ver import map em index.html) — aí fica garantido que a
// versão do worker é exatamente a mesma do pacote carregado, sem depender
// de outro CDN já ter copiado esse release.
if (typeof window !== "undefined" && "GlobalWorkerOptions" in pdfjsLib) {
  pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdn.jsdelivr.net/npm/pdfjs-dist@" + pdfjsLib.version + "/build/pdf.worker.min.mjs";
}

function el(tag, className, html) {
  var node = document.createElement(tag);
  if (className) node.className = className;
  if (html !== undefined) node.innerHTML = html;
  return node;
}

function campoOuTraco(v) { return v || v === 0 ? v : "—"; }

function formatFileSize(bytes) {
  if (!bytes) return "0 KB";
  if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

// Agrupa TIPOS_ATO_DIARIO por categoria, na ordem em que aparecem (não
// alfabética) — mais fácil de achar um tipo específico olhando em grupo.
function tiposPorCategoria() {
  var categorias = [];
  var porCategoria = {};
  TIPOS_ATO_DIARIO.forEach(function (t) {
    if (!porCategoria[t.categoria]) { porCategoria[t.categoria] = []; categorias.push(t.categoria); }
    porCategoria[t.categoria].push(t);
  });
  return categorias.map(function (c) { return { categoria: c, tipos: porCategoria[c] }; });
}

var COLUNAS = [
  { chave: "nome_servidor", label: "Nome" },
  { chave: "masp", label: "MaSP" },
  { chave: "cargo", label: "Cargo" },
  { chave: "admissao", label: "Admissão" },
  { chave: "localidade_escola", label: "Escola / Município" },
  { chave: "tipo_label", label: "Tipo de ato" },
  { chave: "numero_ato", label: "Nº do ato" },
];

function exportarCsv(registros) {
  var cabecalho = COLUNAS.map(function (c) { return c.label; }).concat(["Confiança", "Motivo"]);
  function csvEscape(v) {
    var s = v === undefined || v === null ? "" : String(v);
    if (/[",\n;]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
    return s;
  }
  var linhas = [cabecalho.map(csvEscape).join(";")];
  registros.forEach(function (r) {
    var motivo = (r.problemas_validacao || []).filter(function (p) { return !/_OK:/.test(p); }).join(" | ");
    var vals = COLUNAS.map(function (c) { return r[c.chave] || ""; }).concat([r.confianca === "revisar" ? "Revisar" : "Alta", motivo]);
    linhas.push(vals.map(csvEscape).join(";"));
  });
  var blob = new Blob(["﻿" + linhas.join("\r\n")], { type: "text/csv;charset=utf-8" });
  var url = URL.createObjectURL(blob);
  var a = document.createElement("a");
  a.href = url;
  a.download = "leitor-diario-" + new Date().toISOString().slice(0, 10) + ".csv";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

// canEdit: só quem administra o setor (ou diretor) processa PDFs novos,
// edita ou exclui registros — mesma regra do resto do site (ver isAdmin()
// em app.js e a RLS da migração). Quem só visualiza (servidor) vê a
// tabela salva, sem os controles de edição.
function buildView(canEdit) {
  var wrap = el("div", "leitor-diario-view");

  wrap.appendChild(el("p", "sicalc-intro",
    "Lê PDF(s) do <strong>Diário do Executivo de Minas Gerais</strong> e extrai os atos de pessoal (férias-prêmio, licenças, afastamentos, designações, etc.) da <strong>SRE Metropolitana A</strong> — descarta deliberadamente conteúdo de outras SREs. " +
    "Cada servidor encontrado vem com uma nota de confiança (\"alta\" ou \"revisar\") e, quando precisa de revisão, o motivo exato — nunca um aviso genérico. Os resultados ficam salvos — continuam aqui mesmo se você sair e voltar depois."));

  var state = { files: [], registros: [], currentLoteId: null };

  if (canEdit) wrap.appendChild(buildUploadSection());

  var loadingBox = el("p", "sicalc-loading", "Carregando registros salvos...");
  wrap.appendChild(loadingBox);

  var toolbarRow = el("div", "leitor-diario-toolbar");
  toolbarRow.hidden = true;
  var exportBtn = document.createElement("button");
  exportBtn.type = "button";
  exportBtn.className = "btn btn-ghost";
  exportBtn.textContent = "Exportar CSV";
  exportBtn.addEventListener("click", function () { exportarCsv(state.registros); });
  toolbarRow.appendChild(exportBtn);
  if (canEdit) {
    var clearLoteBtn = document.createElement("button");
    clearLoteBtn.type = "button";
    clearLoteBtn.className = "btn btn-ghost";
    clearLoteBtn.textContent = "Limpar dados do fluxo atual";
    clearLoteBtn.disabled = true;
    clearLoteBtn.addEventListener("click", function () {
      if (!state.currentLoteId) return;
      if (!confirm("Apagar só os registros do último processamento? Os de antes continuam salvos.")) return;
      Store.clearLeitorDiarioLote(state.currentLoteId).then(function () {
        state.registros = state.registros.filter(function (r) { return r.loteId !== state.currentLoteId; });
        state.currentLoteId = null;
        clearLoteBtn.disabled = true;
        renderTabela();
      }).catch(function (err) { alert("Não foi possível limpar: " + ((err && err.message) || "erro desconhecido")); });
    });
    toolbarRow.appendChild(clearLoteBtn);

    var clearTudoBtn = document.createElement("button");
    clearTudoBtn.type = "button";
    clearTudoBtn.className = "btn btn-danger-ghost";
    clearTudoBtn.textContent = "Limpar TODOS os dados do painel";
    clearTudoBtn.addEventListener("click", function () {
      if (!confirm("Apagar TODOS os registros salvos deste setor? Não dá pra desfazer.")) return;
      Store.clearLeitorDiarioTudo().then(function () {
        state.registros = [];
        state.currentLoteId = null;
        clearLoteBtn.disabled = true;
        renderTabela();
      }).catch(function (err) { alert("Não foi possível limpar: " + ((err && err.message) || "erro desconhecido")); });
    });
    toolbarRow.appendChild(clearTudoBtn);
  }
  wrap.appendChild(toolbarRow);

  var errorBox = el("p", "field-error", "");
  errorBox.hidden = true;
  wrap.appendChild(errorBox);

  var resultsBox = el("div", "leitor-diario-results");
  resultsBox.hidden = true;
  wrap.appendChild(resultsBox);

  function renderTabela() {
    toolbarRow.hidden = state.registros.length === 0;
    if (canEdit) toolbarRow.querySelector(".btn-danger-ghost").hidden = state.registros.length === 0;
    renderResultados(resultsBox, state.registros, canEdit, {
      onEdit: function (registro, patch) {
        return Store.updateLeitorDiarioRegistro(registro.id, Object.assign({ loteId: registro.loteId }, patch)).then(function () {
          Object.assign(registro, patch);
        });
      },
      onDelete: function (registro) {
        if (!confirm("Excluir o registro de " + (registro.nome_servidor || "esse servidor") + "?")) return Promise.resolve(false);
        return Store.deleteLeitorDiarioRegistro(registro.id).then(function () {
          state.registros = state.registros.filter(function (r) { return r.id !== registro.id; });
          renderTabela();
          return true;
        });
      },
    });
  }

  Store.getLeitorDiarioRegistros().then(function (rows) {
    loadingBox.hidden = true;
    state.registros = rows;
    // "Fluxo atual" é o lote mais recente mesmo depois de recarregar a
    // página — getLeitorDiarioRegistros vem ordenado por criado_em
    // crescente, então o último da lista é o lote mais novo.
    state.currentLoteId = rows.length ? rows[rows.length - 1].loteId : null;
    if (canEdit && state.currentLoteId) clearLoteBtn.disabled = false;
    renderTabela();
  }).catch(function (err) {
    loadingBox.hidden = true;
    errorBox.hidden = false;
    errorBox.textContent = "Não foi possível carregar os registros salvos. Verifique sua internet e recarregue a página.";
    console.error("Falha ao carregar registros do Leitor do Diário:", err);
  });

  if (!canEdit) return wrap;

  // ---- o resto (upload/checkboxes/processar) só existe pra quem edita ----

  var uploadSection = wrap.querySelector(".leitor-diario-upload");
  var tiposCheckboxes = uploadSection.querySelectorAll("input[type=checkbox][data-tipo-id]");
  var fileInput = uploadSection.querySelector("input[type=file]");
  var dropzone = uploadSection.querySelector(".leitor-diario-drop");
  var fileList = uploadSection.querySelector(".leitor-diario-file-list");
  var processBtn = uploadSection.querySelector(".leitor-diario-process-btn");
  var progressBox = uploadSection.querySelector(".leitor-diario-progress");

  function renderFileList() {
    fileList.innerHTML = "";
    state.files.forEach(function (file, idx) {
      var li = el("li", "leitor-diario-file-item");
      li.appendChild(el("span", "leitor-diario-file-name", "")).textContent = file.name;
      li.appendChild(el("span", "leitor-diario-file-size", "")).textContent = formatFileSize(file.size);
      var removeBtn = document.createElement("button");
      removeBtn.type = "button";
      removeBtn.className = "doc-editor-remove";
      removeBtn.setAttribute("aria-label", "Remover");
      removeBtn.textContent = "×";
      removeBtn.addEventListener("click", function () {
        state.files.splice(idx, 1);
        renderFileList();
        processBtn.disabled = state.files.length === 0;
      });
      li.appendChild(removeBtn);
      fileList.appendChild(li);
    });
  }

  function addFiles(fileListArg) {
    var incoming = Array.prototype.filter.call(fileListArg, function (f) {
      return f.type === "application/pdf" || /\.pdf$/i.test(f.name);
    });
    if (!incoming.length) return;
    state.files = state.files.concat(incoming);
    renderFileList();
    processBtn.disabled = state.files.length === 0;
  }

  uploadSection.querySelector(".leitor-diario-pick-btn").addEventListener("click", function () { fileInput.click(); });
  dropzone.addEventListener("click", function (e) { if (e.target === dropzone) fileInput.click(); });
  dropzone.addEventListener("dragover", function (e) { e.preventDefault(); dropzone.classList.add("is-dragover"); });
  dropzone.addEventListener("dragleave", function () { dropzone.classList.remove("is-dragover"); });
  dropzone.addEventListener("drop", function (e) { e.preventDefault(); dropzone.classList.remove("is-dragover"); addFiles(e.dataTransfer.files); });
  fileInput.addEventListener("change", function () { addFiles(fileInput.files); fileInput.value = ""; });

  uploadSection.querySelector(".leitor-diario-tipos-todos").addEventListener("click", function () {
    tiposCheckboxes.forEach(function (cb) { cb.checked = true; });
  });
  uploadSection.querySelector(".leitor-diario-tipos-nenhum").addEventListener("click", function () {
    tiposCheckboxes.forEach(function (cb) { cb.checked = false; });
  });

  processBtn.addEventListener("click", function () {
    if (!state.files.length) return;
    var tiposAtivos = Array.prototype.filter.call(tiposCheckboxes, function (cb) { return cb.checked; })
      .map(function (cb) { return cb.getAttribute("data-tipo-id"); });
    if (!tiposAtivos.length) {
      errorBox.hidden = false;
      errorBox.textContent = "Marque pelo menos um tipo de ato antes de processar.";
      return;
    }
    processBtn.disabled = true;
    errorBox.hidden = true;
    progressBox.hidden = false;
    progressBox.textContent = "Lendo os PDFs...";

    extrairPaginasDiario(state.files, function (fracao, texto) {
      progressBox.textContent = texto || ("Lendo os PDFs... " + Math.round((fracao || 0) * 100) + "%");
    }).then(function (resultadoLeitura) {
      progressBox.textContent = "Analisando os atos...";
      var resultado = parsearAtosDiario(resultadoLeitura.paginas, tiposAtivos);
      progressBox.textContent = "Salvando resultado...";
      return Store.saveLeitorDiarioLote(resultado.registros || []);
    }).then(function (salvos) {
      progressBox.hidden = true;
      processBtn.disabled = false;
      state.files = [];
      renderFileList();
      state.registros = state.registros.concat(salvos);
      state.currentLoteId = salvos.length ? salvos[0].loteId : null;
      if (state.currentLoteId) clearLoteBtn.disabled = false;
      renderTabela();
    }).catch(function (err) {
      progressBox.hidden = true;
      processBtn.disabled = false;
      errorBox.hidden = false;
      errorBox.textContent = "Não foi possível processar: " + ((err && err.message) || "erro desconhecido") + ". Confira se os arquivos são PDFs válidos e tente de novo.";
      console.error("Falha ao processar Diário:", err);
    });
  });

  return wrap;
}

function buildUploadSection() {
  var section = el("div", "leitor-diario-upload");

  var tiposDetails = document.createElement("details");
  tiposDetails.className = "sicalc-avancado";
  var tiposSummary = document.createElement("summary");
  tiposSummary.textContent = "Tipos de ato a processar (todos marcados por padrão)";
  tiposDetails.appendChild(tiposSummary);
  var tiposLinks = el("p", "leitor-diario-tipos-links");
  var todosBtn = document.createElement("button");
  todosBtn.type = "button"; todosBtn.className = "btn-link leitor-diario-tipos-todos"; todosBtn.textContent = "Marcar todos";
  var nenhumBtn = document.createElement("button");
  nenhumBtn.type = "button"; nenhumBtn.className = "btn-link leitor-diario-tipos-nenhum"; nenhumBtn.textContent = "Desmarcar todos";
  tiposLinks.appendChild(todosBtn);
  tiposLinks.appendChild(document.createTextNode(" · "));
  tiposLinks.appendChild(nenhumBtn);
  tiposDetails.appendChild(tiposLinks);

  tiposPorCategoria().forEach(function (grupo) {
    var grupoBox = el("div", "leitor-diario-tipos-grupo");
    grupoBox.appendChild(el("p", "leitor-diario-tipos-categoria", "")).textContent = grupo.categoria;
    var lista = el("div", "leitor-diario-tipos-lista");
    grupo.tipos.forEach(function (t) {
      var label = el("label", "leitor-diario-tipo-item");
      var checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = true;
      checkbox.setAttribute("data-tipo-id", t.id);
      label.appendChild(checkbox);
      label.appendChild(document.createTextNode(" " + t.label));
      lista.appendChild(label);
    });
    grupoBox.appendChild(lista);
    tiposDetails.appendChild(grupoBox);
  });
  section.appendChild(tiposDetails);

  var dropzone = el("div", "leitor-diario-drop");
  var fileInput = document.createElement("input");
  fileInput.type = "file";
  fileInput.accept = ".pdf,application/pdf";
  fileInput.multiple = true;
  fileInput.hidden = true;
  dropzone.appendChild(fileInput);

  var dropText = el("p", "leitor-diario-drop-text", "");
  var pickBtn = document.createElement("button");
  pickBtn.type = "button";
  pickBtn.className = "btn-link leitor-diario-pick-btn";
  pickBtn.textContent = "clique para selecionar";
  dropText.appendChild(document.createTextNode("Arraste PDFs do Diário aqui, ou "));
  dropText.appendChild(pickBtn);
  dropzone.appendChild(dropText);
  dropzone.appendChild(el("p", "field-hint", "Só PDF. Pode selecionar vários de uma vez (várias edições do Diário)."));
  section.appendChild(dropzone);

  var fileList = el("ul", "leitor-diario-file-list");
  section.appendChild(fileList);

  var submitRow = el("div", "sicalc-submit-row");
  var processBtn = document.createElement("button");
  processBtn.type = "button";
  processBtn.className = "btn btn-primary leitor-diario-process-btn";
  processBtn.textContent = "Processar arquivos";
  processBtn.disabled = true;
  submitRow.appendChild(processBtn);
  section.appendChild(submitRow);

  var progressBox = el("p", "field-hint leitor-diario-progress", "");
  progressBox.hidden = true;
  section.appendChild(progressBox);

  return section;
}

function renderResultados(container, registros, canEdit, callbacks) {
  container.innerHTML = "";
  container.hidden = registros.length === 0;
  if (!registros.length) return;

  var altos = registros.filter(function (r) { return r.confianca !== "revisar"; }).length;
  var revisar = registros.length - altos;
  var resumo = el("p", "sicalc-admin-summary", "");
  resumo.textContent = registros.length + " servidor" + (registros.length === 1 ? "" : "es") + " encontrado" + (registros.length === 1 ? "" : "s") +
    " (" + altos + " com confiança alta, " + revisar + " pra revisar).";
  container.appendChild(resumo);

  var wrapTable = el("div", "acessos-table-wrap");
  var table = document.createElement("table");
  table.className = "acessos-table";
  var thead = document.createElement("thead");
  var headerCells = COLUNAS.map(function (c) { return "<th>" + c.label + "</th>"; }).join("") + "<th>Confiança</th><th>Motivo (se revisar)</th>";
  thead.innerHTML = "<tr>" + headerCells + (canEdit ? "<th></th>" : "") + "</tr>";
  table.appendChild(thead);
  var tbody = document.createElement("tbody");

  registros.forEach(function (r) {
    tbody.appendChild(buildRow(r, canEdit, callbacks));
  });

  table.appendChild(tbody);
  wrapTable.appendChild(table);
  container.appendChild(wrapTable);
}

function buildRow(registro, canEdit, callbacks) {
  var tr = document.createElement("tr");
  var editing = false;
  var inputs = {};

  function renderDisplay() {
    tr.innerHTML = "";
    COLUNAS.forEach(function (c) {
      var td = document.createElement("td");
      td.textContent = campoOuTraco(registro[c.chave]);
      tr.appendChild(td);
    });
    var tdConfianca = document.createElement("td");
    var badge = el("span", "role-badge " + (registro.confianca === "revisar" ? "role-badge-revisar" : "role-badge-admin"), "");
    badge.textContent = registro.confianca === "revisar" ? "Revisar" : "Alta";
    tdConfianca.appendChild(badge);
    tr.appendChild(tdConfianca);
    var tdMotivo = document.createElement("td");
    tdMotivo.textContent = (registro.problemas_validacao || []).filter(function (p) { return !/_OK:/.test(p); }).join("; ") || "—";
    tr.appendChild(tdMotivo);
    if (canEdit) {
      var tdAcoes = el("td", "leitor-diario-row-actions");
      var editBtn = document.createElement("button");
      editBtn.type = "button"; editBtn.className = "icon-btn"; editBtn.title = "Editar"; editBtn.textContent = "✎";
      editBtn.addEventListener("click", function () { editing = true; renderEdit(); });
      var delBtn = document.createElement("button");
      delBtn.type = "button"; delBtn.className = "icon-btn"; delBtn.title = "Excluir"; delBtn.textContent = "🗑";
      delBtn.addEventListener("click", function () { callbacks.onDelete(registro); });
      tdAcoes.appendChild(editBtn);
      tdAcoes.appendChild(delBtn);
      tr.appendChild(tdAcoes);
    }
  }

  function renderEdit() {
    tr.innerHTML = "";
    inputs = {};
    COLUNAS.forEach(function (c) {
      var td = document.createElement("td");
      var input = document.createElement("input");
      input.type = "text";
      input.className = "field-input leitor-diario-edit-input";
      input.value = registro[c.chave] || "";
      inputs[c.chave] = input;
      td.appendChild(input);
      tr.appendChild(td);
    });
    tr.appendChild(document.createElement("td")); // confiança não é editável aqui
    tr.appendChild(document.createElement("td")); // motivo idem
    var tdAcoes = el("td", "leitor-diario-row-actions");
    var saveBtn = document.createElement("button");
    saveBtn.type = "button"; saveBtn.className = "icon-btn"; saveBtn.title = "Salvar"; saveBtn.textContent = "✔";
    saveBtn.addEventListener("click", function () {
      var patch = {};
      COLUNAS.forEach(function (c) { patch[c.chave] = inputs[c.chave].value.trim() || null; });
      saveBtn.disabled = true;
      callbacks.onEdit(registro, patch).then(function () {
        editing = false;
        renderDisplay();
      }).catch(function (err) {
        saveBtn.disabled = false;
        alert("Não foi possível salvar: " + ((err && err.message) || "erro desconhecido"));
      });
    });
    var cancelBtn = document.createElement("button");
    cancelBtn.type = "button"; cancelBtn.className = "icon-btn"; cancelBtn.title = "Cancelar"; cancelBtn.textContent = "✕";
    cancelBtn.addEventListener("click", function () { editing = false; renderDisplay(); });
    tdAcoes.appendChild(saveBtn);
    tdAcoes.appendChild(cancelBtn);
    tr.appendChild(tdAcoes);
  }

  renderDisplay();
  return tr;
}

window.LeitorDiario = { buildView: buildView };
