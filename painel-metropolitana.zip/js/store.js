// Camada de dados do portal. Fica num banco compartilhado no Supabase —
// o que o coordenador editar aparece pra todo mundo que abrir o site.
// Login e permissões agora são de verdade (Supabase Auth + RLS no banco,
// ver supabase/migrations/ e o README) — o próprio banco decide quem
// pode ver/editar cada linha, não só a tela.
(function (global) {
  "use strict";

  var PALETTE = {
    blue: { from: "#2f5fb3", to: "#5b9bd5" },
    teal: { from: "#0f6d63", to: "#2a9d8f" },
    indigo: { from: "#4338ca", to: "#6d5ce0" },
    green: { from: "#15803d", to: "#3fa85c" },
    amber: { from: "#a16207", to: "#d99a2b" },
    violet: { from: "#6d28d9", to: "#9061e8" },
    pink: { from: "#be185d", to: "#e0559b" },
    orange: { from: "#b45309", to: "#e08838" },
    red: { from: "#b91c1c", to: "#e0524b" },
    slate: { from: "#475569", to: "#7587a0" },
  };
  var PALETTE_ORDER = ["blue", "teal", "indigo", "green", "amber", "violet", "pink", "orange", "red", "slate"];

  function uid(prefix) {
    return prefix + "-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  // Monta o payload de uma conta "servidor" (coordenador ou visualização,
  // com nome/MASP/telefone/cargo/e-mail/senha) — usado tanto ao aprovar
  // um pedido de acesso quanto no cadastro direto. Quem cria a conta de
  // verdade (e o usuário no Auth) é a Edge Function "manage-account".
  function servidorPayload(data) {
    data = data || {};
    return {
      role: data.role || "admin",
      name: (data.name || "").trim(),
      setor_id: data.setorId || null,
      email: (data.email || "").trim().toLowerCase(),
      masp: (data.masp || "").trim(),
      telefone: (data.telefone || "").trim(),
      cargo: (data.cargo || "").trim(),
      password: data.password || "",
    };
  }

  // ---------- conversao linha do banco <-> objeto usado pelo app.js ----------

  function setorFromRow(row) {
    return { id: row.id, nome: row.nome, color: row.color, iconImage: row.icon_image || null, order: row.order };
  }
  function setorToRow(s) {
    return { id: s.id, nome: s.nome, color: s.color, icon_image: s.iconImage || null, "order": s.order };
  }
  function groupFromRow(row) {
    return { id: row.id, name: row.name, color: row.color, iconImage: row.icon_image || null, order: row.order, setorId: row.setor_id || null };
  }
  function groupToRow(g) {
    return { id: g.id, name: g.name, color: g.color, icon_image: g.iconImage || null, "order": g.order, setor_id: g.setorId || null };
  }
  function systemFromRow(row) {
    return {
      id: row.id, name: row.name, tag: row.tag, color: row.color,
      iconImage: row.icon_image || null, groupId: row.group_id,
      documents: Array.isArray(row.documents) ? row.documents : [],
      internalTool: row.internal_tool || null,
    };
  }
  function systemToRow(s) {
    return {
      id: s.id, name: s.name, tag: s.tag, color: s.color, icon_image: s.iconImage || null,
      group_id: s.groupId, documents: s.documents, internal_tool: s.internalTool || null,
    };
  }

  // ---------- Leitor do Diário: registros extraídos, convertidos
  // linha-do-banco <-> objeto usado por js/leitor-diario-view.js (mesma
  // forma que RegistroDiario já tinha, pra não precisar converter de novo
  // depois de salvar) ----------

  function leitorDiarioRegistroFromRow(row) {
    return {
      id: row.id, loteId: row.lote_id, nome_servidor: row.nome_servidor, masp: row.masp, cargo: row.cargo,
      admissao: row.admissao, municipio: row.municipio, localidade_escola: row.localidade_escola,
      tipo_ato: row.tipo_ato, tipo_label: row.tipo_label, numero_ato: row.numero_ato, confianca: row.confianca,
      problemas_validacao: Array.isArray(row.problemas_validacao) ? row.problemas_validacao : [],
      fonte_arquivo: row.fonte_arquivo, fonte_pagina: row.fonte_pagina,
    };
  }
  function leitorDiarioRegistroToRow(r, setorId, loteId) {
    return {
      setor_id: setorId, lote_id: loteId, nome_servidor: r.nome_servidor || null, masp: r.masp || null,
      cargo: r.cargo || null, admissao: r.admissao || null, municipio: r.municipio || null,
      localidade_escola: r.localidade_escola || null, tipo_ato: r.tipo_ato || null, tipo_label: r.tipo_label || null,
      numero_ato: r.numero_ato || null, confianca: r.confianca || null,
      problemas_validacao: Array.isArray(r.problemas_validacao) ? r.problemas_validacao : [],
      fonte_arquivo: r.fonte_arquivo || null, fonte_pagina: r.fonte_pagina || null,
    };
  }

  // ---------- SICALC: tabela de vencimentos + faixas de contribuição +
  // IPSEMG, convertidas linha-do-banco <-> objeto usado por sicalc.js
  // (mesma forma que js/sicalc-data.js já usava, pra não precisar mudar o
  // motor de cálculo) ----------

  function sicalcVencimentoFromRow(row) {
    return { id: row.id, cargo: row.cargo, cargaHoraria: row.carga_horaria, nivel: row.nivel, grau: row.grau, ano: row.ano, valor: Number(row.valor) };
  }
  function sicalcPrevidFaixaFromRow(row) {
    return {
      id: row.id, tipo: row.tipo, ordem: row.ordem,
      min: Number(row.minimo), max: row.maximo === null ? Infinity : Number(row.maximo),
      aliquota: Number(row.aliquota), deducao: Number(row.deducao),
    };
  }
  function sicalcIpsemgFromRow(row) {
    return { aliquotaBase: Number(row.aliquota_base), aliquotaIdade59: Number(row.aliquota_idade_59), teto: Number(row.teto) };
  }

  // ---------- estado em memoria (carregado do Supabase após o login) ----------

  var EMAIL_DOMAIN_RE = /@educacao\.mg\.gov\.br$/i;

  // Só o diretor precisa confirmar o e-mail no primeiro login —
  // coordenador/servidor entra direto (a senha certa já é a autenticação
  // de verdade; isso aqui é uma etapa extra, não a proteção em si). A
  // conta de quem administra o site fica de fora dessa etapa mesmo sendo
  // diretor — só o Kelson passa por ela. Função única (usada tanto no
  // login quanto na checagem de boot, em app.js) pra nunca as duas
  // divergirem de novo — já aconteceu uma vez, com o corte por papel.
  var EMAIL_VERIFICATION_EXEMPT = ["davi.zicker@educacao.mg.gov.br"];
  function accountNeedsEmailVerification(account) {
    if (!account || !account.email || account.email_verified_at) return false;
    if (account.role !== "diretor") return false;
    return EMAIL_VERIFICATION_EXEMPT.indexOf(account.email.toLowerCase()) === -1;
  }

  // Segunda camada só pro diretor: trocar a PRÓPRIA senha em Configurações
  // exige confirmar um código mandado pro e-mail (mesmo mecanismo do OTP
  // de login, ver sendLoginOtp/verifyLoginOtp abaixo) — a conta é de
  // acesso geral, então vale uma confirmação extra antes de mudar a
  // credencial dela. Reaproveita a mesma lista de isenção (quem administra
  // o site já é isento da verificação por e-mail no login, então fica
  // isento aqui também, pelo mesmo motivo). Só a senha exige isso — trocar
  // o nome continua imediato.
  function passwordChangeNeedsVerification(account) {
    if (!account || !account.email || account.role !== "diretor") return false;
    return EMAIL_VERIFICATION_EXEMPT.indexOf(account.email.toLowerCase()) === -1;
  }

  var state = { groups: [], systems: [], setores: [], solicitacoes: [], ferramentaAcessos: [] };
  var lastWriteFailed = false;
  var initError = null;

  // Cache dos dados do SICALC: carregado só na primeira vez que alguém
  // pede (abrir a Calculadora ou a tela de Parâmetros do ano), não no
  // boot — são ~1200 linhas de vencimento, sem sentido buscar isso pra
  // todo mundo que loga e nunca abre essa ferramenta. Cada entrada aqui é
  // a Promise em andamento (ou já resolvida); fica null de novo depois de
  // qualquer escrita, pra próxima leitura buscar os dados atualizados.
  var sicalcCache = { vencimentos: null, previd: null, ipsemg: null };

  // Setor "atual": null quando é o diretor/dev navegando o Painel de
  // Setores (visão geral, sem nenhum setor aberto); o id do setor pros
  // outros papéis, que ficam sempre presos ao próprio setor, e pro
  // diretor/dev quando "entra" num setor pra geri-lo.
  var currentSetorId = null;

  function syncWrite(promise) {
    promise.then(function () {
      lastWriteFailed = false;
      if (Store.onPersistChange) Store.onPersistChange();
    }).catch(function (err) {
      lastWriteFailed = true;
      console.error("Falha ao salvar no Supabase:", err);
      if (Store.onPersistChange) Store.onPersistChange();
    });
  }

  // Carrega grupos/sistemas/setores/pedidos de acesso — só depois de
  // logado (antes disso, o RLS nem deixa ler essas tabelas: é assim que
  // a proteção de verdade funciona agora, não só a tela escondendo
  // botão). Quem não é diretor/dev só vê os próprios; quem não é diretor
  // simplesmente recebe uma fila de pedidos vazia (RLS filtra sozinho).
  function loadPortalData() {
    return Promise.all([
      SupabaseClient.select("groups", "?order=order"),
      SupabaseClient.select("systems"),
      SupabaseClient.select("setores", "?order=order"),
      SupabaseClient.select("solicitacoes_acesso", "?order=created_at"),
      SupabaseClient.select("ferramenta_acessos"),
    ]).then(function (results) {
      state.groups = results[0].map(groupFromRow);
      state.systems = results[1].map(systemFromRow);
      state.setores = results[2].map(setorFromRow);
      state.solicitacoes = results[3] || [];
      state.ferramentaAcessos = (results[4] || []).map(function (r) { return { ferramentaId: r.ferramenta_id, setorId: r.setor_id }; });
    }).catch(function (err) {
      initError = "Não foi possível carregar os dados do banco. Verifique sua internet e recarregue a página.";
      console.error("Falha ao carregar dados do Supabase:", err);
      throw err;
    });
  }

  // No boot, só confere se já existe uma sessão de verdade (sobrevive a
  // recarregar a página na mesma aba) — se existir, já carrega os dados;
  // se não, não carrega nada (nem tenta: sem sessão, o RLS bloquearia
  // mesmo, então nem faz sentido chamar).
  var readyPromise = SupabaseClient.getSession().then(function (session) {
    if (!session) return;
    return loadPortalData();
  });

  var Store = {
    PALETTE: PALETTE,
    PALETTE_ORDER: PALETTE_ORDER,
    uid: uid,
    ready: readyPromise,
    // Exposta pra app.js usar a mesma regra na checagem de boot (ver
    // DOMContentLoaded) — nunca reimplementar essa condição de novo lá.
    accountNeedsEmailVerification: accountNeedsEmailVerification,
    passwordChangeNeedsVerification: passwordChangeNeedsVerification,
    hasInitError: function () { return initError; },
    isPersistent: function () { return !lastWriteFailed && !initError; },
    onPersistChange: null,

    getCurrentSetor: function () { return currentSetorId; },
    setCurrentSetor: function (id) { currentSetorId = id || null; },

    getSetores: function () {
      return state.setores.slice().sort(function (a, b) { return a.order - b.order; });
    },
    getSetor: function (id) {
      return state.setores.filter(function (s) { return s.id === id; })[0] || null;
    },
    countGroupsBySetor: function (setorId) {
      return state.groups.filter(function (g) { return g.setorId === setorId; }).length;
    },
    // Setor novo nasce sem conta nenhuma — coordenador e visualização só
    // entram depois de o diretor aprovar um pedido de acesso (ver
    // approveAccessRequest) ou de um cadastro direto (ver createServidor).
    createSetor: function (data) {
      data = data || {};
      var setor = {
        id: uid("setor"),
        nome: (data.nome || "").trim() || "Novo setor",
        color: data.color || "blue",
        iconImage: data.iconImage || null,
        order: state.setores.length,
      };
      state.setores.push(setor);
      syncWrite(SupabaseClient.insert("setores", setorToRow(setor)));
      return setor;
    },
    updateSetor: function (id, patch) {
      var setor = this.getSetor(id);
      if (!setor) return null;
      patch = patch || {};
      if (typeof patch.nome === "string" && patch.nome.trim()) setor.nome = patch.nome.trim();
      if (typeof patch.color === "string") setor.color = patch.color;
      if (Object.prototype.hasOwnProperty.call(patch, "iconImage")) setor.iconImage = patch.iconImage || null;
      syncWrite(SupabaseClient.updateById("setores", id, setorToRow(setor)));
      return setor;
    },
    deleteSetor: function (id) {
      var hasGroups = state.groups.some(function (g) { return g.setorId === id; });
      if (hasGroups) return { ok: false, reason: "not-empty" };
      state.setores = state.setores.filter(function (s) { return s.id !== id; });
      syncWrite(SupabaseClient.deleteById("setores", id));
      return { ok: true };
    },
    // Reordena os setores (arrastar e soltar no Painel) — recalcula o
    // "order" de cada um a partir da nova posição na lista recebida e
    // salva todo mundo de uma vez.
    reorderSetores: function (orderedIds) {
      orderedIds.forEach(function (id, index) {
        var setor = state.setores.filter(function (s) { return s.id === id; })[0];
        if (setor) setor.order = index;
      });
      syncWrite(Promise.all(orderedIds.map(function (id, index) {
        return SupabaseClient.updateById("setores", id, { order: index });
      })));
      return this.getSetores();
    },

    getGroups: function () {
      return state.groups
        .filter(function (g) { return g.setorId === currentSetorId; })
        .sort(function (a, b) { return a.order - b.order; });
    },
    getGroup: function (id) {
      return state.groups.filter(function (g) { return g.id === id; })[0] || null;
    },
    getSystems: function () {
      var setorGroupIds = {};
      state.groups.forEach(function (g) { if (g.setorId === currentSetorId) setorGroupIds[g.id] = true; });
      return state.systems.filter(function (s) { return setorGroupIds[s.groupId]; });
    },
    getSystemsByGroup: function (groupId) {
      return state.systems.filter(function (s) { return s.groupId === groupId; });
    },
    getSystem: function (id) {
      return state.systems.filter(function (s) { return s.id === id; })[0] || null;
    },
    countByGroup: function (groupId) {
      return state.systems.filter(function (s) { return s.groupId === groupId; }).length;
    },

    createGroup: function (data) {
      data = data || {};
      var group = {
        id: uid("grp"),
        name: (data.name || "").trim() || "Novo grupo",
        color: data.color || "blue",
        iconImage: data.iconImage || null,
        order: this.getGroups().length,
        setorId: currentSetorId,
      };
      state.groups.push(group);
      syncWrite(SupabaseClient.insert("groups", groupToRow(group)));
      return group;
    },
    updateGroup: function (id, patch) {
      var group = this.getGroup(id);
      if (!group) return null;
      patch = patch || {};
      if (typeof patch.name === "string" && patch.name.trim()) group.name = patch.name.trim();
      if (typeof patch.color === "string") group.color = patch.color;
      if (Object.prototype.hasOwnProperty.call(patch, "iconImage")) group.iconImage = patch.iconImage || null;
      syncWrite(SupabaseClient.updateById("groups", id, groupToRow(group)));
      return group;
    },
    deleteGroup: function (id) {
      var hasSystems = state.systems.some(function (s) { return s.groupId === id; });
      if (hasSystems) return { ok: false, reason: "not-empty" };
      state.groups = state.groups.filter(function (g) { return g.id !== id; });
      syncWrite(SupabaseClient.deleteById("groups", id));
      return { ok: true };
    },

    createSystem: function (data) {
      data = data || {};
      var system = {
        id: uid("sys"),
        name: (data.name || "").trim() || "Novo sistema",
        tag: (data.tag || "").trim().slice(0, 3).toUpperCase() || "??",
        color: data.color || "blue",
        iconImage: data.iconImage || null,
        groupId: data.groupId || (state.groups[0] && state.groups[0].id) || null,
        documents: Array.isArray(data.documents) ? data.documents : [],
        internalTool: data.internalTool || null,
      };
      state.systems.push(system);
      syncWrite(SupabaseClient.insert("systems", systemToRow(system)));
      return system;
    },
    updateSystem: function (id, patch) {
      var system = this.getSystem(id);
      if (!system) return null;
      patch = patch || {};
      if (typeof patch.name === "string" && patch.name.trim()) system.name = patch.name.trim();
      if (typeof patch.tag === "string" && patch.tag.trim()) system.tag = patch.tag.trim().slice(0, 3).toUpperCase();
      if (typeof patch.color === "string") system.color = patch.color;
      if (Object.prototype.hasOwnProperty.call(patch, "iconImage")) system.iconImage = patch.iconImage || null;
      if (typeof patch.groupId === "string") system.groupId = patch.groupId;
      if (Array.isArray(patch.documents)) system.documents = patch.documents;
      syncWrite(SupabaseClient.updateById("systems", id, systemToRow(system)));
      return system;
    },
    // Ferramenta interna (internalTool, ex: a Calculadora de Pagamento)
    // nunca pode ser excluída, nem pelo diretor — é parte do site, não
    // conteúdo configurável, e excluir por engano tira a ferramenta do ar
    // pra todo mundo. Enquanto ela existir, o grupo que a contém também
    // fica protegido sozinho, pela regra de "não-empty" de deleteGroup.
    deleteSystem: function (id) {
      var system = this.getSystem(id);
      if (system && system.internalTool) return { ok: false, reason: "protected" };
      state.systems = state.systems.filter(function (s) { return s.id !== id; });
      syncWrite(SupabaseClient.deleteById("systems", id));
      return { ok: true };
    },

    // ---------- contas (autenticação de verdade) ----------

    // Busca ao vivo no banco (não é mais um cache local) — o RLS decide
    // se essa conta pode ver a linha pedida: sempre pode ver a própria;
    // diretor/dev vê qualquer uma; coordenador vê as do próprio setor.
    getAccount: function (id) {
      return SupabaseClient.selectOne("accounts", "id", id);
    },
    getSectorAccounts: function (setorId) {
      return SupabaseClient.selectEq("accounts", "setor_id", setorId);
    },
    // Pra tela "Gerenciar acessos": busca sem filtro de setor — a RLS já
    // devolve só o que cada papel pode ver (diretor/dev: todo mundo;
    // coordenador: só o próprio setor), então o mesmo método serve pros
    // dois sem precisar de dois caminhos no app.js.
    getAllAccounts: function () {
      return SupabaseClient.selectAllAccounts();
    },
    // A própria conta de quem está logado agora, a partir da sessão real
    // (não de um id guardado à mão) — usado no boot pra saber quem entrou.
    getMyAccount: function () {
      return SupabaseClient.getSession().then(function (session) {
        if (!session) return null;
        return SupabaseClient.selectOne("accounts", "auth_user_id", session.user.id);
      });
    },

    // Login de verdade: se a conta já migrou pro Auth (auth_user_id
    // preenchido), entra direto pelo Auth; se ainda não (senha antiga em
    // texto puro), a Edge Function "legacy-login" confere essa senha e
    // já cria o usuário no Auth — migração automática, sem a pessoa
    // precisar fazer nada diferente. Depois de entrar, carrega os dados
    // do portal (só dá pra ler depois de logado, com RLS de verdade).
    verifyLogin: function (username, password) {
      var login = (username || "").trim();
      return SupabaseClient.needsMigration(login).then(function (needsMigration) {
        if (needsMigration === null) return null; // não corresponde a conta nenhuma
        if (needsMigration) return SupabaseClient.legacyLogin(login, password);
        return SupabaseClient.resolveLoginEmail(login).then(function (email) {
          if (!email) return null;
          return SupabaseClient.signInWithPassword(email, password);
        });
      }).then(function (authResult) {
        if (!authResult) return null;
        return loadPortalData().then(function () { return Store.getMyAccount(); });
      }).then(function (account) {
        if (!account) return null;
        account.needs_email_verification = accountNeedsEmailVerification(account);
        currentSetorId = (account.role === "diretor" || account.role === "dev") ? null : (account.setor_id || null);
        return account;
      }).catch(function (err) {
        var msg = (err && err.message) || "";
        if (/invalid|credentials/i.test(msg)) return null;
        throw err;
      });
    },
    // ---------- "Esqueci a senha" (sem estar logado) ----------
    // Sempre manda o código (mesmo se o e-mail não tiver conta nenhuma —
    // de propósito, pra não dar pra descobrir quais e-mails têm conta só
    // tentando essa tela). O cuidado de sempre mostrar a mesma mensagem
    // pro usuário fica em app.js.
    requestPasswordReset: function (email) {
      return SupabaseClient.sendOtp((email || "").trim().toLowerCase());
    },
    // Confirma o código (abre uma sessão temporária com ele) e já troca
    // pra senha nova nessa sessão — devolve true/false em código errado
    // (igual verifyLoginOtp), mas deixa erro de verdade (rede, senha
    // curta demais) estourar pra quem chamou tratar.
    confirmPasswordReset: function (email, code, newPassword) {
      // Só o passo de CONFIRMAR O CÓDIGO devolve false num erro esperado
      // (código errado/expirado) — erro no passo de trocar a senha (ex:
      // "muito curta") precisa estourar de verdade pra tela mostrar a
      // mensagem certa, não virar um genérico "código errado".
      return SupabaseClient.verifyPasswordResetOtp((email || "").trim().toLowerCase(), code).catch(function (err) {
        var msg = (err && err.message) || "";
        if (/^Supabase 4/.test(msg)) return null;
        throw err;
      }).then(function (verified) {
        if (verified === null) return false;
        return SupabaseClient.finishPasswordReset(newPassword).then(function () {
          return SupabaseClient.signOut();
        }).then(function () { return true; });
      });
    },

    // Verificação de e-mail (só na primeira vez que uma conta com e-mail
    // loga) — usa o Auth do próprio Supabase só pra mandar/confirmar o
    // código, nunca pra manter sessão (isso é signInWithPassword/legacyLogin).
    sendLoginOtp: function (email) {
      return SupabaseClient.sendOtp(email);
    },
    verifyLoginOtp: function (email, code) {
      return SupabaseClient.verifyOtp(email, code).then(function () { return true; }).catch(function (err) {
        if (/^Supabase 4/.test(err.message)) return false;
        throw err;
      });
    },
    markEmailVerified: function () {
      syncWrite(SupabaseClient.rpc("mark_email_verified", {}));
    },
    logout: function () {
      return SupabaseClient.signOut();
    },
    // Troca o próprio nome (RLS só deixa editar a própria linha) e/ou a
    // própria senha (isso vai direto pro Auth, não pra tabela accounts —
    // não é mais texto puro em lugar nenhum).
    updateMyAccount: function (id, patch) {
      patch = patch || {};
      var promises = [];
      if (typeof patch.name === "string" && patch.name.trim()) {
        promises.push(SupabaseClient.updateById("accounts", id, { name: patch.name.trim() }));
      }
      if (patch.password) {
        promises.push(SupabaseClient.updatePassword(patch.password));
      }
      return Promise.all(promises);
    },
    deleteAccount: function (id) {
      return SupabaseClient.deleteAccount(id);
    },
    // Promove servidor -> coordenador ou revoga coordenador -> servidor
    // (Edge Function "manage-account", ação "set_role" — mesma permissão
    // de criar/remover: diretor/dev em qualquer setor, coordenador só no
    // próprio). Nunca muda diretor/dev: isso continua manual, no SQL.
    setAccountRole: function (id, role) {
      return SupabaseClient.setAccountRole(id, role).then(function (result) {
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
        return result.account;
      });
    },

    // ---------- solicitação de acesso (auto-cadastro, sem precisar estar logado) ----------

    isInstitutionalEmail: function (email) {
      return EMAIL_DOMAIN_RE.test((email || "").trim());
    },
    getAccessRequests: function () {
      return state.solicitacoes.slice().sort(function (a, b) { return (a.created_at || "").localeCompare(b.created_at || ""); });
    },
    // Lista de setores pro formulário de auto-cadastro, sem precisar estar
    // logado (setores_select libera leitura geral — nada sensível ali, só
    // nome/cor/ícone). Não mexe em state.setores (só preenchido depois do
    // login, por loadPortalData) — é uma lista à parte, só pra esse form.
    getSetoresPublic: function () {
      return SupabaseClient.select("setores", "?order=order").then(function (rows) {
        return rows.map(setorFromRow);
      });
    },
    // Auto-cadastro: a própria pessoa preenche os dados e escolhe a
    // própria senha, sem precisar estar logada — a Edge Function
    // "manage-account" (ação "register") já cria o usuário no Auth com
    // essa senha e guarda o pedido esperando o diretor aprovar. Retorna
    // uma Promise de verdade: pode falhar (e-mail já tem conta, pedido já
    // pendente, senha curta demais), então o chamador precisa aguardar.
    requestAccess: function (data) {
      data = data || {};
      var email = (data.email || "").trim().toLowerCase();
      if (!this.isInstitutionalEmail(email)) {
        var err = new Error("domain");
        return Promise.reject(err);
      }
      return SupabaseClient.registerRequest({
        name: (data.name || "").trim(),
        masp: (data.masp || "").trim(),
        telefone: (data.telefone || "").trim(),
        cargo: (data.cargo || "").trim(),
        email: email,
        setor_id: data.setorId || null,
        password: data.password || "",
      });
    },
    // Recusa um pedido (Edge Function: limpa o usuário do Auth se o
    // pedido veio de auto-cadastro, senão só apaga a linha) — Promise de
    // verdade, igual approveAccessRequest, pelo mesmo motivo.
    dismissAccessRequest: function (id) {
      return SupabaseClient.rejectAccessRequest(id).then(function () {
        state.solicitacoes = state.solicitacoes.filter(function (r) { return r.id !== id; });
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
      });
    },
    // Cria a conta de verdade (e o usuário no Auth, pela Edge Function
    // "manage-account") a partir de um pedido, e remove o pedido da fila.
    // Precisa ser aguardada (retorna uma Promise agora): pode falhar de
    // verdade (ex: e-mail duplicado), então não dá pra assumir sucesso
    // antes do banco confirmar.
    approveAccessRequest: function (requestId, data) {
      var payload = servidorPayload(data);
      payload.request_id = requestId;
      return SupabaseClient.createAccount(payload).then(function (result) {
        state.solicitacoes = state.solicitacoes.filter(function (r) { return r.id !== requestId; });
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
        return result.account;
      });
    },

    // ---------- servidores (cadastro direto, sem pedido de acesso) ----------

    // Cadastro direto: o diretor/dev (ou o coordenador, no próprio setor)
    // preenche tudo de uma vez — nome, MASP, telefone, cargo, e-mail,
    // papel e senha inicial. Também retorna uma Promise, pelo mesmo
    // motivo do approveAccessRequest acima.
    createServidor: function (data) {
      var payload = servidorPayload(data);
      return SupabaseClient.createAccount(payload).then(function (result) {
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
        return result.account;
      });
    },

    // ---------- SICALC: parâmetros do ano (vencimentos, faixas de
    // contribuição e IPSEMG), editáveis pelo coordenador do setor que
    // hospeda a Calculadora (ou pelo diretor) — ver migração
    // 20261007000000_sicalc_data_tables.sql. Toda leitura devolve a mesma
    // Promise enquanto não houver escrita nova (evita buscar as ~1200
    // linhas de vencimento de novo a cada clique); "force" ignora o cache.

    getSicalcVencimentos: function (force) {
      if (!sicalcCache.vencimentos || force) {
        sicalcCache.vencimentos = SupabaseClient.select("sicalc_vencimentos").then(function (rows) {
          return rows.map(sicalcVencimentoFromRow);
        }).catch(function (err) { sicalcCache.vencimentos = null; throw err; });
      }
      return sicalcCache.vencimentos;
    },
    getSicalcPrevidFaixas: function (force) {
      if (!sicalcCache.previd || force) {
        sicalcCache.previd = SupabaseClient.select("sicalc_previd_faixas").then(function (rows) {
          return rows.map(sicalcPrevidFaixaFromRow).sort(function (a, b) {
            return a.tipo === b.tipo ? a.ordem - b.ordem : a.tipo.localeCompare(b.tipo);
          });
        }).catch(function (err) { sicalcCache.previd = null; throw err; });
      }
      return sicalcCache.previd;
    },
    getSicalcIpsemg: function (force) {
      if (!sicalcCache.ipsemg || force) {
        sicalcCache.ipsemg = SupabaseClient.selectOne("sicalc_ipsemg", "id", 1).then(function (row) {
          return row ? sicalcIpsemgFromRow(row) : null;
        }).catch(function (err) { sicalcCache.ipsemg = null; throw err; });
      }
      return sicalcCache.ipsemg;
    },
    // Importa (ou corrige) uma vigência inteira de uma vez — upsert, não
    // insert simples: colar de novo a mesma vigência pra corrigir um valor
    // só atualiza a linha existente em vez de dar erro de duplicado.
    // "rows": [{cargo, cargaHoraria, nivel, grau, ano, valor}, ...].
    // Retorna uma Promise de verdade (nunca otimista): com ~1200 linhas
    // por vigência, a tela precisa saber se deu certo antes de avisar o
    // Everton que terminou.
    importSicalcVencimentos: function (rows) {
      var payload = rows.map(function (r) {
        return { cargo: r.cargo, carga_horaria: r.cargaHoraria, nivel: r.nivel, grau: r.grau, ano: String(r.ano), valor: r.valor };
      });
      return SupabaseClient.upsert("sicalc_vencimentos", payload, "cargo,carga_horaria,nivel,grau,ano").then(function (result) {
        sicalcCache.vencimentos = null;
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
        return result;
      });
    },
    updateSicalcPrevidFaixa: function (id, patch) {
      patch = patch || {};
      var row = {};
      if (typeof patch.min === "number") row.minimo = patch.min;
      if (patch.max === Infinity) row.maximo = null;
      else if (typeof patch.max === "number") row.maximo = patch.max;
      if (typeof patch.aliquota === "number") row.aliquota = patch.aliquota;
      if (typeof patch.deducao === "number") row.deducao = patch.deducao;
      return SupabaseClient.updateById("sicalc_previd_faixas", id, row).then(function (result) {
        sicalcCache.previd = null;
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
        return result;
      });
    },
    updateSicalcIpsemg: function (patch) {
      patch = patch || {};
      var row = {};
      if (typeof patch.aliquotaBase === "number") row.aliquota_base = patch.aliquotaBase;
      if (typeof patch.aliquotaIdade59 === "number") row.aliquota_idade_59 = patch.aliquotaIdade59;
      if (typeof patch.teto === "number") row.teto = patch.teto;
      return SupabaseClient.updateById("sicalc_ipsemg", 1, row).then(function (result) {
        sicalcCache.ipsemg = null;
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
        return result;
      });
    },

    // ---------- Leitor do Diário: registros extraídos, salvos por setor
    // (ver supabase/migrations/20261013000000_leitor_diario_registros.sql).
    // Sempre lê/escreve no setor ATUAL (currentSetorId) — cada setor só
    // vê o próprio lote; diretor/dev vê o de qualquer setor em que "entrar".

    getLeitorDiarioRegistros: function () {
      return SupabaseClient.select("leitor_diario_registros", "?order=criado_em").then(function (rows) {
        return rows.map(leitorDiarioRegistroFromRow);
      });
    },
    // Salva um lote inteiro de uma vez (resultado de um "Processar
    // arquivos") — cada linha carrega o mesmo loteId, pra "Limpar dados do
    // fluxo atual" conseguir apagar só esse lote depois. uid("lote")
    // garante um id novo por processamento (mesmo reprocessando o mesmo
    // arquivo, não junta com um lote antigo sem querer).
    saveLeitorDiarioLote: function (registros) {
      var loteId = uid("lote");
      var rows = registros.map(function (r) { return leitorDiarioRegistroToRow(r, currentSetorId, loteId); });
      return SupabaseClient.insert("leitor_diario_registros", rows).then(function (inserted) {
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
        return (inserted || []).map(leitorDiarioRegistroFromRow);
      });
    },
    updateLeitorDiarioRegistro: function (id, patch) {
      var row = leitorDiarioRegistroToRow(patch, currentSetorId, patch.loteId);
      delete row.setor_id; // nunca muda o setor de um registro já salvo
      delete row.lote_id;  // nem o lote — só os campos de verdade
      return SupabaseClient.updateById("leitor_diario_registros", id, row).then(function (result) {
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
        return result;
      });
    },
    deleteLeitorDiarioRegistro: function (id) {
      return SupabaseClient.deleteById("leitor_diario_registros", id).then(function (result) {
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
        return result;
      });
    },
    // "Limpar dados do fluxo atual": apaga só os registros de UM lote
    // (ex: o que acabou de ser processado, se tiver vindo errado).
    clearLeitorDiarioLote: function (loteId) {
      return SupabaseClient.deleteByColumn("leitor_diario_registros", "lote_id", loteId).then(function (result) {
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
        return result;
      });
    },
    // "Limpar TODOS os dados do painel": apaga tudo do setor atual (a RLS
    // já impede apagar de outro setor, mas aqui nem tenta — só manda pelo
    // setor em que a pessoa está).
    clearLeitorDiarioTudo: function () {
      return SupabaseClient.deleteByColumn("leitor_diario_registros", "setor_id", currentSetorId).then(function (result) {
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
        return result;
      });
    },

    // ---------- aba Ferramentas (catálogo fixo em app.js + acesso por setor) ----------
    // Cada linha é {ferramentaId, setorId}. Carregado uma vez no boot
    // (loadPortalData) igual groups/systems — a RLS já limita o que veio:
    // diretor recebe tudo (pra gerenciar), coordenador/servidor só o que
    // foi concedido ao próprio setor (pra saber o que aparece pra eles).
    getFerramentaAcessos: function () {
      return state.ferramentaAcessos.slice();
    },
    concederFerramentaAcesso: function (ferramentaId, setorId) {
      state.ferramentaAcessos.push({ ferramentaId: ferramentaId, setorId: setorId });
      return SupabaseClient.insert("ferramenta_acessos", { ferramenta_id: ferramentaId, setor_id: setorId }).then(function (result) {
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
        return result;
      }).catch(function (err) {
        state.ferramentaAcessos = state.ferramentaAcessos.filter(function (a) { return !(a.ferramentaId === ferramentaId && a.setorId === setorId); });
        throw err;
      });
    },
    revogarFerramentaAcesso: function (ferramentaId, setorId) {
      var removed = state.ferramentaAcessos.filter(function (a) { return a.ferramentaId === ferramentaId && a.setorId === setorId; });
      state.ferramentaAcessos = state.ferramentaAcessos.filter(function (a) { return !(a.ferramentaId === ferramentaId && a.setorId === setorId); });
      return SupabaseClient.deleteByColumns("ferramenta_acessos", { ferramenta_id: ferramentaId, setor_id: setorId }).then(function (result) {
        if (Store.onPersistChange) { lastWriteFailed = false; Store.onPersistChange(); }
        return result;
      }).catch(function (err) {
        state.ferramentaAcessos = state.ferramentaAcessos.concat(removed);
        throw err;
      });
    },
  };

  global.Store = Store;
})(window);
