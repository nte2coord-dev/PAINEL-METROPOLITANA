// Calculadora "Calculadora de Pagamento" (cálculos do SICALC): vencimento básico pró-rata, contribuição
// previdenciária (INSS/RPPS), desconto do IPSEMG e texto de ocorrência pra
// colar no SISAP. Extraída e conferida a partir da planilha SICALC_2025.xlsm
// do Everton (abas DADOS/TELA/VENCIMENTOS/PREVID/IPSEMG/OCORRENCIA/TABELAS) —
// o exemplo abaixo é o mesmo exemplo real já calculado na planilha original:
//
//   ANEI 1A 40H, situação 02 Convocado, de 25/11/2025 a 30/11/2025, incluído
//   na taxação de 06/2026 => vencimento integral R$ 7.301,95, 6 dias, valor
//   pró-rata R$ 1.460,39, contribuição INSS R$ 109,53, texto "PAGO 6 DIAS DE
//   NOV-25 REF CONVOCAÇÃO ANEI1A DE 25/11/25 A 30/11/25 TX 06/2026."
//
// A situação "04/40 Aposentado" fica sem contribuição calculada: a tabela de
// faixa dela na planilha original (PREVID!A23:D29) tem intervalos sobrepostos
// e faixas vazias — o próprio arquivo está incompleto nessa parte, então
// preferimos avisar em vez de inventar um valor. Também não modelamos AEC/AEJ
// (Extensão de Jornada) — só vencimento básico — então se o período também
// tiver AEC/AEJ retroativo, a contribuição e o IPSEMG calculados aqui ficam
// subestimados (a planilha original soma R.B.+A.E.C.+A.E.J. antes de aplicar
// as faixas e o IPSEMG). Ver README.
(function (global) {
  "use strict";

  function el(tag, className, html) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (html !== undefined) node.innerHTML = html;
    return node;
  }

  function money(n) {
    return n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  }

  function pad2(n) { return String(n).padStart(2, "0"); }

  function parseLocalDate(iso) {
    return new Date(iso + "T00:00:00");
  }

  function diasEntre(dataInicioIso, dataFimIso) {
    var d1 = parseLocalDate(dataInicioIso);
    var d2 = parseLocalDate(dataFimIso);
    return Math.round((d2 - d1) / 86400000) + 1;
  }

  function fmtDataCurta(iso) {
    var d = parseLocalDate(iso);
    return pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + String(d.getFullYear()).slice(-2);
  }

  function mesAbrevAno(iso) {
    var d = parseLocalDate(iso);
    return SICALC_MESES[d.getMonth()] + "-" + String(d.getFullYear()).slice(-2);
  }

  function divisorFor(cargo) {
    return (cargo === "PEB" || cargo === "PEBS") ? 108 : 30;
  }

  function round2(n) { return Math.round(n * 100) / 100; }

  function buscarFaixa(tabela, valor) {
    for (var i = 0; i < tabela.length; i++) {
      if (valor >= tabela[i].min && valor <= tabela[i].max) return tabela[i];
    }
    return tabela[tabela.length - 1];
  }

  // Contribuição previdenciária (aba PREVID): "aliquota efetiva com parcela
  // a deduzir" — valor = base*aliquota - dedução da faixa em que a base cai.
  // situacao.contribuicao decide qual tabela usar (ver js/sicalc-data.js).
  // Só o ramo "inss" tem os dois ajustes opcionais que a planilha original
  // também tem: somar outros rendimentos do mês (pra cair na faixa certa) e
  // subtrair o que já foi descontado de INSS/RPPS nesse mês.
  function calcularContribuicao(baseValor, situacao, opts) {
    opts = opts || {};
    if (!situacao || situacao.contribuicao === "nao-suportado") {
      return {
        ok: false,
        motivo: "A tabela de faixas pra situação \"" + (situacao ? situacao.nome : "") + "\" está incompleta na planilha original (faixas sobrepostas e vazias na aba PREVID) — não implementamos esse caso pra não arriscar um valor errado. Calcule à mão até o Everton revisar essa tabela.",
      };
    }
    if (situacao.contribuicao === "rpps") {
      var faixaR = buscarFaixa(SICALC_PREVID.rpps, baseValor);
      var valorR = round2(round2(baseValor * faixaR.aliquota) - faixaR.deducao);
      return { ok: true, tabela: "RPPS", aliquota: faixaR.aliquota, deducao: faixaR.deducao, valor: valorR };
    }
    if (situacao.contribuicao === "inss") {
      var outros = Number(opts.outrosRendimentos) || 0;
      var jaDescontado = Number(opts.jaDescontado) || 0;
      var baseAjustada = baseValor + outros;
      var faixaI = buscarFaixa(SICALC_PREVID.inss, baseAjustada);
      var brutoI = round2(round2(baseAjustada * faixaI.aliquota) - faixaI.deducao);
      var valorI = round2(brutoI - jaDescontado);
      return { ok: true, tabela: "INSS", aliquota: faixaI.aliquota, deducao: faixaI.deducao, valor: valorI };
    }
    return { ok: false, motivo: "Situação funcional sem regra de contribuição definida." };
  }

  // IPSEMG (aba IPSEMG): 3,2% da base com teto de R$500, titular e/ou
  // cônjuge (cada um com seu próprio teto), mais 1% extra (mesmo teto) só
  // pra quem tiver 59 anos ou mais.
  function calcularIpsemg(baseValor, opcao, servidor59, conjuge59) {
    if (opcao !== "servidor" && opcao !== "servidor_conjuge") {
      return { ok: true, valor: 0, titular32: 0, titular1: 0, conjuge32: 0, conjuge1: 0 };
    }
    var teto = SICALC_IPSEMG.teto;
    var base32 = Math.min(round2(baseValor * SICALC_IPSEMG.aliquotaBase), teto);
    var base1 = Math.min(round2(baseValor * SICALC_IPSEMG.aliquotaIdade59), teto);
    var titular32 = base32;
    var titular1 = servidor59 ? base1 : 0;
    var conjuge32 = opcao === "servidor_conjuge" ? base32 : 0;
    var conjuge1 = (opcao === "servidor_conjuge" && conjuge59) ? base1 : 0;
    return { ok: true, valor: round2(titular32 + titular1 + conjuge32 + conjuge1), titular32: titular32, titular1: titular1, conjuge32: conjuge32, conjuge1: conjuge1 };
  }

  // ---------- carregamento dos dados (agora vêm do Supabase, não mais
  // hardcoded em js/sicalc-data.js — ver supabase/migrations/
  // 20261007000000_sicalc_data_tables.sql) ----------

  // Store.getSicalcVencimentos() devolve uma linha "plana" por combinação +
  // ano ({cargo, cargaHoraria, nivel, grau, ano, valor}); reagrupamos pro
  // mesmo formato que SICALC_VENCIMENTOS sempre teve (uma linha por
  // combinação, com um objeto "valores" por ano dentro) — assim todo o
  // resto deste arquivo (allCargos, cargasHorariasFor, niveisFor, grausFor,
  // findRow, o row.valores[ano] em calcular()) continua funcionando sem
  // precisar mudar nada.
  function regroupVencimentos(rows) {
    var map = {};
    var list = [];
    rows.forEach(function (r) {
      var key = r.cargo + "|" + r.cargaHoraria + "|" + r.nivel + "|" + r.grau;
      if (!map[key]) {
        map[key] = { cargo: r.cargo, cargaHoraria: r.cargaHoraria, nivel: r.nivel, grau: r.grau, valores: {} };
        list.push(map[key]);
      }
      map[key].valores[r.ano] = r.valor;
    });
    return list;
  }

  function regroupPrevid(rows) {
    var out = { rpps: [], inss: [] };
    rows.forEach(function (r) {
      if (out[r.tipo]) out[r.tipo].push({ min: r.min, max: r.max, aliquota: r.aliquota, deducao: r.deducao });
    });
    return out;
  }

  // Promise em andamento (ou já resolvida) do carregamento — buildView()
  // nunca busca os dados duas vezes à toa. "force" (usado depois de
  // importar/editar algo na tela "Parâmetros do ano") reaproveita o mesmo
  // "force" do Store pra ignorar o cache dos dois lados de uma vez.
  var dataReady = null;
  function ensureDataLoaded(force) {
    if (!dataReady || force) {
      dataReady = Promise.all([
        Store.getSicalcVencimentos(force),
        Store.getSicalcPrevidFaixas(force),
        Store.getSicalcIpsemg(force),
      ]).then(function (results) {
        SICALC_VENCIMENTOS = regroupVencimentos(results[0]);
        SICALC_PREVID = regroupPrevid(results[1]);
        SICALC_IPSEMG = results[2] || SICALC_IPSEMG;
      }).catch(function (err) {
        dataReady = null; // deixa tentar de novo na próxima vez (ex: caiu a internet)
        throw err;
      });
    }
    return dataReady;
  }

  // ---------- lookups na tabela de vencimentos ----------

  function allCargos() {
    var seen = {};
    var list = [];
    SICALC_VENCIMENTOS.forEach(function (r) {
      if (!seen[r.cargo]) { seen[r.cargo] = true; list.push(r.cargo); }
    });
    return list.sort();
  }

  function cargoLabel(codigo) {
    var nome = SICALC_CARGOS[codigo];
    return nome ? codigo + " — " + nome : codigo;
  }

  function cargasHorariasFor(cargo) {
    var seen = {};
    var list = [];
    SICALC_VENCIMENTOS.forEach(function (r) {
      if (r.cargo === cargo && !seen[r.cargaHoraria]) { seen[r.cargaHoraria] = true; list.push(r.cargaHoraria); }
    });
    return list.sort();
  }

  function niveisFor(cargo, cargaHoraria) {
    var seen = {};
    var list = [];
    SICALC_VENCIMENTOS.forEach(function (r) {
      if (r.cargo === cargo && r.cargaHoraria === cargaHoraria && !seen[r.nivel]) { seen[r.nivel] = true; list.push(r.nivel); }
    });
    return list.sort(function (a, b) { return a - b; });
  }

  function grausFor(cargo, cargaHoraria, nivel) {
    var list = [];
    SICALC_VENCIMENTOS.forEach(function (r) {
      if (r.cargo === cargo && r.cargaHoraria === cargaHoraria && r.nivel === nivel) list.push(r.grau);
    });
    return list;
  }

  function findRow(cargo, cargaHoraria, nivel, grau) {
    return SICALC_VENCIMENTOS.filter(function (r) {
      return r.cargo === cargo && r.cargaHoraria === cargaHoraria && r.nivel === nivel && r.grau === grau;
    })[0] || null;
  }

  // ---------- "Parâmetros do ano": parsing/validação da colagem de
  // vencimentos (ver buildAdminSection) ----------

  function knownComboSet() {
    var set = {};
    SICALC_VENCIMENTOS.forEach(function (r) {
      set[r.cargo + "|" + r.cargaHoraria + "|" + r.nivel + "|" + r.grau] = true;
    });
    return set;
  }

  function missingCombosCount(importedRows) {
    var importedSet = {};
    importedRows.forEach(function (r) {
      importedSet[r.cargo + "|" + r.cargaHoraria + "|" + r.nivel + "|" + r.grau] = true;
    });
    var faltam = 0;
    SICALC_VENCIMENTOS.forEach(function (r) {
      if (!importedSet[r.cargo + "|" + r.cargaHoraria + "|" + r.nivel + "|" + r.grau]) faltam++;
    });
    return faltam;
  }

  // Aceita tanto "3650.97" (ponto) quanto "3.650,97" ou "3650,97" (formato
  // BR, vírgula decimal) — o Excel do Everton pode colar em qualquer um
  // dos dois formatos dependendo da config regional. Prefixo "R$" (com ou
  // sem espaço) é ignorado se vier.
  function parseValorMonetario(raw) {
    var s = String(raw == null ? "" : raw).trim().replace(/^R\$\s*/i, "");
    if (!s) return NaN;
    var hasComma = s.indexOf(",") !== -1;
    var hasDot = s.indexOf(".") !== -1;
    if (hasComma && hasDot) {
      if (s.lastIndexOf(",") > s.lastIndexOf(".")) s = s.replace(/\./g, "").replace(",", ".");
      else s = s.replace(/,/g, "");
    } else if (hasComma) {
      var parts = s.split(",");
      s = parts.length > 2 ? s.replace(/,/g, "") : s.replace(",", ".");
    }
    return Number(s);
  }

  // Quebra uma linha em até "limit" colunas — depois do limite, o resto
  // da linha (inclusive mais ocorrências do separador) vira a última
  // coluna. Isso deixa colar com separador "," funcionar mesmo se o valor
  // também tiver vírgula/ponto de milhar (ex: "AEB,30H,1,A,1.234,56" com
  // limit=5 dá ["AEB","30H","1","A","1.234,56"], não 6 pedaços quebrados).
  function splitLimited(str, sep, limit) {
    var parts = str.split(sep);
    if (parts.length <= limit) return parts;
    var head = parts.slice(0, limit - 1);
    head.push(parts.slice(limit - 1).join(sep));
    return head;
  }

  // Formato esperado, uma linha por combinação: cargo, carga horária,
  // nível, grau, valor — separado por TAB (o que o Excel já usa ao copiar
  // células) ou por vírgula. knownCombos vem de knownComboSet() (a tabela
  // atual, de qualquer ano) — linhas com uma combinação que não existe
  // nela são rejeitadas (provável erro de digitação), nunca criadas "no
  // escuro".
  function parseVencimentosPaste(text, knownCombos) {
    var linhas = text.split(/\r\n|\r|\n/).filter(function (l) { return l.trim(); });
    var sep = text.indexOf("\t") !== -1 ? "\t" : ",";
    var rows = [];
    var errors = [];
    var warnings = [];
    var seenInPaste = {};

    linhas.forEach(function (linhaOriginal, idx) {
      var linha = linhaOriginal.trim();
      var parts = splitLimited(linha, sep, 5).map(function (p) { return p.trim(); });

      if (idx === 0 && parts.length >= 5 && isNaN(Number(parts[2]))) {
        warnings.push("Primeira linha parece um cabeçalho (\"" + linha + "\") — foi ignorada.");
        return;
      }

      var numLinha = idx + 1;
      if (parts.length < 5) {
        errors.push({ linha: numLinha, texto: linha, motivo: "Linha com menos de 5 colunas (esperado: cargo, carga horária, nível, grau, valor)." });
        return;
      }

      var cargo = parts[0].toUpperCase();
      var cargaHoraria = parts[1].toUpperCase();
      var nivel = Number(parts[2]);
      var grau = parts[3].toUpperCase();
      var valor = parseValorMonetario(parts[4]);

      if (!Number.isInteger(nivel) || nivel <= 0) {
        errors.push({ linha: numLinha, texto: linha, motivo: "Nível \"" + parts[2] + "\" não é um número inteiro válido." });
        return;
      }
      if (isNaN(valor) || !isFinite(valor) || valor <= 0) {
        errors.push({ linha: numLinha, texto: linha, motivo: "Valor \"" + parts[4] + "\" não é um número válido." });
        return;
      }
      var key = cargo + "|" + cargaHoraria + "|" + nivel + "|" + grau;
      if (!knownCombos[key]) {
        errors.push({ linha: numLinha, texto: linha, motivo: "Combinação " + cargo + " / " + cargaHoraria + " / nível " + nivel + " / grau " + grau + " não existe na tabela atual — confira se não é erro de digitação." });
        return;
      }
      if (seenInPaste[key]) {
        errors.push({ linha: numLinha, texto: linha, motivo: "Combinação repetida nesta mesma colagem." });
        return;
      }
      seenInPaste[key] = true;
      rows.push({ cargo: cargo, cargaHoraria: cargaHoraria, nivel: nivel, grau: grau, valor: valor });
    });

    return { rows: rows, errors: errors, warnings: warnings };
  }

  // ---------- motor de cálculo (função pura, testável isoladamente) ----------

  function calcular(input) {
    var row = findRow(input.cargo, input.cargaHoraria, input.nivel, input.grau);
    if (!row) {
      return { ok: false, error: "Não encontramos essa combinação de cargo, carga horária, nível e grau na tabela." };
    }
    var inicio = parseLocalDate(input.dataInicio);
    var fim = parseLocalDate(input.dataFim);
    if (isNaN(inicio.getTime()) || isNaN(fim.getTime())) {
      return { ok: false, error: "Preencha a data inicial e a data final do período." };
    }
    if (fim < inicio) {
      return { ok: false, error: "A data final não pode ser anterior à data inicial." };
    }
    if (inicio.getMonth() !== fim.getMonth() || inicio.getFullYear() !== fim.getFullYear()) {
      return { ok: false, error: "O período precisa ficar dentro de um único mês — assim como na planilha original. Se o período atravessa a virada do mês, calcule cada mês em uma operação separada." };
    }

    var ano = String(inicio.getFullYear());
    var vencimentoIntegral = row.valores[ano];
    if (vencimentoIntegral === undefined) {
      return { ok: false, error: "Ainda não temos a tabela de vencimentos para " + ano + " cadastrada (temos: " + Object.keys(row.valores).join(", ") + "). Peça pro Everton confirmar os valores dessa vigência." };
    }

    var dias = diasEntre(input.dataInicio, input.dataFim);
    var divisor = divisorFor(input.cargo);
    var valor = round2(vencimentoIntegral / divisor * dias);

    var cargoNivelGrau = input.cargo + input.nivel + input.grau;
    var situacaoRef = (input.situacaoRef || "").toUpperCase();
    var temTaxacao = input.taxacaoMes && input.taxacaoAno;
    var taxacaoTxt = temTaxacao ? (input.taxacaoMes + "/" + input.taxacaoAno) : "__/____";

    var ocorrencia = "PAGO " + dias + " DIA" + (dias === 1 ? "" : "S") +
      " DE " + mesAbrevAno(input.dataInicio).toUpperCase() +
      (situacaoRef ? " REF " + situacaoRef : "") +
      " " + cargoNivelGrau +
      " DE " + fmtDataCurta(input.dataInicio) + " A " + fmtDataCurta(input.dataFim) +
      " TX " + taxacaoTxt + ".";

    var contribuicao = calcularContribuicao(valor, input.situacao, {
      outrosRendimentos: input.outrosRendimentos,
      jaDescontado: input.jaDescontado,
    });
    var ipsemg = calcularIpsemg(valor, input.ipsemgOpcao, input.ipsemgServidor59, input.ipsemgConjuge59);

    return {
      ok: true,
      ano: ano,
      vencimentoIntegral: vencimentoIntegral,
      divisor: divisor,
      dias: dias,
      valor: valor,
      ocorrencia: ocorrencia,
      contribuicao: contribuicao,
      ipsemg: ipsemg,
    };
  }

  // ---------- view ----------

  function buildSelectField(labelText, selectId) {
    var field = el("label", "field");
    field.appendChild(el("span", "field-label", "")).textContent = labelText;
    var select = document.createElement("select");
    select.className = "field-input";
    select.id = selectId;
    field.appendChild(select);
    return { field: field, select: select };
  }

  function populateSelect(select, items, toValue, toLabel) {
    var prev = select.value;
    select.innerHTML = "";
    items.forEach(function (item) {
      var opt = document.createElement("option");
      opt.value = toValue(item);
      opt.textContent = toLabel(item);
      select.appendChild(opt);
    });
    if (items.some(function (item) { return String(toValue(item)) === prev; })) select.value = prev;
  }

  // buildView() precisa devolver o nó já de cara (app.js encaixa o retorno
  // direto em #view-root, sem esperar Promise nenhuma — ver TOOL_MODULES/
  // buildToolView) — por isso mostra "Carregando..." primeiro e só monta o
  // formulário de verdade (buildForm) depois que ensureDataLoaded() resolver.
  // "canEdit": só true pra quem administra o setor que hospeda esta
  // ferramenta (coordenador do setor, ou diretor dentro de um setor) —
  // app.js manda isso (ver buildToolView/isAdmin), a mesma checagem usada
  // pras outras edições do Setor de Pagamento. É só pra mostrar ou
  // esconder a tela "Parâmetros do ano": a proteção de verdade continua
  // sendo a RLS do banco (ver migração), não esse parâmetro.
  function buildView(canEdit) {
    var wrap = el("div", "sicalc-view");

    wrap.appendChild(el("p", "sicalc-intro",
      "Calcula o <strong>vencimento básico pró-rata</strong> de um período retroativo (convocação, contrato etc.), a <strong>contribuição previdenciária</strong> (INSS/RPPS), o <strong>desconto do IPSEMG</strong> e monta o texto pra colar na ocorrência do SISAP — do mesmo jeito que a planilha SICALC do Everton. " +
      "A situação \"Aposentado\" ainda não tem contribuição calculada (veja o aviso no resultado)."));

    var loadingBox = el("p", "sicalc-loading", "Carregando tabela de vencimentos…");
    wrap.appendChild(loadingBox);

    var loadErrorBox = el("p", "field-error sicalc-error",
      "Não foi possível carregar os dados da Calculadora. Verifique sua internet e tente de novo (recarregue a página).");
    loadErrorBox.hidden = true;
    wrap.appendChild(loadErrorBox);

    ensureDataLoaded().then(function () {
      loadingBox.hidden = true;
      wrap.appendChild(buildForm(canEdit));
    }).catch(function (err) {
      loadingBox.hidden = true;
      loadErrorBox.hidden = false;
      console.error("Falha ao carregar dados do SICALC:", err);
    });

    return wrap;
  }

  function buildForm(canEdit) {
    var container = el("div", "sicalc-form-wrap");

    var form = el("form", "sicalc-form");

    var cargoField = buildSelectField("Cargo", "sc-cargo");
    var cargaField = buildSelectField("Carga horária", "sc-carga");
    var nivelField = buildSelectField("Nível", "sc-nivel");
    var grauField = buildSelectField("Grau", "sc-grau");

    var row1 = el("div", "field-row field-row-4");
    [cargoField, cargaField, nivelField, grauField].forEach(function (f) { row1.appendChild(f.field); });
    form.appendChild(row1);

    var row2 = el("div", "field-row");
    var dataInicioField = el("label", "field");
    dataInicioField.appendChild(el("span", "field-label", "")).textContent = "Data inicial do período";
    var dataInicioInput = document.createElement("input");
    dataInicioInput.type = "date"; dataInicioInput.className = "field-input"; dataInicioInput.id = "sc-data-inicio"; dataInicioInput.required = true;
    dataInicioField.appendChild(dataInicioInput);
    row2.appendChild(dataInicioField);

    var dataFimField = el("label", "field");
    dataFimField.appendChild(el("span", "field-label", "")).textContent = "Data final do período";
    var dataFimInput = document.createElement("input");
    dataFimInput.type = "date"; dataFimInput.className = "field-input"; dataFimInput.id = "sc-data-fim"; dataFimInput.required = true;
    dataFimField.appendChild(dataFimInput);
    row2.appendChild(dataFimField);
    form.appendChild(row2);

    var row3 = el("div", "field-row");
    var situacaoField = buildSelectField("Situação funcional", "sc-situacao");
    row3.appendChild(situacaoField.field);

    var taxacaoField = el("div", "field");
    taxacaoField.appendChild(el("span", "field-label", "")).textContent = "Incluído na taxação de";
    var taxacaoRow = el("div", "sicalc-taxacao-row");
    var taxacaoMes = document.createElement("select");
    taxacaoMes.className = "field-input"; taxacaoMes.id = "sc-taxacao-mes";
    SICALC_MESES.forEach(function (nome, idx) {
      var opt = document.createElement("option");
      opt.value = pad2(idx + 1);
      opt.textContent = nome;
      taxacaoMes.appendChild(opt);
    });
    var taxacaoAno = document.createElement("input");
    taxacaoAno.type = "number"; taxacaoAno.className = "field-input"; taxacaoAno.id = "sc-taxacao-ano";
    taxacaoAno.placeholder = "Ano"; taxacaoAno.min = "2020"; taxacaoAno.max = "2100";
    taxacaoRow.appendChild(taxacaoMes);
    taxacaoRow.appendChild(taxacaoAno);
    taxacaoField.appendChild(taxacaoRow);
    row3.appendChild(taxacaoField);
    form.appendChild(row3);

    var row4 = el("div", "field-row field-row-4");
    var ipsemgOpcaoField = buildSelectField("IPSEMG", "sc-ipsemg-opcao");
    [
      { value: "nao", label: "Não descontar IPSEMG" },
      { value: "servidor", label: "Descontar só do servidor" },
      { value: "servidor_conjuge", label: "Descontar do servidor e cônjuge" },
    ].forEach(function (o) {
      var opt = document.createElement("option");
      opt.value = o.value; opt.textContent = o.label;
      ipsemgOpcaoField.select.appendChild(opt);
    });
    row4.appendChild(ipsemgOpcaoField.field);

    var idadeServidorField = buildSelectField("Idade do servidor", "sc-idade-servidor");
    var idadeConjugeField = buildSelectField("Idade do cônjuge", "sc-idade-conjuge");
    [idadeServidorField, idadeConjugeField].forEach(function (f) {
      ["Até 58 anos", "59 anos ou mais"].forEach(function (label) {
        var opt = document.createElement("option");
        opt.value = label; opt.textContent = label;
        f.select.appendChild(opt);
      });
      row4.appendChild(f.field);
    });
    form.appendChild(row4);

    var avancado = document.createElement("details");
    avancado.className = "sicalc-avancado";
    var avancadoSummary = document.createElement("summary");
    avancadoSummary.textContent = "Avançado (só pra situações com contribuição INSS — Convocado/Contrato)";
    avancado.appendChild(avancadoSummary);
    var avancadoRow = el("div", "field-row");
    var outrosRendimentosField = el("label", "field");
    outrosRendimentosField.appendChild(el("span", "field-label", "")).textContent = "Outros rendimentos recebidos nesse mês";
    var outrosRendimentosInput = document.createElement("input");
    outrosRendimentosInput.type = "number"; outrosRendimentosInput.step = "0.01"; outrosRendimentosInput.min = "0";
    outrosRendimentosInput.className = "field-input"; outrosRendimentosInput.id = "sc-outros-rendimentos"; outrosRendimentosInput.placeholder = "0,00";
    outrosRendimentosField.appendChild(outrosRendimentosInput);
    avancadoRow.appendChild(outrosRendimentosField);
    var jaDescontadoField = el("label", "field");
    jaDescontadoField.appendChild(el("span", "field-label", "")).textContent = "INSS/RPPS já descontado nesse mês";
    var jaDescontadoInput = document.createElement("input");
    jaDescontadoInput.type = "number"; jaDescontadoInput.step = "0.01"; jaDescontadoInput.min = "0";
    jaDescontadoInput.className = "field-input"; jaDescontadoInput.id = "sc-ja-descontado"; jaDescontadoInput.placeholder = "0,00";
    jaDescontadoField.appendChild(jaDescontadoInput);
    avancadoRow.appendChild(jaDescontadoField);
    avancado.appendChild(avancadoRow);
    avancado.appendChild(el("p", "field-hint", "")).textContent =
      "Usado só pra achar a faixa certa quando o servidor já recebeu outro valor no mesmo mês, e pra não descontar de novo o que já foi descontado. Deixe em branco (0) se não se aplica.";
    form.appendChild(avancado);

    var submitRow = el("div", "sicalc-submit-row");
    var submitBtn = document.createElement("button");
    submitBtn.type = "submit"; submitBtn.className = "btn btn-primary";
    submitBtn.textContent = "Calcular";
    submitRow.appendChild(submitBtn);
    form.appendChild(submitRow);

    var errorBox = el("p", "field-error sicalc-error", "");
    errorBox.hidden = true;
    form.appendChild(errorBox);

    container.appendChild(form);

    var resultBox = el("div", "sicalc-result");
    resultBox.hidden = true;
    container.appendChild(resultBox);

    // ---- wiring das listas em cascata ----

    function refreshCarga() {
      var cargo = cargoField.select.value;
      populateSelect(cargaField.select, cargasHorariasFor(cargo), function (c) { return c; }, function (c) { return c; });
      refreshNivel();
    }
    function refreshNivel() {
      var cargo = cargoField.select.value, carga = cargaField.select.value;
      populateSelect(nivelField.select, niveisFor(cargo, carga), function (n) { return n; }, function (n) { return String(n); });
      refreshGrau();
    }
    function refreshGrau() {
      var cargo = cargoField.select.value, carga = cargaField.select.value, nivel = Number(nivelField.select.value);
      populateSelect(grauField.select, grausFor(cargo, carga, nivel), function (g) { return g; }, function (g) { return g; });
    }

    populateSelect(cargoField.select, allCargos(), function (c) { return c; }, cargoLabel);
    cargoField.select.addEventListener("change", refreshCarga);
    cargaField.select.addEventListener("change", refreshNivel);
    nivelField.select.addEventListener("change", refreshGrau);
    refreshCarga();

    populateSelect(situacaoField.select, SICALC_SITUACOES, function (s) { return SICALC_SITUACOES.indexOf(s); }, function (s) {
      return s.codigo + " - " + s.nome + (s.contribuicao === "nao-suportado" ? " (sem contribuição)" : "");
    });

    var today = new Date();
    taxacaoAno.value = String(today.getFullYear());

    // ---- submit ----

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var situacao = SICALC_SITUACOES[Number(situacaoField.select.value)];
      var resultado = calcular({
        cargo: cargoField.select.value,
        cargaHoraria: cargaField.select.value,
        nivel: Number(nivelField.select.value),
        grau: grauField.select.value,
        dataInicio: dataInicioInput.value,
        dataFim: dataFimInput.value,
        situacaoRef: situacao ? situacao.ref : "",
        situacao: situacao,
        taxacaoMes: taxacaoMes.value,
        taxacaoAno: taxacaoAno.value,
        outrosRendimentos: outrosRendimentosInput.value,
        jaDescontado: jaDescontadoInput.value,
        ipsemgOpcao: ipsemgOpcaoField.select.value,
        ipsemgServidor59: idadeServidorField.select.value === "59 anos ou mais",
        ipsemgConjuge59: idadeConjugeField.select.value === "59 anos ou mais",
      });

      if (!resultado.ok) {
        errorBox.textContent = resultado.error;
        errorBox.hidden = false;
        resultBox.hidden = true;
        return;
      }
      errorBox.hidden = true;
      renderResultado(resultBox, resultado, situacao);
    });

    if (canEdit) container.appendChild(buildAdminSection(refreshCarga));

    return container;
  }

  // ---------- "Parâmetros do ano" (admin): importar uma vigência nova de
  // vencimentos (colar em bloco) + editar as faixas de contribuição e o
  // IPSEMG. Só chamada quando buildForm(true) — ver isAdmin() em app.js. A
  // proteção de verdade é a RLS (ver migração); esconder isso daqui é só
  // pra não oferecer um botão que o banco ia recusar mesmo. ----------

  function buildAdminSection(refreshCarga) {
    var section = document.createElement("details");
    section.className = "sicalc-avancado sicalc-admin";
    var summary = document.createElement("summary");
    summary.textContent = "Parâmetros do ano (vencimentos, faixas e IPSEMG)";
    section.appendChild(summary);

    section.appendChild(buildImportBlock(refreshCarga));
    section.appendChild(buildFaixasBlock());

    return section;
  }

  function buildImportBlock(refreshCarga) {
    var box = el("div", "sicalc-admin-block");
    box.appendChild(el("h4", "sicalc-admin-title", "Importar vencimentos de uma vigência"));
    box.appendChild(el("p", "field-hint", "")).textContent =
      "Cole as linhas copiadas do Excel: cargo, carga horária, nível, grau, valor — uma combinação por linha, nessa ordem. Cole com TAB entre as colunas (é o que o Excel já usa ao copiar células) pra não ter confusão nenhuma com a vírgula decimal.";

    var anoField = el("label", "field");
    anoField.appendChild(el("span", "field-label", "")).textContent = "Ano desta vigência";
    var anoInput = document.createElement("input");
    anoInput.type = "number"; anoInput.className = "field-input"; anoInput.id = "sp-ano";
    anoInput.placeholder = String(new Date().getFullYear() + 1);
    anoInput.min = "2000"; anoInput.max = "2100";
    anoField.appendChild(anoInput);
    box.appendChild(anoField);

    var pasteField = el("label", "field");
    pasteField.appendChild(el("span", "field-label", "")).textContent = "Colar aqui";
    var pasteArea = document.createElement("textarea");
    pasteArea.className = "field-input sicalc-admin-paste";
    pasteArea.id = "sp-paste";
    pasteArea.rows = 8;
    pasteArea.placeholder = "AEB\t30H\t1\tA\t3800,00\nAEB\t30H\t1\tB\t3895,00\n…";
    pasteField.appendChild(pasteArea);
    box.appendChild(pasteField);

    var btnRow = el("div", "sicalc-submit-row");
    var validarBtn = document.createElement("button");
    validarBtn.type = "button"; validarBtn.className = "btn btn-ghost"; validarBtn.id = "sp-validar";
    validarBtn.textContent = "Validar";
    btnRow.appendChild(validarBtn);
    var confirmarBtn = document.createElement("button");
    confirmarBtn.type = "button"; confirmarBtn.className = "btn btn-primary"; confirmarBtn.id = "sp-confirmar";
    confirmarBtn.textContent = "Confirmar importação";
    confirmarBtn.disabled = true;
    btnRow.appendChild(confirmarBtn);
    box.appendChild(btnRow);

    var previewBox = el("div", "sicalc-admin-preview");
    previewBox.hidden = true;
    box.appendChild(previewBox);

    var pendingRows = null;

    validarBtn.addEventListener("click", function () {
      confirmarBtn.disabled = true;
      pendingRows = null;
      previewBox.hidden = false;
      previewBox.innerHTML = "";

      var ano = anoInput.value.trim();
      if (!/^\d{4}$/.test(ano)) {
        previewBox.appendChild(el("p", "field-error", "")).textContent = "Preencha o ano (4 dígitos) antes de validar.";
        return;
      }
      var texto = pasteArea.value;
      if (!texto.trim()) {
        previewBox.appendChild(el("p", "field-error", "")).textContent = "Cole as linhas antes de validar.";
        return;
      }

      var resultado = parseVencimentosPaste(texto, knownComboSet());
      var resumo = el("p", "sicalc-admin-summary", "");
      resumo.textContent = resultado.rows.length + " linha" + (resultado.rows.length === 1 ? "" : "s") +
        " pronta" + (resultado.rows.length === 1 ? "" : "s") + " pra importar, " +
        resultado.errors.length + " erro" + (resultado.errors.length === 1 ? "" : "s") + ".";
      previewBox.appendChild(resumo);

      resultado.warnings.forEach(function (w) {
        previewBox.appendChild(el("p", "field-hint", "")).textContent = w;
      });

      if (resultado.rows.length) {
        var faltam = missingCombosCount(resultado.rows);
        if (faltam > 0) {
          previewBox.appendChild(el("p", "field-hint", "")).textContent =
            "Atenção: " + faltam + " combinação" + (faltam === 1 ? "" : "ões") + " da tabela atual não apareceu" +
            (faltam === 1 ? "" : "ram") + " no texto colado — ficará" + (faltam === 1 ? "" : "ão") +
            " sem valor pra " + ano + " até você importar o resto.";
        }
      }

      if (resultado.errors.length) {
        var wrap = el("div", "acessos-table-wrap");
        var table = document.createElement("table");
        table.className = "acessos-table";
        var thead = document.createElement("thead");
        thead.innerHTML = "<tr><th>Linha</th><th>Texto</th><th>Problema</th></tr>";
        table.appendChild(thead);
        var tbody = document.createElement("tbody");
        resultado.errors.slice(0, 50).forEach(function (e) {
          var tr = document.createElement("tr");
          var tdLinha = document.createElement("td"); tdLinha.textContent = String(e.linha);
          var tdTexto = document.createElement("td"); tdTexto.textContent = e.texto;
          var tdMotivo = document.createElement("td"); tdMotivo.textContent = e.motivo;
          tr.appendChild(tdLinha); tr.appendChild(tdTexto); tr.appendChild(tdMotivo);
          tbody.appendChild(tr);
        });
        table.appendChild(tbody);
        wrap.appendChild(table);
        previewBox.appendChild(wrap);
        if (resultado.errors.length > 50) {
          previewBox.appendChild(el("p", "field-hint", "")).textContent =
            "Mostrando só os primeiros 50 erros — corrija esses, valide de novo, e o resto aparece.";
        }
      }

      if (!resultado.errors.length && resultado.rows.length) {
        pendingRows = resultado.rows.map(function (r) {
          return { cargo: r.cargo, cargaHoraria: r.cargaHoraria, nivel: r.nivel, grau: r.grau, valor: r.valor, ano: ano };
        });
        confirmarBtn.disabled = false;
      }
    });

    confirmarBtn.addEventListener("click", function () {
      if (!pendingRows || !pendingRows.length) return;
      confirmarBtn.disabled = true;
      confirmarBtn.textContent = "Importando…";
      Store.importSicalcVencimentos(pendingRows).then(function () {
        return ensureDataLoaded(true);
      }).then(function () {
        confirmarBtn.textContent = "Confirmar importação";
        pasteArea.value = "";
        pendingRows = null;
        previewBox.innerHTML = "";
        previewBox.appendChild(el("p", "sicalc-admin-success", "")).textContent =
          "Importação concluída! A calculadora já está usando os valores novos.";
        if (refreshCarga) refreshCarga();
      }).catch(function (err) {
        confirmarBtn.disabled = false;
        confirmarBtn.textContent = "Confirmar importação";
        previewBox.appendChild(el("p", "field-error", "")).textContent =
          "Não foi possível salvar: " + ((err && err.message) || "erro desconhecido") + ". Tente de novo.";
        console.error("Falha ao importar vencimentos do SICALC:", err);
      });
    });

    return box;
  }

  function buildFaixasBlock() {
    var box = el("div", "sicalc-admin-block");
    box.appendChild(el("h4", "sicalc-admin-title", "Faixas de contribuição (INSS / RPPS) e IPSEMG"));
    box.appendChild(el("p", "field-hint", "")).textContent =
      "Esses valores raramente mudam (diferente do vencimento, que muda toda vigência) — edite só quando o Everton confirmar uma faixa nova.";

    var statusBox = el("p", "sicalc-admin-loading", "Carregando faixas…");
    box.appendChild(statusBox);

    var wrap = el("div", "acessos-table-wrap");
    wrap.hidden = true;
    var table = document.createElement("table");
    table.className = "acessos-table";
    var thead = document.createElement("thead");
    thead.innerHTML = "<tr><th>Faixa</th><th>Mínimo (R$)</th><th>Máximo (R$)</th><th>Alíquota (%)</th><th>Dedução (R$)</th></tr>";
    table.appendChild(thead);
    var tbody = document.createElement("tbody");
    table.appendChild(tbody);
    wrap.appendChild(table);
    box.appendChild(wrap);

    var ipsemgRow = el("div", "field-row field-row-4 sicalc-admin-ipsemg-row");
    ipsemgRow.hidden = true;
    function numField(labelText, id) {
      var field = el("label", "field");
      field.appendChild(el("span", "field-label", "")).textContent = labelText;
      var input = document.createElement("input");
      input.type = "number"; input.step = "0.01"; input.className = "field-input"; input.id = id;
      field.appendChild(input);
      ipsemgRow.appendChild(field);
      return input;
    }
    var ipsemgBaseInput = numField("IPSEMG — alíquota base (%)", "sp-ipsemg-base");
    var ipsemgIdadeInput = numField("IPSEMG — alíquota 59+ (%)", "sp-ipsemg-idade");
    var ipsemgTetoInput = numField("IPSEMG — teto (R$)", "sp-ipsemg-teto");
    box.appendChild(ipsemgRow);

    var saveRow = el("div", "sicalc-submit-row");
    var saveBtn = document.createElement("button");
    saveBtn.type = "button"; saveBtn.className = "btn btn-primary";
    saveBtn.textContent = "Salvar alterações";
    saveBtn.disabled = true;
    saveRow.appendChild(saveBtn);
    box.appendChild(saveRow);

    var saveMsg = el("p", "sicalc-admin-success", "");
    saveMsg.hidden = true;
    box.appendChild(saveMsg);
    var saveErr = el("p", "field-error", "");
    saveErr.hidden = true;
    box.appendChild(saveErr);

    var faixaRows = []; // {id, minInput, maxInput, aliquotaInput, deducaoInput}

    function renderFaixas(faixas) {
      tbody.innerHTML = "";
      faixaRows = [];
      faixas.forEach(function (f) {
        var tr = document.createElement("tr");
        var tdLabel = document.createElement("td");
        tdLabel.textContent = f.tipo.toUpperCase() + " — faixa " + (f.ordem + 1);
        tr.appendChild(tdLabel);

        function cell(value, placeholder) {
          var td = document.createElement("td");
          var input = document.createElement("input");
          input.type = "number"; input.step = "0.01"; input.className = "field-input sicalc-admin-cell-input";
          if (value !== null && value !== undefined) input.value = value;
          if (placeholder) input.placeholder = placeholder;
          td.appendChild(input);
          tr.appendChild(td);
          return input;
        }

        var minInput = cell(f.min);
        var maxInput = cell(f.max === Infinity ? "" : f.max, "sem limite");
        var aliquotaInput = cell(round2(f.aliquota * 100));
        var deducaoInput = cell(f.deducao);
        tbody.appendChild(tr);
        faixaRows.push({ id: f.id, minInput: minInput, maxInput: maxInput, aliquotaInput: aliquotaInput, deducaoInput: deducaoInput });
      });
    }

    Promise.all([Store.getSicalcPrevidFaixas(), Store.getSicalcIpsemg()]).then(function (results) {
      statusBox.hidden = true;
      wrap.hidden = false;
      ipsemgRow.hidden = false;
      saveBtn.disabled = false;
      renderFaixas(results[0]);
      var ipsemg = results[1];
      if (ipsemg) {
        ipsemgBaseInput.value = round2(ipsemg.aliquotaBase * 100);
        ipsemgIdadeInput.value = round2(ipsemg.aliquotaIdade59 * 100);
        ipsemgTetoInput.value = ipsemg.teto;
      }
    }).catch(function (err) {
      statusBox.textContent = "Não foi possível carregar as faixas. Recarregue a página e tente de novo.";
      console.error("Falha ao carregar faixas do SICALC:", err);
    });

    saveBtn.addEventListener("click", function () {
      saveMsg.hidden = true;
      saveErr.hidden = true;

      var faixaPatches = [];
      for (var i = 0; i < faixaRows.length; i++) {
        var fr = faixaRows[i];
        var min = Number(fr.minInput.value);
        var maxRaw = fr.maxInput.value.trim();
        var max = maxRaw === "" ? Infinity : Number(maxRaw);
        var aliquota = Number(fr.aliquotaInput.value) / 100;
        var deducao = Number(fr.deducaoInput.value);
        if (isNaN(min) || min < 0 || (max !== Infinity && (isNaN(max) || max <= min)) ||
            isNaN(aliquota) || aliquota <= 0 || aliquota >= 1 || isNaN(deducao) || deducao < 0) {
          saveErr.hidden = false;
          saveErr.textContent = "Linha " + (i + 1) + " da tabela de faixas tem um valor inválido (mínimo/máximo/alíquota/dedução) — confira antes de salvar.";
          return;
        }
        faixaPatches.push({ id: fr.id, min: min, max: max, aliquota: aliquota, deducao: deducao });
      }
      var ipsemgBase = Number(ipsemgBaseInput.value) / 100;
      var ipsemgIdade = Number(ipsemgIdadeInput.value) / 100;
      var ipsemgTeto = Number(ipsemgTetoInput.value);
      if (isNaN(ipsemgBase) || ipsemgBase <= 0 || ipsemgBase >= 1 ||
          isNaN(ipsemgIdade) || ipsemgIdade <= 0 || ipsemgIdade >= 1 ||
          isNaN(ipsemgTeto) || ipsemgTeto <= 0) {
        saveErr.hidden = false;
        saveErr.textContent = "Os valores do IPSEMG precisam ser números válidos (alíquotas entre 0 e 100%, teto maior que zero).";
        return;
      }

      saveBtn.disabled = true;
      saveBtn.textContent = "Salvando…";
      Promise.all(
        faixaPatches.map(function (p) { return Store.updateSicalcPrevidFaixa(p.id, p); }).concat([
          Store.updateSicalcIpsemg({ aliquotaBase: ipsemgBase, aliquotaIdade59: ipsemgIdade, teto: ipsemgTeto }),
        ])
      ).then(function () {
        return ensureDataLoaded(true);
      }).then(function () {
        saveBtn.disabled = false;
        saveBtn.textContent = "Salvar alterações";
        saveMsg.hidden = false;
        saveMsg.textContent = "Faixas e IPSEMG atualizados — a calculadora já está usando os valores novos.";
      }).catch(function (err) {
        saveBtn.disabled = false;
        saveBtn.textContent = "Salvar alterações";
        saveErr.hidden = false;
        saveErr.textContent = "Não foi possível salvar: " + ((err && err.message) || "erro desconhecido") + ". Tente de novo.";
        console.error("Falha ao salvar faixas/IPSEMG do SICALC:", err);
      });
    });

    return box;
  }

  function renderResultado(container, r, situacao) {
    container.innerHTML = "";
    container.hidden = false;

    var grid = el("div", "sicalc-result-grid");
    function stat(label, value) {
      var box = el("div", "sicalc-stat");
      box.appendChild(el("span", "sicalc-stat-label", "")).textContent = label;
      box.appendChild(el("span", "sicalc-stat-value", "")).textContent = value;
      grid.appendChild(box);
    }
    stat("Vencimento básico integral (" + r.ano + ")", money(r.vencimentoIntegral));
    stat("Divisor", String(r.divisor));
    stat("Dias calculados", String(r.dias));
    container.appendChild(grid);

    function destaqueBox(label, valor, verba) {
      var d = el("div", "sicalc-valor-destaque");
      d.appendChild(el("span", "sicalc-valor-label", "")).textContent = label + (verba ? " (verba " + verba + ")" : "");
      d.appendChild(el("span", "sicalc-valor-numero", "")).textContent = money(valor);
      container.appendChild(d);
    }

    destaqueBox("Vencimento básico pró-rata", r.valor, SICALC_VERBAS.vencimentoBasico);

    if (r.contribuicao.ok) {
      destaqueBox("Contribuição " + r.contribuicao.tabela + " (" + (r.contribuicao.aliquota * 100).toFixed(1).replace(".0", "") + "% − dedução " + money(r.contribuicao.deducao) + ")", r.contribuicao.valor, SICALC_VERBAS.contribuicao);
    } else {
      container.appendChild(el("p", "sicalc-not-implemented", "")).textContent = r.contribuicao.motivo;
    }

    if (r.ipsemg.valor > 0) {
      destaqueBox("IPSEMG — titular", r.ipsemg.titular32 + r.ipsemg.titular1, SICALC_VERBAS.ipsemgTitular);
      if (r.ipsemg.conjuge32 > 0 || r.ipsemg.conjuge1 > 0) {
        destaqueBox("IPSEMG — cônjuge", r.ipsemg.conjuge32 + r.ipsemg.conjuge1, SICALC_VERBAS.ipsemgConjuge);
      }
    }

    if (r.contribuicao.ok) {
      var liquido = round2(r.valor - r.contribuicao.valor - r.ipsemg.valor);
      destaqueBox("Valor líquido estimado (pró-rata − contribuição − IPSEMG)", liquido, null);
    }

    var ocorrenciaField = el("div", "field");
    ocorrenciaField.appendChild(el("span", "field-label", "")).textContent = "Texto para a ocorrência (SISAP)";
    var textarea = document.createElement("textarea");
    textarea.className = "field-input sicalc-ocorrencia-text";
    textarea.rows = 2;
    textarea.value = r.ocorrencia;
    ocorrenciaField.appendChild(textarea);

    var copyRow = el("div", "sicalc-copy-row");
    var copyBtn = document.createElement("button");
    copyBtn.type = "button";
    copyBtn.className = "btn btn-ghost";
    copyBtn.textContent = "Copiar texto";
    copyBtn.addEventListener("click", function () {
      var text = textarea.value;
      var done = function () { copyBtn.textContent = "Copiado!"; setTimeout(function () { copyBtn.textContent = "Copiar texto"; }, 1500); };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done).catch(function () { textarea.focus(); textarea.select(); });
      } else {
        textarea.focus();
        textarea.select();
      }
    });
    copyRow.appendChild(copyBtn);
    ocorrenciaField.appendChild(copyRow);

    if (!situacao || !situacao.refConfirmado) {
      ocorrenciaField.appendChild(el("p", "field-hint", "")).textContent =
        "Situação funcional \"" + (situacao ? situacao.nome : "") + "\" ainda não foi confirmada com o Everton — revise o texto acima (o campo é editável) antes de colar no SISAP.";
    }
    container.appendChild(ocorrenciaField);

    var aviso = el("p", "sicalc-note", "");
    aviso.textContent = "Esta calculadora só soma vencimento básico (R.B.) — se o período também tiver A.E.C./A.E.J. retroativo, a contribuição e o IPSEMG acima ficam subestimados (a planilha original soma os três antes de aplicar as faixas). \"Outros rendimentos do mês\" e \"já descontado\" (campo Avançado) ficam 0 se você não preencher.";
    container.appendChild(aviso);
  }

  global.Sicalc = {
    calcular: calcular,
    calcularContribuicao: calcularContribuicao,
    calcularIpsemg: calcularIpsemg,
    buildView: buildView,
    money: money,
    // Chamado pela tela "Parâmetros do ano" depois de importar/editar
    // algo, pra próxima vez que a Calculadora abrir buscar os dados
    // atualizados em vez do cache (que, sem isso, só expira recarregando
    // a página).
    invalidate: function () { dataReady = null; },
  };
})(window);
