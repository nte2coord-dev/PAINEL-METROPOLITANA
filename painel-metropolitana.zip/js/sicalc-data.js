// Dados de referencia do SICALC. A partir desta mudanca, a tabela de
// vencimentos, as faixas de contribuicao previdenciaria (INSS/RPPS) e os
// valores do IPSEMG NAO ficam mais hardcoded aqui — moraram pro banco
// (tabelas sicalc_vencimentos / sicalc_previd_faixas / sicalc_ipsemg, ver
// supabase/migrations/20261007000000_sicalc_data_tables.sql), porque esses
// numeros mudam todo ano (vigencia salarial nova) e o Everton precisa
// conseguir atualizar sem pedir uma mudanca de codigo pra cada vigencia.
// Quem edita esses valores agora e a tela "Parametros do ano" (dentro da
// Calculadora de Pagamento) — ver README.
//
// SICALC_VENCIMENTOS / SICALC_PREVID / SICALC_IPSEMG abaixo comecam vazios
// de proposito e sao PREENCHIDOS EM TEMPO DE EXECUCAO por js/sicalc.js
// (funcao ensureDataLoaded, que busca do Supabase via Store) assim que a
// Calculadora e aberta — por isso sao "var", nao "const": js/sicalc.js
// precisa poder reatribuir o valor depois que os dados chegam do banco.
// NUNCA edite valores aqui pra atualizar uma vigencia: isso nao tem efeito
// nenhum (o loader sobrescreve de qualquer jeito) — use a tela "Parametros
// do ano".
var SICALC_VENCIMENTOS = [];
var SICALC_PREVID = { rpps: [], inss: [] };
var SICALC_IPSEMG = { aliquotaBase: 0, aliquotaIdade59: 0, teto: 0 };

// Nome descritivo de cada codigo de cargo (pra exibir no formulario). PEBS
// fica sem nome (null) porque nao encontramos essa expansao confirmada na
// planilha — o formulario mostra so o codigo nesse caso, em vez de chutar.
// Isso aqui NAO muda de ano pra ano (e so um texto de apoio), por isso
// continua sendo uma constante normal do codigo, nao algo editavel pela
// tela "Parametros do ano".
const SICALC_CARGOS = {
  "ASB": "Auxiliar de Serviços de Educação Básica",
  "ASE": "Assistente de Educação",
  "ATB": "Assistente Técnico de Educação Básica",
  "ANE": "Analista Educacional",
  "ANEI": "Analista Educacional - Função de Inspeção Escolar",
  "AEB": "Analista de Educação Básica",
  "EEB": "Especialista em Educação Básica",
  "PEB": "Professor de Educação Básica",
  "PEBS": null,
  "TDE": "Técnico da Educação",
};

// Situacoes funcionais: codigos e nomes tirados direto do dropdown da propria
// planilha (TABELAS!O1:O24) — "01" e "16" sao dois codigos diferentes com o
// mesmo nome "Efetivo" na planilha original (por isso mostramos o codigo
// junto, pra nao confundir os dois). "contribuicao" diz qual tabela de
// desconto previdenciario usar (ver SICALC_PREVID) — mapeado a partir da
// formula real da aba PREVID (N3/N4/N5 e a checagem de "28"):
//   N3 = OR(N2="01",N2="16",N2="20",N2="26") -> tabela rpps
//   N4 = OR(N2="04",N2="40")                 -> tabela quebrada na planilha
//   N5 = OR(N2="02",N2="21")                 -> tabela inss (confirmada)
//   N2="28"                                  -> mesma tabela rpps
// "20"/"26"/"40" aparecem na formula mas nao existem mais no dropdown atual
// (provavelmente codigos antigos) — por isso nao tem entrada pra eles aqui.
// "ref" (pro texto de ocorrencia) so foi confirmado pra "Convocado"; os
// outros usam o proprio nome sem tentar adivinhar a forma gramatical certa.
const SICALC_SITUACOES = [
  { codigo: "01", nome: "Efetivo", contribuicao: "rpps", ref: "Efetivo", refConfirmado: false },
  { codigo: "02", nome: "Convocado", contribuicao: "inss", ref: "Convocação", refConfirmado: true },
  { codigo: "04", nome: "Aposentado", contribuicao: "nao-suportado", ref: "Aposentado", refConfirmado: false },
  { codigo: "16", nome: "Efetivo", contribuicao: "rpps", ref: "Efetivo", refConfirmado: false },
  { codigo: "21", nome: "Contrato", contribuicao: "inss", ref: "Contrato", refConfirmado: false },
  { codigo: "28", nome: "Nomeado", contribuicao: "rpps", ref: "Nomeado", refConfirmado: false },
];

const SICALC_MESES = [
  "Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
  "Jul", "Ago", "Set", "Out", "Nov", "Dez",
];

// Codigos de verba (SISAP) pra cada linha do calculo — uteis pra lançar o
// valor certo no sistema depois de calcular aqui. 2916/7837 vêm da propria
// aba VERBAS do SICALC; 7732/8716 vêm do DAVI_EVOLUÇÃO.xlsm do Everton.
const SICALC_VERBAS = {
  vencimentoBasico: 2916,
  contribuicao: 7837,
  ipsemgTitular: 7732,
  ipsemgConjuge: 8716,
};
