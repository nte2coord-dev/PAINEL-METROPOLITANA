# Leitor do Diário Oficial de MG — SRE Metropolitana A

Esse pacote é só a parte que LÊ o Diário do Executivo de Minas Gerais e
extrai os atos de pessoal (férias-prêmio, licenças, afastamentos,
designações, etc.) da SRE Metropolitana A — a mesma lógica usada no
Painel DIPE, sem o resto da tela (Lauda, CTC etc.).

## O que ele faz, em uma frase

Recebe PDF(s) do Diário do Executivo → devolve uma lista de servidores
(nome, MaSP, cargo, admissão, escola/município, tipo de ato, etc.), cada
um com uma nota de confiança ("alta" ou "revisar") e, quando precisa de
revisão, o motivo exato escrito — nunca um aviso genérico.

## Por que só a Metropolitana A

Por desenho: o programa reconhece e descarta deliberadamente conteúdo de
qualquer outra SRE (B, C, ...). Isso é intencional, não uma limitação —
se o seu uso precisar de outras regionais, isso exige trabalho adicional
de mapeamento de formato, não é só "tirar um filtro".

## Arquivos deste pacote

```
src/
  types.ts                          — tipos (RegistroDiario, LogEntrada, TIPOS_ATO_DIARIO, ...)
  data/sreSchoolLists.ts            — listas oficiais de escolas por SRE (usadas pra evitar vazamento entre regionais)
  utils/
    diarioParser.ts                 — PONTO DE ENTRADA principal (parsearAtosDiario, extrairPaginasDiario)
    diarioMetropolitanaA.ts         — extratores especializados (tabela larga, acumulação, lotação)
    conferenciaDiarioGenerator.ts   — gera um .docx de "Conferência Geral" (opcional)
    minutaParser.ts                 — extração de texto de PDF + fallback de OCR
    pdfExtraction.ts                — geometria nativa do PDF (ordem de leitura por coluna)
    ocrPipeline.ts                  — OCR via Tesseract (só roda quando o PDF não tem texto nativo bom)
    fileSupport.ts                  — detecta se um arquivo é PDF/imagem suportada
    minutaSegmentation.ts           — dependência interna de minutaParser.ts (não precisa mexer)
    sreSchoolRegistry.ts            — confere se uma escola pertence exclusivamente à Metropolitana B
    fieldValidators.ts              — validação de MaSP/nome/cargo/órgão
    normalizers.ts                  — normalização de texto (acentos, maiúsculas, etc.)
```

## Dependências de npm

```
npm install pdfjs-dist tesseract.js docx
```

(`docx` só é necessário se você for usar `conferenciaDiarioGenerator.ts`
— se não quiser o relatório Word, pode remover esse arquivo e a
dependência.)

## Como usar (API pública)

```ts
import { extrairPaginasDiario, parsearAtosDiario, TIPOS_ATO_DIARIO } from "./utils/diarioParser";

// 1. Os PDFs vêm de um <input type="file">, por exemplo.
const files: File[] = /* ... */;

// 2. Extrai o texto de cada página (com fallback de OCR quando necessário).
const { paginas, logs: logsLeitura } = await extrairPaginasDiario(files, (progresso, mensagem) => {
  console.log(progresso, mensagem); // opcional, pra barra de progresso
});

// 3. Roda o parser sobre as páginas já extraídas.
const tiposAtivos = TIPOS_ATO_DIARIO.map((t) => t.id); // ou filtre os tipos que te interessam
const { registros, logs } = parsearAtosDiario(paginas, tiposAtivos);

// `registros` é RegistroDiario[] — cada um com:
//   nome_servidor, masp, cargo, admissao, municipio, localidade_escola,
//   tipo_ato, tipo_label, numero_ato, confianca ("alta" | "revisar"),
//   problemas_validacao (string[] — SEMPRE com o motivo exato quando != [])
//   fonte_pagina, pagina_jornal, texto_legal, ...

// `logs` é LogEntrada[] — trilha de auditoria completa (o que foi
// descartado, recuperado, ou ficou duvidoso, e por quê).
```

## Princípios importantes pra quem for integrar isso

Esses não são detalhes de implementação — são a razão de o programa ser
confiável. Se uma IA for adaptar este código pra outro painel, ela
precisa preservar isso:

1. **Nunca inventa dado.** Se um campo não pôde ser lido com segurança,
   fica vazio/REVISAR com o motivo escrito — nunca um valor "chutado".
2. **Nunca deixa um servidor real sumir em silêncio.** Toda MaSP
   publicada no ato, mesmo que não tenha virado um registro limpo, gera
   pelo menos um log de auditoria (e, quando possível, um registro
   "revisar" com o motivo).
3. **Distingue "cuidado de rotina" de "erro de verdade".** Um dado
   extraído de tabela (formato menos estruturado) é sempre marcado
   "revisar" por precaução — isso não é bug, é o programa sendo
   honesto sobre o que não tem 100% de certeza. `problemas_validacao`
   que começam com `TABELA_LARGA_DIARIO_OK:` são essa rotina; os que
   começam com `TABELA_LARGA_DIARIO:` (sem o `_OK`) são problema de
   verdade, com o motivo.

## Prompt pronto para outra IA implementar isso no seu painel

Copie o bloco abaixo, ajuste o `[...]` com o nome/stack do seu projeto, e
cole pra outra IA (Claude, GPT, Copilot, etc.) junto com os arquivos
desta pasta:

---

> Quero integrar este leitor de Diário Oficial de Minas Gerais (SRE
> Metropolitana A) no meu painel, que é construído em [framework/stack
> do seu projeto, ex.: Next.js + TypeScript / Django + React / etc.].
>
> Os arquivos estão na pasta `leitor-diario-mg/src/`. O ponto de entrada
> é `utils/diarioParser.ts`, com duas funções principais:
> `extrairPaginasDiario(files: File[])` e
> `parsearAtosDiario(paginas, tiposAtivos)`. Leia o `README.md` dessa
> pasta primeiro — ele explica a API e os princípios de confiabilidade
> que este código segue (nunca inventar dado, nunca deixar um servidor
> sumir em silêncio, distinguir "cuidado de rotina" de "erro de
> verdade").
>
> Preciso que você:
> 1. Copie esses arquivos para dentro do meu projeto, ajustando os
>    caminhos de import (`../types`, `./normalizers`, etc.) pra bater
>    com a estrutura de pastas daqui.
> 2. Instale as dependências necessárias: `pdfjs-dist`, `tesseract.js`
>    (e `docx`, só se eu também for usar o gerador de relatório Word).
> 3. Crie uma tela/rota simples onde eu possa subir um PDF do Diário,
>    chamar `extrairPaginasDiario` e depois `parsearAtosDiario`, e ver o
>    resultado numa tabela (nome, MaSP, cargo, confiança, motivo quando
>    não for "alta").
> 4. NÃO mude a lógica de extração/validação desses arquivos sem antes
>    me avisar — eles já foram testados e corrigidos contra Diários
>    reais; qualquer ajuste de regex precisa de um motivo concreto e,
>    se possível, um teste mostrando o caso real que motivou a mudança.
> 5. Rode a suíte de testes (se eu trouxer os arquivos `__tests__/*`
>    também) antes de considerar a integração concluída.
>
> Me avise se algo nos imports não bater (por exemplo, se o meu projeto
> não usa TypeScript, ou se eu não tiver uma das dependências) antes de
> improvisar uma solução diferente.

---
