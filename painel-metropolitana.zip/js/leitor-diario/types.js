// ============================================================================
// types.ts — modelos de dados compartilhados
// ============================================================================
export const TIPO_FERIAS_PREMIO = "FERIAS_PREMIO";
export const TIPO_RETIFICACAO = "RETIFICACAO";
export const TIPO_ANULACAO = "ANULACAO";
export const TIPO_CONCESSAO = "CONCESSAO";
export const TIPO_LABELS = {
    [TIPO_FERIAS_PREMIO]: "Férias-Prêmio Afastamento",
    [TIPO_RETIFICACAO]: "Retificação",
    [TIPO_ANULACAO]: "Anulação",
    [TIPO_CONCESSAO]: "Férias-Prêmio — Concessão",
};
export const TIPOS_LAUDA = [TIPO_FERIAS_PREMIO, TIPO_RETIFICACAO, TIPO_ANULACAO, TIPO_CONCESSAO];
export const EMENTA_FERIAS_PADRAO = "AUTORIZA AFASTAMENTO PARA GOZO DE FÉRIAS PRÊMIO, nos termos da " +
    "Resolução Conjunta SEPLAG/SEE nº8.656, de 02/07/2012, c/c Decreto " +
    "nº43.285, de 23/04/2003, alterado pelo art.1º do Decreto nº48.173, " +
    "de 08/04/2021, ao(s) servidor(es):";
export const TIPOS_ATO_DIARIO = [
    { id: "acumulacao_cargos", label: "Acumulação de Cargos, Empregos e Funções Públicos", categoria: "Acumulação de Cargos" },
    { id: "dispensa_vice_diretor", label: "Dispensa de Vice-Diretor / Função Gratificada", categoria: "Provimento e Função" },
    { id: "designacao", label: "Designação", categoria: "Provimento e Função" },
    { id: "quinquenio", label: "Concessão de Quinquênio", categoria: "Remuneração e Benefícios" },
    { id: "adicional_tempo_servico", label: "Adicional por Tempo de Serviço", categoria: "Remuneração e Benefícios" },
    { id: "abono_familia", label: "Abono Família", categoria: "Remuneração e Benefícios" },
    { id: "abono_permanencia", label: "Abono de Permanência", categoria: "Remuneração e Benefícios" },
    { id: "opcao_remuneratoria", label: "Opção Remuneratória", categoria: "Remuneração e Benefícios" },
    { id: "gratificacao_educacao_especial", label: "Gratificação de Educação Especial", categoria: "Remuneração e Benefícios" },
    { id: "ferias_premio_especie", label: "Férias-Prêmio em Espécie", categoria: "Remuneração e Benefícios" },
    { id: "afastamento_docencia", label: "Afastamento de Docência", categoria: "Afastamentos" },
    { id: "afastamento_regencia", label: "Afastamento de Regência", categoria: "Afastamentos" },
    { id: "afastamento_preliminar_invalidez", label: "Afastamento Preliminar à Invalidez", categoria: "Afastamentos" },
    { id: "afastamento_preliminar_compulsoria", label: "Afastamento Preliminar à Compulsória", categoria: "Afastamentos" },
    { id: "afastamento_preliminar_aposentadoria", label: "Afastamento Preliminar à Aposentadoria", categoria: "Afastamentos" },
    { id: "alteracao_nome", label: "Alteração de Nome", categoria: "Movimentação Funcional" },
    { id: "ampliacao_carga_horaria", label: "Ampliação de Carga Horária", categoria: "Movimentação Funcional" },
    { id: "reducao_carga_horaria", label: "Redução de Carga Horária do Trabalho", categoria: "Movimentação Funcional" },
    { id: "lotacao", label: "Lotação / Mudança de Lotação", categoria: "Movimentação Funcional" },
    { id: "remanejamento", label: "Remanejamento", categoria: "Movimentação Funcional" },
    { id: "remocao", label: "Remoção", categoria: "Movimentação Funcional" },
    { id: "processo_administrativo", label: "Processo Administrativo", categoria: "Atos Processuais" },
    { id: "retificacao", label: "Retificação", categoria: "Atos Processuais" },
    { id: "revogacao", label: "Revogação", categoria: "Atos Processuais" },
    { id: "anulacao", label: "Anulação", categoria: "Atos Processuais" },
    { id: "licenca_maternidade", label: "Licença-Maternidade", categoria: "Licenças" },
    { id: "licenca_paternidade", label: "Licença-Paternidade", categoria: "Licenças" },
    { id: "afastamento_casamento", label: "Afastamento por Motivo de Casamento", categoria: "Afastamentos" },
    { id: "afastamento_luto", label: "Afastamento por Motivo de Luto", categoria: "Afastamentos" },
    { id: "ferias_premio_concessao", label: "Férias-Prêmio — Concessão", categoria: "Remuneração e Benefícios" },
    { id: "ferias_premio_afastamento", label: "Férias-Prêmio — Afastamento", categoria: "Afastamentos" },
    { id: "licenca_saude", label: "Licença para Tratamento de Saúde", categoria: "Saúde do Servidor" },
    { id: "outro", label: "Outro tipo de ato", categoria: "Outros" },
];
export const TIPO_ATO_LABEL = Object.fromEntries(TIPOS_ATO_DIARIO.map((t) => [t.id, t.label]));
