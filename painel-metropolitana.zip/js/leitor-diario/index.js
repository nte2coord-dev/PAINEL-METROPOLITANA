// Ponto de entrada único do leitor do Diário Oficial de MG (SRE
// Metropolitana A) — ver README.md original do pacote (mantido junto dos
// arquivos, na pasta leitor-diario-mg-README.md deste mesmo diretório) pra
// quem for mexer aqui. Reexporta só a API pública usada pelo site
// (js/leitor-diario-view.js); os arquivos internos (utils/*) nunca são
// importados direto de fora desta pasta.
export { extrairPaginasDiario, parsearAtosDiario } from "./utils/diarioParser.js";
export { TIPOS_ATO_DIARIO, TIPO_ATO_LABEL } from "./types.js";
