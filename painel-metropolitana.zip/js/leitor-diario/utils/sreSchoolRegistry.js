import { semAcento } from './normalizers.js';
import { ESCOLAS_METROPOLITANA_A, ESCOLAS_METROPOLITANA_B } from '../data/sreSchoolLists.js';
function normNome(v) {
    return semAcento(v || '')
        .toUpperCase()
        .replace(/\bE\s*\.?\s*E\s*\.?\b/g, 'EE')
        .replace(/\bESCOLA\s+ESTADUAL\b/g, 'EE')
        .replace(/[–—-]/g, ' ')
        .replace(/[^A-Z0-9 ]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}
function normCodigo(v) {
    return String(v || '').replace(/\D/g, '').replace(/^0+/, '');
}
const codigosA = new Set(ESCOLAS_METROPOLITANA_A.map((e) => normCodigo(e.codigo)).filter(Boolean));
const codigosB = new Set(ESCOLAS_METROPOLITANA_B.map((e) => normCodigo(e.codigo)).filter(Boolean));
const nomesA = new Set(ESCOLAS_METROPOLITANA_A.map((e) => normNome(e.escola)).filter(Boolean));
const nomesB = new Set(ESCOLAS_METROPOLITANA_B.map((e) => normNome(e.escola)).filter(Boolean));
export function classificarEscolaSre(codigo, nome) {
    const c = normCodigo(codigo || '');
    const n = normNome(nome || '');
    if (c) {
        const a = codigosA.has(c);
        const b = codigosB.has(c);
        if (a && b)
            return 'AMBIGUA';
        if (a)
            return 'A';
        if (b)
            return 'B';
    }
    if (n) {
        const a = nomesA.has(n);
        const b = nomesB.has(n);
        if (a && b)
            return 'AMBIGUA';
        if (a)
            return 'A';
        if (b)
            return 'B';
    }
    return 'DESCONHECIDA';
}
export function escolaEhExclusivaMetropolitanaB(codigo, nome) {
    return classificarEscolaSre(codigo, nome) === 'B';
}
export function escolaEhExclusivaMetropolitanaA(codigo, nome) {
    return classificarEscolaSre(codigo, nome) === 'A';
}
