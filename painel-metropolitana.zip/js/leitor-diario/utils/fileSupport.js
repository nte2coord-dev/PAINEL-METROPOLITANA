// Tipos de arquivo aceitos nos fluxos de leitura documental.
// Fotos baixadas do WhatsApp normalmente chegam como JPG/JPEG; PNG, WEBP e
// JFIF também são aceitos. HEIC/HEIF não entram aqui porque o suporte varia
// entre navegadores e servidores e poderia falhar silenciosamente.
export const ACCEPT_DOCUMENTOS = [
    'application/pdf',
    'image/jpeg',
    'image/png',
    'image/webp',
    '.pdf',
    '.jpg',
    '.jpeg',
    '.jfif',
    '.png',
    '.webp',
].join(',');
const RE_PDF = /\.pdf$/i;
const RE_IMAGEM = /\.(?:jpe?g|jfif|png|webp)$/i;
export function classificarArquivoDocumento(file) {
    const nome = (file.name || '').trim();
    const mime = (file.type || '').toLowerCase();
    if (RE_PDF.test(nome) || mime === 'application/pdf')
        return 'pdf';
    if (RE_IMAGEM.test(nome) || ['image/jpeg', 'image/png', 'image/webp'].includes(mime))
        return 'imagem';
    return 'nao_suportado';
}
export function descricaoTiposAceitos() {
    return 'PDF, JPG, JPEG, JFIF, PNG ou WEBP';
}
