// ============================================================================
// minutaParser.ts — orquestrador da extração de laudas (PDFs ou fotos de minuta).
// Pipeline: extrair texto nativo → avaliar qualidade → OCR se necessário →
// segmentar por servidor → extrair campos POR BLOCO → validar → confiança.
// ============================================================================
import * as pdfjsLib from "pdfjs-dist";
import { TIPO_ANULACAO, TIPO_FERIAS_PREMIO, TIPO_RETIFICACAO, EMENTA_FERIAS_PADRAO, } from "../types.js";
import { normalizarLinha, semAcento, normalizarMasp, normalizarNome, normalizarAdmissao, corrigirTextoRetificacao, slug } from "./normalizers.js";
import { validarNomeServidor, validarMasp, validarOrgao, validarCargo, extrairDatasVigencia, MUNICIPIOS_CONHECIDOS, } from "./fieldValidators.js";
import { segmentarPagina } from "./minutaSegmentation.js";
import { reconstruirLinhas, linhasParaTexto, renderizarPaginaParaCanvas } from "./pdfExtraction.js";
import { avaliarQualidadeTexto, precisaDeOcr, ocrComMultiplasTentativas, limparTextoOcr } from "./ocrPipeline.js";
import { classificarArquivoDocumento } from "./fileSupport.js";
import { escolaEhExclusivaMetropolitanaB } from "./sreSchoolRegistry.js";
if (typeof window !== "undefined" && "GlobalWorkerOptions" in pdfjsLib) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;
}
// ============================================================================
// 1) EXTRAÇÃO DE TEXTO DOS PDFs (nativo + OCR quando necessário)
// ============================================================================
async function carregarImagemEmCanvas(file) {
    // createImageBitmap respeita a orientação EXIF nos navegadores modernos, o
    // que é importante para fotos feitas no celular e baixadas do WhatsApp.
    const bitmap = await createImageBitmap(file);
    const maxDim = 3000;
    const minDim = 1400;
    const maior = Math.max(bitmap.width, bitmap.height);
    let escala = maior > maxDim ? maxDim / maior : 1;
    if (maior * escala < minDim)
        escala = minDim / maior;
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * escala));
    canvas.height = Math.max(1, Math.round(bitmap.height * escala));
    const ctx = canvas.getContext("2d");
    if (!ctx)
        throw new Error("Não foi possível preparar a imagem para OCR.");
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close?.();
    return canvas;
}
export async function extrairTextoPDFs(files, onProgress) {
    const paginas = [];
    const logs = [];
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const tipo = classificarArquivoDocumento(file);
        if (onProgress)
            onProgress(i / files.length, `Lendo arquivo ${i + 1} de ${files.length}: ${file.name}`);
        if (tipo === "nao_suportado") {
            logs.push({
                nivel: "erro", origem: "Leitor de arquivos",
                mensagem: `${file.name}: formato não suportado. Use PDF, JPG, JPEG, JFIF, PNG ou WEBP.`,
            });
            continue;
        }
        try {
            if (tipo === "imagem") {
                const pageProgress = (i + 0.75) / files.length;
                if (onProgress)
                    onProgress(pageProgress, `Aplicando OCR na foto ${file.name}...`);
                const canvas = await carregarImagemEmCanvas(file);
                const ocr = await ocrComMultiplasTentativas(canvas);
                const texto = limparTextoOcr(ocr.texto);
                if (texto.trim().length <= 20) {
                    logs.push({
                        nivel: "aviso", origem: "OCR Imagem", pagina: 1,
                        mensagem: `${file.name}: a foto foi aberta, mas o OCR encontrou pouco texto. Verifique se a imagem está nítida, completa e na posição correta.`,
                    });
                }
                else {
                    logs.push({
                        nivel: ocr.confiancaMedia >= 70 ? "info" : "aviso", origem: "OCR Imagem", pagina: 1,
                        mensagem: `${file.name}: foto processada por OCR (variante: ${ocr.variante}, confiança Tesseract: ${ocr.confiancaMedia.toFixed(0)}%).`,
                    });
                }
                paginas.push({ arquivo: file.name, numero: 1, texto, usouOcr: true });
                continue;
            }
            const arrayBuffer = await file.arrayBuffer();
            const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
            for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
                const pageProgress = (i + pageNum / pdf.numPages) / files.length;
                if (onProgress)
                    onProgress(pageProgress, `Lendo página ${pageNum}/${pdf.numPages} de ${file.name}`);
                const page = await pdf.getPage(pageNum);
                const viewport1 = page.getViewport({ scale: 1 });
                const textContent = await page.getTextContent();
                const [origemX = 0, origemY = 0] = Array.isArray(page.view) ? page.view : [0, 0];
                const linhas = reconstruirLinhas(textContent, Number(origemX) || 0, Number(origemY) || 0);
                let texto = linhasParaTexto(linhas);
                let usouOcr = false;
                const qualidade = avaliarQualidadeTexto(texto, linhas);
                if (precisaDeOcr(qualidade)) {
                    if (onProgress)
                        onProgress(pageProgress, `Qualidade do texto nativo baixa (${(qualidade.pontuacao * 100).toFixed(0)}%) — aplicando OCR em ${file.name}, pág. ${pageNum}...`);
                    try {
                        const canvas = await renderizarPaginaParaCanvas(page, 2.5);
                        const ocr = await ocrComMultiplasTentativas(canvas);
                        const limpo = limparTextoOcr(ocr.texto);
                        if (limpo.trim().length > 20) {
                            texto = limpo;
                            usouOcr = true;
                            logs.push({
                                nivel: "info", origem: "OCR",
                                mensagem: `OCR aplicado em ${file.name}, página ${pageNum} (variante: ${ocr.variante}, ${ocr.passagens ?? 1} passagem(ns), confiança Tesseract: ${ocr.confiancaMedia.toFixed(0)}%). Motivo: ${qualidade.motivos.join("; ") || "qualidade abaixo do limiar"}`,
                                pagina: pageNum,
                            });
                        }
                        else {
                            logs.push({
                                nivel: "aviso", origem: "OCR",
                                mensagem: `OCR não retornou texto útil em ${file.name}, página ${pageNum}; mantendo texto nativo (qualidade ${(qualidade.pontuacao * 100).toFixed(0)}%).`,
                                pagina: pageNum,
                            });
                        }
                    }
                    catch (ocrErr) {
                        logs.push({
                            nivel: "aviso", origem: "OCR",
                            mensagem: `Falha ao rodar OCR em ${file.name}, página ${pageNum}: ${ocrErr?.message || ocrErr}`,
                            pagina: pageNum,
                        });
                    }
                }
                paginas.push({
                    arquivo: file.name, numero: pageNum, texto: texto || "", usouOcr,
                    linhas, larguraPagina: viewport1.width, alturaPagina: viewport1.height,
                });
            }
        }
        catch (err) {
            logs.push({
                nivel: "erro", origem: tipo === "imagem" ? "Leitor de imagem" : "PDF Reader",
                mensagem: `Erro ao ler ${file.name}: ${err?.message || "Falha de leitura"}`,
            });
        }
    }
    if (onProgress)
        onProgress(1.0, "Extração de texto e OCR concluídos");
    return { paginas, logs };
}
// ============================================================================
// 2) EXTRATORES DE CAMPO — operam sobre um BLOCO (não a página inteira)
// ============================================================================
function baseText(txt) { return semAcento(txt).toUpperCase(); }
function detectarTipo(textoAntes, textoDepois) {
    const b = baseText(textoAntes + " " + textoDepois);
    if (b.includes("RETIFICA") || (b.includes("ONDE SE LE") && b.includes("LEIA-SE")))
        return TIPO_RETIFICACAO;
    if (b.includes("ANULA"))
        return TIPO_ANULACAO;
    if (b.includes("FERIAS") || b.includes("AFASTAMENTO"))
        return TIPO_FERIAS_PREMIO;
    return TIPO_RETIFICACAO;
}
function capturaEntre(texto, inicio, fins) {
    const match = inicio.exec(texto);
    if (!match)
        return "";
    const trecho = texto.slice(match.index + match[0].length);
    let fimPos = trecho.length;
    for (const fin of fins) {
        const finMatch = fin.exec(trecho);
        if (finMatch)
            fimPos = Math.min(fimPos, finMatch.index);
    }
    return normalizarLinha(trecho.slice(0, fimPos));
}
/** Extrai o NOME do servidor imediatamente após o MaSP — restrito ao
 *  início do `textoDepois` do bloco, nunca buscando em outro bloco. */
function extrairNomeDoBloco(textoDepois) {
    const inicio = textoDepois.slice(0, 200); // nome sempre está bem no início do bloco
    // Padrão: ", NOME COMPLETO," ou logo após o MaSP com separador
    const m = /^\s*[,:\-–—\s]*([A-ZÀ-Ü][A-ZÀ-Ü'´.\-\s]{3,80}?)(?:\s*[,;]|\s{2,}|$)/i.exec(inicio);
    if (m) {
        const candidato = normalizarNome(m[1]);
        const v = validarNomeServidor(candidato);
        if (v.valido)
            return candidato;
    }
    // Fallback: primeira linha do bloco que passe na validação de nome
    for (const linha of inicio.split("\n")) {
        const candidato = normalizarNome(linha);
        if (validarNomeServidor(candidato).valido)
            return candidato;
    }
    return "";
}
/** Restringe a busca de órgão/escola à MESMA LINHA (usa [ \t] em vez de
 *  \s, que também casa quebras de linha) — corrige o vazamento para texto
 *  de decreto/artigo em linhas seguintes. */
function extrairOrgaoDoBloco(textoAntes, textoDepois) {
    const RE_EE = /\b((?:EE|E\.E\.|ESCOLA ESTADUAL)[ \t]+[A-ZÀ-Ü0-9][ \t\S]{2,55})/i;
    for (const fonte of [textoDepois, textoAntes]) {
        for (const linha of fonte.split("\n")) {
            const m = RE_EE.exec(linha);
            if (m) {
                let cand = normalizarLinha(m[1]);
                cand = cand.replace(/\bE\.\s*E\.?\s*/i, "EE ");
                cand = cand.replace(/\s*[-–—]\s*\d{4,6}\s*$/i, "");
                cand = cand.toUpperCase();
                if (validarOrgao(cand).valido)
                    return cand;
            }
        }
    }
    // Qualquer SRE, não só a Metropolitana A. A versão anterior casava a
    // Metropolitana A LITERALMENTE, de modo que uma lauda de outra regional
    // ("807209 - SRE Juiz de Fora", visto em registro real) saía com o órgão
    // vazio. O nome é LIDO do documento — não há lista fixa de regionais aqui,
    // justamente para não inventar uma SRE que o texto não afirma.
    const sreMatch = /\bSRE\s+([A-ZÀ-Ü][A-Za-zÀ-ÿ]+(?:\s+(?:DE|DA|DO|DOS|DAS|E|[A-ZÀ-Ü][A-Za-zÀ-ÿ]*)){0,3})/i
        .exec(textoAntes + textoDepois);
    if (sreMatch) {
        const nome = normalizarLinha(sreMatch[1]).toUpperCase().replace(/\s+/g, " ").trim();
        if (nome)
            return `SRE ${nome}`;
    }
    return "";
}
function extrairMunicipioDoBloco(textoAntes, textoDepois) {
    const combinado = baseText(textoAntes.slice(-150) + " " + textoDepois.slice(0, 150));
    for (const chave of Object.keys(MUNICIPIOS_CONHECIDOS)) {
        if (combinado.includes(chave))
            return MUNICIPIOS_CONHECIDOS[chave];
    }
    return ""; // nunca inventa — se não há evidência explícita, fica vazio
}
function extrairCargoAdmissaoDoBloco(textoDepois) {
    const trecho = textoDepois.slice(0, 250);
    let m = /CARG[OÓ]\s*(\d{1,2})\s*[-–—:]?\s*([A-Z0-9/.-]+)/i.exec(trecho);
    if (m) {
        const cargo = m[2].trim().toUpperCase();
        if (validarCargo(cargo).valido)
            return [cargo, normalizarAdmissao(m[1])];
    }
    // Só a sigla funcional (m[1]) — a descrição por extenso que às vezes
    // segue ("- PROFESSOR DE EDUCAÇÃO BÁSICA") nunca entra no campo CARGO.
    m = /\b([A-Z]{2,4}\d[A-Z0-9]*(?:\/FGD-\d)?)\s*[-–—/]?\s*ADM\.?\s*(\d{1,2})(?:\s*[-–—]\s*[A-ZÀ-Ü\s]{4,60})?/i.exec(trecho);
    if (m) {
        const cargoUp = m[1].toUpperCase();
        if (validarCargo(cargoUp).valido)
            return [cargoUp, normalizarAdmissao(m[2])];
    }
    // Código solto reconhecível, sem admissão explícita — não inventa "01"
    const codeMatch = /\b([A-Z]{2,5}\d[A-Z0-9]*(?:\/FGD-\d)?)\b/i.exec(trecho);
    if (codeMatch) {
        const cargoUp = codeMatch[1].toUpperCase();
        if (validarCargo(cargoUp).valido) {
            const admMatch = /\bADM\.?\s*(\d{1,2})\b/i.exec(trecho);
            return [cargoUp, admMatch ? normalizarAdmissao(admMatch[1]) : ""];
        }
    }
    return ["", ""];
}
function extrairAtoPublicacaoDoBloco(textoAntes, textoDepois) {
    const combinado = `${textoAntes} ${textoDepois}`;
    let ato = "";
    let pub = "";
    const mAto = /Ato\s*n[º°o]?\s*:?\s*(\d{1,5})\s*(?:\/|\s)\s*(20\d{2})/i.exec(combinado);
    if (mAto)
        ato = `${mAto[1]}/${mAto[2]}`;
    const mPub = /Publicado\s+em\s*:?\s*_?\s*(\d{2}\/\d{2}\/\d{4})/i.exec(combinado);
    if (mPub)
        pub = mPub[1];
    return [ato, pub];
}
function extrairPeriodoQuinquenio(trecho) {
    let periodo = "";
    let quinquenio = "";
    // "1º período ... 2º período ..." com datas próprias = dois períodos
    // GENUINAMENTE distintos (janelas separadas) — mantém o formato original.
    // Sem essa marcação, "NN períodos de 15 dias" é só a mesma duração
    // expressa em quinzenas e deve virar meses (2 quinzenas = 1 mês).
    const doisPeriodosComDatas = /1[ºo°]\s+per[ií]odo[\s\S]*?2[ºo°]\s+per[ií]odo/i.test(trecho);
    const mPer = /(\d{1,2})\s+per[ií]odos?\s+de\s+15\s+dias/i.exec(trecho);
    if (mPer && doisPeriodosComDatas) {
        periodo = `${mPer[1].padStart(2, "0")} PERÍODOS DE 15 DIAS`;
    }
    else if (mPer) {
        const meses = Math.max(1, Math.round(parseInt(mPer[1], 10) / 2));
        periodo = `${String(meses).padStart(2, "0")} ${meses === 1 ? "MÊS" : "MESES"}`;
    }
    else {
        const mP = /(?:p?or)\s+(\d{1,2})\s+(m[eê]s(?:es)?)/i.exec(trecho);
        if (mP) {
            const n = parseInt(mP[1], 10);
            periodo = `${String(n).padStart(2, "0")} ${n === 1 ? "MÊS" : "MESES"}`;
        }
    }
    const mQ = /\b(\d)\s*[º°o]?\s*quinq/i.exec(trecho);
    if (mQ) {
        quinquenio = `${mQ[1]}º`;
    }
    return [periodo, quinquenio];
}
/** Retificação de data: mantém somente a data (DD/MM/AAAA) do texto —
 *  a lauda-modelo mostra "ONDE SE LÊ: 03/08/2026", não a frase inteira de
 *  onde a data foi extraída. Quando não há data (troca de cargo,
 *  localidade, nome etc.), devolve "" e o chamador preserva o texto
 *  original. */
function extrairApenasData(texto) {
    const m = /\b(\d{2}\/\d{2}\/\d{4})\b/.exec(texto || "");
    return m ? m[1] : "";
}
function extrairDatasRetificacaoDoBloco(textoDepois) {
    const ondeRaw = capturaEntre(textoDepois, /Onde\s+se\s+l[eê]\s*:\s*/i, [/\(reda[cç][aã]o anterior\)/i, /Leia-se\s*:/i]);
    const leiaRaw = capturaEntre(textoDepois, /Leia-se\s*:\s*/i, [/\(reda[cç][aã]o correta\)/i, /\bData\s*:/i]);
    const cOnde = corrigirTextoRetificacao(ondeRaw);
    const cLeia = corrigirTextoRetificacao(leiaRaw);
    const [periodo, quinquenio] = extrairPeriodoQuinquenio(leiaRaw + " " + ondeRaw);
    return {
        onde: extrairApenasData(cOnde.texto) || cOnde.texto || "",
        leia: extrairApenasData(cLeia.texto) || cLeia.texto || "",
        periodo, quinquenio,
        correcaoAplicada: cOnde.corrigido || cLeia.corrigido,
    };
}
/** Extrai a(s) data(s) de vigência do bloco usando classificação por
 *  contexto (fieldValidators.classificarDatasNoTexto) — nunca usa "a
 *  última data da página" nem aceita uma data de decreto. */
function extrairVigenciaDoBloco(textoDepois) {
    const datas = extrairDatasVigencia(textoDepois);
    if (datas.length === 0)
        return "";
    if (datas.length === 1)
        return datas[0];
    return datas.join(" e "); // preserva os dois períodos, nunca descarta o segundo
}
const CAMPOS_OBRIGATORIOS = {
    [TIPO_FERIAS_PREMIO]: ["masp", "nome", "cargo", "periodo", "quinquenio"],
    [TIPO_RETIFICACAO]: ["masp", "nome", "onde_se_le", "leia_se"],
    [TIPO_ANULACAO]: ["masp", "nome", "periodo"],
};
function calcularConfianca(reg, tipo) {
    const problemas = [];
    const vMasp = validarMasp(reg.masp || "");
    if (!vMasp.valido)
        problemas.push(`MaSP: ${vMasp.motivo}`);
    const vNome = validarNomeServidor(reg.nome || "");
    if (!vNome.valido)
        problemas.push(`Nome: ${vNome.motivo}`);
    if (reg.orgao) {
        const vOrgao = validarOrgao(reg.orgao);
        if (!vOrgao.valido)
            problemas.push(`Órgão: ${vOrgao.motivo}`);
        if (escolaEhExclusivaMetropolitanaB("", reg.orgao)) {
            problemas.push("Órgão identificado exclusivamente na lista da SRE Metropolitana B — confira a página; não tratar como Metropolitana A.");
        }
    }
    if (reg.cargo) {
        const vCargo = validarCargo(reg.cargo);
        if (!vCargo.valido)
            problemas.push(`Cargo: ${vCargo.motivo}`);
    }
    const obrigatorios = CAMPOS_OBRIGATORIOS[tipo] || [];
    for (const campo of obrigatorios) {
        const valor = reg[campo];
        if (!valor)
            problemas.push(`Campo obrigatório "${campo}" ausente para o tipo de ato`);
    }
    if (problemas.length > 0)
        return { nivel: "revisar", problemas };
    return { nivel: "alta", problemas: [] };
}
// ============================================================================
// 4) MONTAGEM DO REGISTRO A PARTIR DE UM BLOCO
// ============================================================================
let _contadorId = 0;
function proximoId() {
    _contadorId += 1;
    return `srv_${Date.now().toString(36)}_${_contadorId}`;
}
function montarRegistroDoBloco(bloco, pagina) {
    const logs = [];
    const { textoAntes, textoDepois, masp: maspBruto } = bloco;
    const masp = normalizarMasp(maspBruto);
    const nome = extrairNomeDoBloco(textoDepois);
    const [cargo, admissao] = extrairCargoAdmissaoDoBloco(textoDepois);
    const municipio = extrairMunicipioDoBloco(textoAntes, textoDepois);
    const orgao = extrairOrgaoDoBloco(textoAntes, textoDepois);
    const [atoRef, publicado] = extrairAtoPublicacaoDoBloco(textoAntes, textoDepois);
    const tipo = detectarTipo(textoAntes, textoDepois);
    const anoAtual = new Date().getFullYear();
    let onde = "", leia = "", periodo = "", quinquenio = "", aPartir = "";
    let titulo = "", ementa = "";
    if (tipo === TIPO_RETIFICACAO) {
        const r = extrairDatasRetificacaoDoBloco(textoDepois);
        onde = r.onde;
        leia = r.leia;
        periodo = r.periodo;
        quinquenio = r.quinquenio;
        titulo = `RETIFICAÇÃO - ATO Nº /${anoAtual}.`;
        ementa = `RETIFICA NO ATO DE FÉRIAS PRÊMIO - AFASTAMENTO de férias prêmio, a seguir, a parte que se refere a: ${atoRef ? `ato nº ${atoRef}, ` : ""}${publicado ? `publicado em ${publicado}.` : ""}`.trim();
        if (r.correcaoAplicada) {
            logs.push({ nivel: "info", origem: "correção automática", mensagem: `Correção segura aplicada no texto de retificação de ${nome || masp}` });
        }
    }
    else if (tipo === TIPO_ANULACAO) {
        [periodo, quinquenio] = extrairPeriodoQuinquenio(textoDepois);
        aPartir = extrairVigenciaDoBloco(textoDepois);
        titulo = `ANULAÇÃO - ATO Nº /${anoAtual}.`;
        ementa = `ANULA NO ATO DE FÉRIAS PRÊMIO - AFASTAMENTO a parte referente aos servidores: ${atoRef ? `ato nº ${atoRef} ` : ""}${publicado ? `publicado em ${publicado}.` : ""}`.trim();
    }
    else {
        [periodo, quinquenio] = extrairPeriodoQuinquenio(textoDepois);
        aPartir = extrairVigenciaDoBloco(textoDepois);
        titulo = `FÉRIAS-PRÊMIO AFASTAMENTO - ATO Nº /${anoAtual}.`;
        ementa = EMENTA_FERIAS_PADRAO;
    }
    if (!masp && !nome) {
        // Regra do usuário: NENHUMA PÁGINA PODE DESAPARECER. Antes este bloco
        // era descartado (registro: null) e a página simplesmente sumia da
        // tabela — quebrando a garantia "47 páginas de PDF = 47 registros".
        // Agora sempre criamos um registro para a página, com os campos que
        // não deram para ler em branco e status "revisar", para o usuário
        // preencher manualmente (possível manuscrito/cursiva ou OCR insuficiente).
        logs.push({
            nivel: "aviso", origem: "parser",
            mensagem: `Nenhum servidor identificado em ${pagina.arquivo}, página ${pagina.numero} — registro mantido para revisão manual (possível manuscrito/cursiva ou OCR insuficiente).`,
            pagina: pagina.numero,
        });
        const registroNaoLido = {
            id: proximoId(),
            selecionar: false,
            tipo_ato: tipo,
            titulo_ato: titulo,
            ementa_ato: ementa,
            municipio, orgao, masp: "", nome: "", cargo, admissao,
            periodo, quinquenio, a_partir_de: aPartir,
            onde_se_le: onde, leia_se: leia,
            ato_referenciado: atoRef, publicado_em: publicado,
            fonte_arquivo: pagina.arquivo,
            fonte_pagina: pagina.numero,
            bloco_origem: bloco.textoCompleto,
            texto_origem: pagina.texto,
            confianca: "revisar",
            problemas_validacao: ["Não identificado: possível manuscrito/cursiva ou OCR insuficiente. Preencha manualmente."],
            origem_campos: {
                masp: pagina.usouOcr ? "ocr" : "nativo",
                nome: pagina.usouOcr ? "ocr" : "nativo",
                orgao: pagina.usouOcr ? "ocr" : "nativo",
                cargo: pagina.usouOcr ? "ocr" : "nativo",
            },
            historico_alteracoes: [],
        };
        return { registro: registroNaoLido, logs };
    }
    const registroParcial = {
        masp, nome, orgao, cargo, periodo, quinquenio, onde_se_le: onde, leia_se: leia,
    };
    const { nivel, problemas } = calcularConfianca(registroParcial, tipo);
    const origem_campos = {
        masp: pagina.usouOcr ? "ocr" : "nativo",
        nome: pagina.usouOcr ? "ocr" : "nativo",
        orgao: pagina.usouOcr ? "ocr" : "nativo",
        cargo: pagina.usouOcr ? "ocr" : "nativo",
    };
    if (problemas.length > 0) {
        logs.push({
            nivel: "aviso", origem: "parser",
            mensagem: `${pagina.arquivo}, página ${pagina.numero} (${nome || masp || "servidor sem nome"}): ${problemas.join(" | ")}`,
            pagina: pagina.numero,
        });
    }
    const registro = {
        id: proximoId(),
        selecionar: nivel === "alta",
        tipo_ato: tipo,
        titulo_ato: titulo,
        ementa_ato: ementa,
        municipio, orgao, masp, nome, cargo, admissao,
        periodo, quinquenio, a_partir_de: aPartir,
        onde_se_le: onde, leia_se: leia,
        ato_referenciado: atoRef, publicado_em: publicado,
        fonte_arquivo: pagina.arquivo,
        fonte_pagina: pagina.numero,
        bloco_origem: bloco.textoCompleto,
        texto_origem: pagina.texto,
        confianca: nivel,
        problemas_validacao: problemas,
        origem_campos,
        historico_alteracoes: [],
    };
    return { registro, logs };
}
// ============================================================================
// 5) PIPELINE PÚBLICO — uma página pode gerar 0, 1 ou N registros
// ============================================================================
export function parsearPaginaMinuta(pagina) {
    const logs = [];
    const registros = [];
    const blocos = segmentarPagina(pagina.texto);
    for (const bloco of blocos) {
        const res = montarRegistroDoBloco(bloco, pagina);
        logs.push(...res.logs);
        if (res.registro)
            registros.push(res.registro);
    }
    // O fluxo de minuta informado pela DIPE é 1 página = 1 servidor. Se mais
    // de uma identidade sobreviver às barreiras anti-signatário, não escolhemos
    // uma no chute: todas permanecem visíveis para auditoria, DESMARCADAS e com
    // a página explicitamente marcada como ambígua.
    const identidades = new Set(registros.map((r) => `${r.masp}|${r.nome}`));
    if (identidades.size > 1) {
        const motivo = `Página ${pagina.numero}: mais de um servidor detectado; o fluxo exige 1 página = 1 servidor`;
        for (const reg of registros) {
            reg.selecionar = false;
            reg.confianca = "revisar";
            reg.problemas_validacao = Array.from(new Set([...(reg.problemas_validacao || []), motivo]));
        }
        logs.push({ nivel: "aviso", origem: "Minuta/Identidade", pagina: pagina.numero, mensagem: motivo });
    }
    return { registros, logs };
}
export function parsearPaginasMinuta(paginas) {
    const listRegs = [];
    const logs = [];
    for (const pagina of paginas) {
        const res = parsearPaginaMinuta(pagina);
        logs.push(...res.logs);
        listRegs.push(...res.registros);
    }
    return { registros: listRegs, logs };
}
/** Reprocessa UM registro a partir do texto de origem já guardado nele —
 *  usado pelo botão "Reprocessar este registro" da tabela. Não perde o
 *  histórico de edição manual anterior. */
export function reprocessarRegistro(registro) {
    if (!registro.texto_origem)
        return registro;
    const blocos = segmentarPagina(registro.texto_origem);
    // Localiza o bloco cujo MaSP bate com o do registro atual (mesmo servidor)
    const alvo = blocos.find((b) => normalizarMasp(b.masp) === registro.masp) || blocos[0];
    if (!alvo)
        return registro;
    const paginaFake = {
        arquivo: registro.fonte_arquivo || "",
        numero: registro.fonte_pagina || 0,
        texto: registro.texto_origem,
        usouOcr: false,
    };
    const { registro: novo } = montarRegistroDoBloco(alvo, paginaFake);
    if (!novo)
        return registro;
    return {
        ...novo,
        id: registro.id,
        selecionar: registro.selecionar,
        historico_alteracoes: [
            ...(registro.historico_alteracoes || []),
            { campo: "(reprocessamento completo)", valorAnterior: "-", valorNovo: "-", dataHora: new Date().toISOString(), origem: "reprocessamento" },
        ],
    };
}
export { slug };
