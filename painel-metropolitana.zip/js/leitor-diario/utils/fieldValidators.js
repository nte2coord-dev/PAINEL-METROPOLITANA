// ============================================================================
// fieldValidators.ts — validação real de campos extraídos. Nenhuma função
// aqui "inventa" dado: cada validador só diz se um valor já extraído é
// PLAUSÍVEL, e produz um motivo legível quando rejeita.
// ============================================================================
import { semAcento } from "./normalizers.js";
// ── Nome do servidor ─────────────────────────────────────────────────────────
/** Termos que NUNCA podem ser aceitos como nome de servidor — cobre
 *  exatamente o bug relatado ("ADMISSAO" aparecendo como nome) e a
 *  classe inteira de rótulos de formulário/termos administrativos que
 *  podem ser confundidos com um nome por um regex frouxo. */
export const TERMOS_PROIBIDOS_NOME = [
    "ADMISSAO", "ADMISSÃO", "ADM", "CARGO", "MUNICIPIO", "MUNICÍPIO",
    "LOCALIDADE", "ORGAO", "ÓRGÃO", "ESCOLA", "ESTADUAL", "SRE",
    "METROPOLITANA", "ATO", "DECRETO", "RESOLUCAO", "RESOLUÇÃO", "ART",
    "ARTIGO", "SERVIDOR", "MASP", "FERIAS", "FÉRIAS", "PREMIO", "PRÊMIO",
    "AFASTAMENTO", "RETIFICACAO", "RETIFICAÇÃO", "ANULACAO", "ANULAÇÃO",
    "ONDE SE LE", "ONDE SE LÊ", "LEIA-SE", "DATA", "PAGINA", "PÁGINA",
    "PUBLICADO", "QUINQUENIO", "QUINQUÊNIO", "PERIODO", "PERÍODO",
];
const TERMOS_PROIBIDOS_SEM_ACENTO = new Set(TERMOS_PROIBIDOS_NOME.map((t) => semAcento(t).toUpperCase()));
/** Valida se `candidato` é um nome de pessoa plausível. Regras:
 *  - pelo menos duas palavras (exceto lista de exceção explícita)
 *  - predominantemente letras (acentos preservados)
 *  - sem dígitos, sem código de cargo isolado, sem termo proibido */
export function validarNomeServidor(candidato, excecoesUmaPalavra = []) {
    const nome = (candidato || "").trim();
    if (!nome)
        return { valido: false, motivo: "nome vazio" };
    const semAc = semAcento(nome).toUpperCase();
    // Termo inteiro (ou qualquer palavra do nome) é um termo proibido
    const palavras = semAc.split(/\s+/).filter(Boolean);
    for (const p of palavras) {
        if (TERMOS_PROIBIDOS_SEM_ACENTO.has(p)) {
            return { valido: false, motivo: `contém termo administrativo "${p}", não é nome de pessoa` };
        }
    }
    if (TERMOS_PROIBIDOS_SEM_ACENTO.has(semAc)) {
        return { valido: false, motivo: `"${nome}" é um termo administrativo, não um nome` };
    }
    if (/\d/.test(nome)) {
        return { valido: false, motivo: "nome contém dígitos" };
    }
    if (palavras.length < 2 && !excecoesUmaPalavra.includes(semAc)) {
        return { valido: false, motivo: "nome com apenas uma palavra" };
    }
    const letras = nome.replace(/[^A-Za-zÀ-ÿ]/g, "").length;
    if (letras < nome.replace(/\s/g, "").length * 0.85) {
        return { valido: false, motivo: "nome com caracteres não alfabéticos em excesso" };
    }
    if (letras < 5) {
        return { valido: false, motivo: "nome muito curto" };
    }
    return { valido: true };
}
// ── MaSP ──────────────────────────────────────────────────────────────────
export function validarMasp(candidato) {
    const digitos = (candidato || "").replace(/\D/g, "");
    if (digitos.length < 6) {
        return { valido: false, motivo: "MaSP com poucos dígitos" };
    }
    if (digitos.length > 10) {
        return { valido: false, motivo: "MaSP com dígitos demais (pode ser data/ato/decreto confundido)" };
    }
    return { valido: true };
}
/** Confere se um trecho de dígitos que PARECE um MaSP não é na verdade
 *  uma data (DD/MM/AAAA sem separador), o número de um ato, ou um decreto —
 *  usado pelo extrator para descartar falsos positivos antes mesmo de gerar
 *  o candidato a MaSP. */
export function pareceMaspEnaoOutraCoisa(trechoAntes, trechoDepois) {
    const antes = semAcento(trechoAntes).toUpperCase().slice(-25);
    if (/\b(DECRETO|RESOLU[CÇ][AÃ]O|ATO\s*N|LEI\s*N|PORTARIA)\b[^A-Z]{0,10}$/i.test(antes)) {
        return false; // dígitos logo após "Decreto nº" etc. não são MaSP
    }
    const depois = semAcento(trechoDepois).toUpperCase().slice(0, 6);
    if (/^\s*DE\s+\d{4}/.test(depois)) {
        return false; // "43.285, de 2003" → é decreto, não MaSP
    }
    return true;
}
// ── Órgão / escola ────────────────────────────────────────────────────────
/** Termos cuja presença no candidato a órgão indica que a captura vazou
 *  para texto legal/fundamentação — nesse caso o campo deve ficar vazio
 *  e o registro marcado para revisão, nunca aceitar o texto misturado. */
const TERMOS_VAZAMENTO_ORGAO = [
    /DECRETO/i, /RESOLU[CÇ][AÃ]O/i, /\bART\.?\s*\d*\b/i, /ARTIGO/i,
    /\bLEI\s+N/i, /PORTARIA/i, /MASP/i, /SERVIDOR/i,
    /ALTERAD[OA]/i, /PELO\s+ART/i, /\bC\/C\b/i,
];
export function validarOrgao(candidato) {
    const org = (candidato || "").trim();
    if (!org)
        return { valido: false, motivo: "órgão vazio" };
    for (const rx of TERMOS_VAZAMENTO_ORGAO) {
        if (rx.test(org)) {
            return {
                valido: false,
                motivo: `órgão contém texto de fundamentação legal ("${org.match(rx)?.[0]}") — captura vazou de linha/bloco diferente`,
            };
        }
    }
    // Mais de um grupo de dígitos separado (além do código único da escola)
    // é forte indício de números de decreto/artigo colados na captura —
    // ex.: "HELENA FENA 02.0.6 ... 1514" tem dois grupos numéricos distintos.
    const gruposDigitos = org.match(/\d[\d.]*\d|\d/g) || [];
    if (gruposDigitos.length > 1) {
        return { valido: false, motivo: "órgão com mais de um grupo numérico — provável número de decreto/artigo misturado" };
    }
    // Órgão plausível tem de 3 a ~70 caracteres e não é majoritariamente dígitos
    const digitos = org.replace(/\D/g, "").length;
    if (digitos > org.length * 0.4) {
        return { valido: false, motivo: "órgão com dígitos em excesso (pode ser código/decreto misturado)" };
    }
    if (org.length > 75) {
        return { valido: false, motivo: "órgão longo demais — provável captura atravessando várias linhas" };
    }
    return { valido: true };
}
// ── Cargo ─────────────────────────────────────────────────────────────────
/** Famílias de prefixo de código de cargo conhecidas na SEE/MG. Usado só
 *  para RECONHECER (não restringir) — qualquer código não listado ainda
 *  passa se tiver o formato geral letras+dígitos(+"/"+FGD-n). */
export const PREFIXOS_CARGO_CONHECIDOS = [
    // As oito carreiras do quadro dos profissionais da Educação Básica
    // (Lei 15.293/2004), mais as grafias que aparecem de fato nas laudas.
    "PEB", // Professor de Educação Básica
    "EEB", // Especialista em Educação Básica
    "AEB", // Analista de Educação Básica
    "ANE", // Analista Educacional
    "ANEI", // Analista Educacional — grafia com I usada nas laudas da SRE
    "ATB", // Assistente Técnico de Educação Básica
    "TDE", // Técnico da Educação
    "ASE", // Assistente de Educação
    "ASB", // Auxiliar de Serviços de Educação Básica
    // Nome anterior do TDE (a Lei 21.710/2015 trocou ATE por TDE). Atos
    // antigos e as retificações que os corrigem ainda trazem ATE.
    "ATE",
    // Abreviações de função que aparecem no Diário, sem nível/grau.
    "D", "DV", "DIV", "FGD",
];
// Sufixo de designação de função colado ao código do cargo com "/": FGD-n
// (função gratificada), e DV/DVI/VICED (Vice-Diretor) — todos vistos de
// fato no Diário junto de cargos PEB/EEB válidos.
// Sufixo de designação de função colado ao código do cargo com "/": FGD-n
// (função gratificada), e DV/DVI/VICED (Vice-Diretor) — vistos de fato no
// Diário junto de cargos PEB/EEB válidos, sempre com dígito no código base
// (ex.: "PEB3P/DV"). Não entra no formato sem dígito nem no "só letras" —
// esses dois já são bem mais permissivos, e aceitar o sufixo ali também
// deixaria passar lixo de 5-6 letras coladas a "/DVI" sem nenhum dígito.
const RE_SUFIXO_DESIGNACAO = "(?:\\/(?:FGD-\\d|DVI?|VICED))?";
const RE_CODIGO_CARGO = /^[A-Z]{1,4}\d?[A-Z]?\d?$/i;
const RE_CODIGO_CARGO_COM_SUFIXO = new RegExp(`^[A-Z]{2,5}\\d[A-Z\\d]*${RE_SUFIXO_DESIGNACAO}$`, "i");
const RE_CODIGO_CARGO_SOMENTE_LETRAS = /^[A-Z]{3,8}$/i;
export function validarCargo(candidato) {
    const cargo = (candidato || "").trim();
    if (!cargo)
        return { valido: false, motivo: "cargo vazio" };
    if (cargo.length > 60) {
        return { valido: false, motivo: "cargo longo demais — provável captura de texto legal" };
    }
    // Aceita tanto o código puro (PEB3H) quanto código + descrição
    // ("PEB3H - PROFESSOR DE EDUCAÇÃO BÁSICA") — separa só em " - " com
    // espaço dos dois lados, nunca em hífen colado como o de "FGD-5".
    const codigoIsolado = cargo.split(/\s+-\s+/)[0].trim();
    const reconhecido = RE_CODIGO_CARGO.test(codigoIsolado) ||
        RE_CODIGO_CARGO_COM_SUFIXO.test(codigoIsolado) ||
        RE_CODIGO_CARGO_SOMENTE_LETRAS.test(codigoIsolado); // ex.: PEIIIO (numeração romana em vez de dígito)
    if (!reconhecido) {
        return { valido: false, motivo: `código de cargo em formato não reconhecido: "${codigoIsolado}"` };
    }
    return { valido: true };
}
// ── Município ─────────────────────────────────────────────────────────────
/** Lista usada SÓ para normalização de grafia (acento/maiúsculas) de um
 *  candidato já encontrado no texto — nunca para "adivinhar" a cidade
 *  quando ela não aparece explicitamente perto do servidor. */
export const MUNICIPIOS_CONHECIDOS = {
    "BELO HORIZONTE": "BELO HORIZONTE",
    RAPOSOS: "RAPOSOS",
    CONTAGEM: "CONTAGEM",
    BETIM: "BETIM",
    SABARA: "SABARÁ",
    IBIRITE: "IBIRITÉ",
    "SANTA LUZIA": "SANTA LUZIA",
    VESPASIANO: "VESPASIANO",
    "SAO JOSE DA LAPA": "SÃO JOSÉ DA LAPA",
    "PEDRO LEOPOLDO": "PEDRO LEOPOLDO",
    "NOVA LIMA": "NOVA LIMA",
    BRUMADINHO: "BRUMADINHO",
    CAETE: "CAETÉ",
    "RIBEIRAO DAS NEVES": "RIBEIRÃO DAS NEVES",
};
const RE_DATA = /\b(\d{2})\/(\d{2})\/(\d{4})\b/g;
const GATILHOS_VIGENCIA = [
    /a\s+partir\s+de/i, /a\s+contar\s+de/i, /com\s+vig[eê]ncia\s+em/i,
    /\bdesde\b/i, /1[ºo°]\s+per[ií]odo/i, /2[ºo°]\s+per[ií]odo/i,
];
const GATILHOS_LEGAIS = [
    /decreto/i, /resolu[cç][aã]o/i, /\bart\.?\s*\d/i, /\blei\s+n/i, /portaria/i,
];
/** Classifica CADA data encontrada no texto pelo contexto que a cerca
 *  (janela de ~45 caracteres antes da data). Quando mais de um tipo de
 *  gatilho aparece na janela (ex.: "Decreto" mais atrás e "a partir de"
 *  logo antes da data), vence o gatilho mais PRÓXIMO da data — nunca dá
 *  prioridade fixa ao termo legal, senão uma vigência perto o bastante de
 *  uma menção a decreto seria classificada errado (bug encontrado nos
 *  testes: "...Decreto nº48.173, de 08/04/2021, a partir de 10/08/2026"
 *  classificava 10/08/2026 como decreto_legal por "Decreto" ainda caber
 *  na janela, mesmo "a partir de" estando mais perto). */
export function classificarDatasNoTexto(texto) {
    const resultado = [];
    let m;
    const rx = new RegExp(RE_DATA);
    while ((m = rx.exec(texto)) !== null) {
        const inicio = Math.max(0, m.index - 45);
        const antes = texto.slice(inicio, m.index);
        const candidatos = [];
        for (const g of GATILHOS_LEGAIS) {
            const ultima = [...antes.matchAll(new RegExp(g.source, g.flags.includes("g") ? g.flags : g.flags + "g"))].pop();
            if (ultima)
                candidatos.push({ pos: ultima.index ?? 0, classe: "decreto_legal" });
        }
        for (const g of GATILHOS_VIGENCIA) {
            const ultima = [...antes.matchAll(new RegExp(g.source, g.flags.includes("g") ? g.flags : g.flags + "g"))].pop();
            if (ultima)
                candidatos.push({ pos: ultima.index ?? 0, classe: "a_partir_de" });
        }
        const mPub = /publicad[oa]\s+em/i.exec(antes);
        if (mPub)
            candidatos.push({ pos: mPub.index, classe: "publicacao" });
        const mAto = /ato\s*n[º°o]?\s*\d/i.exec(antes);
        if (mAto)
            candidatos.push({ pos: mAto.index, classe: "ato_anterior" });
        let classe = "indefinida";
        if (candidatos.length > 0) {
            candidatos.sort((a, b) => b.pos - a.pos); // o de maior posição é o mais próximo da data
            classe = candidatos[0].classe;
        }
        resultado.push({ data: m[0], classe, contextoAntes: antes.trim() });
    }
    return resultado;
}
/** Extrai a(s) data(s) de vigência ("a partir de") do texto, SEM jamais
 *  usar uma data classificada como "decreto_legal". Se dois períodos de
 *  vigência estiverem presentes, preserva os dois — nunca descarta o
 *  segundo. Devolve string vazia (não um palpite) se nenhuma data
 *  claramente rotulada for encontrada. */
export function extrairDatasVigencia(texto) {
    const classificadas = classificarDatasNoTexto(texto);
    return classificadas.filter((d) => d.classe === "a_partir_de").map((d) => d.data);
}
