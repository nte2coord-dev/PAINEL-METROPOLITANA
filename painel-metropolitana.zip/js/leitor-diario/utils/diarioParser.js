// ============================================================================
// diarioParser.ts — extração de atos de servidores do Diário Oficial do
// Executivo de MG (PDF, várias colunas).
//
// Pipeline (versão de texto, sem coordenadas geométricas — ver limitações
// no fim do arquivo):
//   1) delimitação de secretaria ativa (SEE/SEPLAG/outra) por cabeçalho,
//      mantida em ordem de leitura ao longo das páginas;
//   2) dentro de cada trecho SEE/SEPLAG, segmentação em BLOCOS DE ATO
//      (título, "ATO Nº", verbo administrativo de abertura de parágrafo);
//   3) dentro de cada bloco, localização de ocorrências MaSP+nome — o TIPO
//      do ato é classificado UMA VEZ por bloco (nunca por "janela mais
//      próxima" cruzando servidores/blocos diferentes);
//   4) validação de nome/MaSP e bloqueio de confiança "alta" quando há
//      qualquer sinal de contaminação.
//
// Isto substitui a versão anterior, que achatava a página inteira numa
// única string (`pagina.texto.replace(/\s*\n\s*/g, " ")`) e classificava
// pelo gatilho de tipo mais próximo numa janela de 700 caracteres — o que
// permitia que um ato/servidor "vazasse" tipo, cargo ou vigência para o
// próximo, e não distinguia secretaria publicadora nenhuma.
// ============================================================================
import { TIPOS_ATO_DIARIO, TIPO_ATO_LABEL } from "../types.js";
import { normalizarLinha, normalizarMasp, normalizarNome, semAcento, slug } from "./normalizers.js";
import { validarNomeServidor, validarMasp, validarOrgao } from "./fieldValidators.js";
import { extrairTextoPDFs } from "./minutaParser.js";
import { linhasParaTextoDiario, linhasParaTexto } from "./pdfExtraction.js";
import { escolaEhExclusivaMetropolitanaB } from "./sreSchoolRegistry.js";
import { dividirPorSreMetropolitanaA, extrairAcumulacoesMetropolitanaA, extrairLotacaoTabelaMetropolitanaA, extrairTabelaLargaFeriasPremio, temCabecalhoExplicitoMetropolitanaA, ehMetropolitanaA, RE_TABELA_LARGA_CABECALHO, } from "./diarioMetropolitanaA.js";
function baseText(t) { return semAcento(t || "").toUpperCase(); }
// Cabeçalhos que ABREM escopo SEE/SEPLAG — exigem "SECRETARIA DE ESTADO DE"
// (ou "PELA SECRETARIA DE ESTADO DE") por extenso, nunca só palavras soltas
// como "Planejamento, Gestão e Finanças" (que também aparece em unidades de
// outros órgãos, ex.: Polícia Civil).
const RE_ABRE_SEE = /^[ \t]*(?:(?:PELA\s+)?SECRETARIA|SECRET[ÁA]RIA)\s+DE\s+ESTADO\s+DE\s+EDUCA[ÇC][ÃA]O\b/gim;
const RE_ABRE_SEPLAG = /^[ \t]*(?:(?:PELA\s+)?SECRETARIA|(?:ATO\s+DA\s+SENHORA\s+)?SECRET[ÁA]RIA)\s+DE\s+ESTADO\s+DE\s+PLANEJAMENTO\s+E\s+GEST[ÃA]O\b/gim;
// Cabeçalhos que FECHAM o escopo (outra secretaria/seção começou) — inclui
// o catálogo genérico "SECRETARIA DE ESTADO DE X" (X != Educação/Planejamento)
// e as seções nomeadas nos casos de regressão do briefing.
//
// Regressão real (Diário 05/09/2026, pág. 39): o Conselho Estadual de
// Educação (CEE/MG) publica seus próprios pareceres e atos (inclusive um
// "ATO DE LICENÇA À GESTANTE") logo depois da última seção da SEE/MG, sem
// nenhum cabeçalho de secretaria novo — só "Conselho Estadual de\nEducação
// - CEE" (quebrado em duas linhas no PDF). Sem esse cabeçalho na lista, o
// escopo SEE ficava "aberto" e o extrator colava o servidor do CEE/MG
// (outro órgão, sem nenhuma relação com a Metropolitana A) no bloco do
// ato de Licença à Gestante da SEE/MG anterior. `\s+` já cobre a quebra de
// linha entre "de" e "Educação".
const RE_ABRE_OUTRA = /^[ \t]*(?:(?:PELA\s+)?SECRETARIA|SECRET[ÁA]RIA)\s+DE\s+ESTADO\s+DE\s+(?!EDUCA[ÇC][ÃA]O\b|PLANEJAMENTO\s+E\s+GEST[ÃA]O\b)[A-ZÀ-Ü][A-ZÀ-Ü\s]{2,60}|^[ \t]*(?:POL[ÍI]CIA\s+CIVIL|CONTROLADORIA[\s-]GERAL\s+DO\s+ESTADO|PODER\s+JUDICI[ÁA]RIO|EDITAIS\s+E\s+AVISOS|MINIST[ÉE]RIO\s+P[ÚU]BLICO|DEFENSORIA\s+P[ÚU]BLICA|CONSELHO\s+ESTADUAL\s+DE\s+EDUCA[ÇC][ÃA]O)\b/gim;
/** Varre o texto (com quebras de linha preservadas) e devolve os eventos de
 *  troca de secretaria em ordem de posição. Não achata o texto. */
function coletarEventosSecao(texto) {
    const eventos = [];
    for (const [rx, secretaria] of [
        [RE_ABRE_SEE, "SEE"],
        [RE_ABRE_SEPLAG, "SEPLAG"],
        [RE_ABRE_OUTRA, "OUTRA"],
    ]) {
        rx.lastIndex = 0;
        let m;
        while ((m = rx.exec(texto)) !== null) {
            eventos.push({ pos: m.index, secretaria });
            if (m.index === rx.lastIndex)
                rx.lastIndex++;
        }
    }
    eventos.sort((a, b) => a.pos - b.pos);
    return eventos;
}
/** Divide o texto de uma página em trechos rotulados pela secretaria ativa
 *  no momento — `secretariaInicial` é o estado herdado do fim da página
 *  anterior (o Diário não reabre o cabeçalho em toda página). Devolve
 *  também o estado ao final, para a próxima página herdar. */
function dividirPorSecretaria(texto, secretariaInicial) {
    const eventos = coletarEventosSecao(texto);
    if (eventos.length === 0) {
        return { trechos: [{ texto, secretaria: secretariaInicial }], secretariaFinal: secretariaInicial };
    }
    const trechos = [];
    let cursor = 0;
    let atual = secretariaInicial;
    for (const ev of eventos) {
        if (ev.pos > cursor)
            trechos.push({ texto: texto.slice(cursor, ev.pos), secretaria: atual });
        atual = ev.secretaria;
        cursor = ev.pos;
    }
    trechos.push({ texto: texto.slice(cursor), secretaria: atual });
    return { trechos, secretariaFinal: atual };
}
// Marcadores de abertura de um novo bloco de ato — cada um em início de
// linha (^ com flag m), como no Diário real.
// Regressão real (Diário 05/09/2026, pág. 38): "FÉRIAS–PRÊMIO/AFASTAMENTO –
// ATO Nº 616/2026" usa TRAVESSÃO (–, U+2013) entre "FÉRIAS" e "PRÊMIO", não
// o hífen comum. O gatilho de Férias-Prêmio só aceitava `[\s-]?` (espaço OU
// hífen ASCII, no máximo um caractere) — não reconhecia o travessão, então
// este título NUNCA abria bloco novo aqui. O ato inteiro (e mais cinco
// outros: 617 a 621/2026) ficava GRUDADO dentro do bloco anterior
// ("AFASTAMENTO POR MOTIVO DE LUTO – ATO Nº 26/2026"), e a auditoria de
// recuperação (que varre o bloco original, sem cortes) atribuía os
// servidores desses 6 atos individuais a "26/2026" por engano — mesmo
// aparecendo corretamente como REVISAR, o número do ato ficava errado.
const RE_INICIO_BLOCO = /^[ \t]*(?:ATO\s*N[ºo°.]|PORTARIA\s*N[ºo°.]|RETIFICA[ÇC][ÃA]O\b|ANULA[ÇC][ÃA]O\b|REVOGA[ÇC][ÃA]O\b|TORNA\s+SEM\s+EFEITO\b|DESIGNA[ÇC][ÃA]O\b|DISPENSA\b|CONCESS[ÃA]O\b|ABONO\b|ADICIONAL\b|OP[ÇC][ÃA]O\s+REMUNERAT[ÓO]RIA\b|GRATIFICA[ÇC][ÃA]O\b|AMPLIA[ÇC][ÃA]O\b|REDU[ÇC][ÃA]O\b|LOTA[ÇC][ÃA]O\b|MUDAN[ÇC]A\s+DE\s+LOTA[ÇC][ÃA]O\b|REMANEJAMENTO\b|REMO[ÇC][ÃA]O\b|LICEN[ÇC]A\b|AFASTAMENTO\b|ALTERA[ÇC][ÃA]O\s+DE\s+NOME\b|PROCESSO\s+ADMINISTRATIVO\b|F[ÉE]RIAS[\s\-–—\/]*PR[ÊE]MIO\b|\d{2,3}(?:\.\d{3})*\s*-\s|O\s+(?:SUBSECRET[ÁA]RI[OA]|SECRET[ÁA]RI[OA]|SUPERINTENDENTE|DIRETOR[A]?|GOVERNADOR[A]?)\b|A\s+(?:SUBSECRET[ÁA]RIA|SECRET[ÁA]RIA|SUPERINTENDENTE|SUPERINTEND[ÊE]NCIA|DIRETORA)\b)/gim;
/** Divide um trecho (já delimitado a uma única secretaria) em blocos de
 *  ato. Sem marcador nenhum, devolve o trecho inteiro como um bloco só —
 *  o classificador de tipo ainda roda sobre ele normalmente. */
function segmentarBlocosAto(texto) {
    RE_INICIO_BLOCO.lastIndex = 0;
    const posicoes = [];
    let m;
    while ((m = RE_INICIO_BLOCO.exec(texto)) !== null) {
        posicoes.push(m.index);
        if (m.index === RE_INICIO_BLOCO.lastIndex)
            RE_INICIO_BLOCO.lastIndex++;
    }
    if (posicoes.length === 0)
        return [{ texto, inicio: 0 }];
    const blocos = [];
    if (posicoes[0] > 0)
        blocos.push({ texto: texto.slice(0, posicoes[0]), inicio: 0 });
    for (let i = 0; i < posicoes.length; i++) {
        const fim = i + 1 < posicoes.length ? posicoes[i + 1] : texto.length;
        blocos.push({ texto: texto.slice(posicoes[i], fim), inicio: posicoes[i] });
    }
    return blocos;
}
// V24: o PDF do Diário pode devolver duas colunas intercaladas na mesma linha.
// Nessa situação, um segundo título de ato pode aparecer DENTRO do bloco já
// segmentado. Antes de procurar MaSP, corta o bloco no primeiro título novo.
// Assim um servidor de Licença/Luto/Casamento nunca é atribuído à Anulação
// anterior apenas porque o extrator geométrico colou as colunas.
//
// Regressão real (Diário 05/09/2026, pág. 38): uma RETIFICAÇÃO sempre cita o
// ato ORIGINAL que está corrigindo — "...a parte que se refere a: ato nº
// 57/2026, publicado em..." — e esse "ato nº X/YYYY" minúsculo, de
// referência, também batia no gatilho de "título embutido" quando o ato
// citado era de Férias-Prêmio (o mais comum), cortando o bloco ANTES da
// tabela de servidores da própria Retificação e apagando todo mundo dela
// sem nenhum aviso. Um título de verdade nunca tem mais que uma pontuação
// curta ("-", "–", ":") entre o gatilho e o próprio "ATO Nº" — uma citação
// de referência sempre tem uma frase inteira no meio ("publicado em",
// "a que se refere", etc.). Encurtar o vão de 90 para 20 caracteres deixa
// as colagens de verdade (sempre um traço curto) intactas e para de
// confundir citação com título novo.
const RE_TITULO_EMBUTIDO = /(?:ANULA[ÇC][ÃA]O|RETIFICA[ÇC][ÃA]O|LICEN[ÇC]A[\s-]*(?:MATERNIDADE|PATERNIDADE)|AFASTAMENTO\s+(?:POR\s+MOTIVO\s+DE\s+(?:CASAMENTO|LUTO)|PRELIMINAR)|F[ÉE]RIAS[\s–—\/-]*PR[ÊE]MIO(?:[\s–—\/-]*(?:AFASTAMENTO|CONCESS[ÃA]O|CONVERS[ÃA]O\s+EM\s+ESP[ÉE]CIE))?|ABONO\s+DE\s+PERMAN[ÊE]NCIA|LOTA[ÇC][ÃA]O|TORNA\s+SEM\s+EFEITO)[^\n]{0,20}?ATO\s*N[ºo°.]*\s*[\d.]+\s*\/\s*\d{4}/gim;
function recortarBlocoNoProximoTitulo(texto) {
    const matches = [...texto.matchAll(RE_TITULO_EMBUTIDO)];
    if (matches.length <= 1)
        return texto;
    const primeiro = matches[0].index ?? 0;
    for (let i = 1; i < matches.length; i++) {
        const pos = matches[i].index ?? -1;
        if (pos > primeiro + 20)
            return texto.slice(0, pos);
    }
    return texto;
}
const GATILHOS_TIPO = [
    { id: "acumulacao_cargos", padrao: /ACUMULA[ÇC][ÃA]O\s+DE\s+CARGOS,?\s+EMPREGOS\s+E\s+FUN[ÇC][ÕO]ES\s+P[ÚU]BLICOS/i, prioridade: 20 },
    { id: "dispensa_vice_diretor", padrao: /DISPENSA\s+(?:DE\s+)?VICE\s*[-–]?\s*DIRETOR|DISPENSA\s+(?:DE\s+)?FUN[ÇC][ÃA]O\s+GRATIFICADA/i, prioridade: 10 },
    { id: "quinquenio", padrao: /CONCEDE\s+QUINQU[EÊ]NIO|CONCESS[ÃA]O\s+DE\s+QUINQU[EÊ]NIO/i, prioridade: 10 },
    { id: "designacao", padrao: /\bDESIGNA(?:[ÇC][ÃA]O)?\b/i, prioridade: 3 },
    { id: "adicional_tempo_servico", padrao: /ADICIONAL\s+POR\s+TEMPO\s+DE\s+SERVI[ÇC]O/i, prioridade: 8 },
    { id: "abono_familia", padrao: /ABONO\s+FAM[IÍ]LIA|ABONO\s+DE\s+FAM[IÍ]LIA/i, prioridade: 6 },
    { id: "abono_permanencia", padrao: /ABONO\s+DE\s+PERMAN[ÊE]NCIA/i, prioridade: 8 },
    { id: "opcao_remuneratoria", padrao: /OP[ÇC][ÃA]O\s+REMUNERAT[ÓO]RIA/i, prioridade: 8 },
    { id: "gratificacao_educacao_especial", padrao: /GRATIFICA[ÇC][ÃA]O\s+(?:DE\s+)?EDUCA[ÇC][ÃA]O\s+ESPECIAL/i, prioridade: 9 },
    { id: "ferias_premio_especie", padrao: /F[ÉE]RIAS[\s-]?PR[ÊE]MIO.{0,25}ESP[ÉE]CIE|CONVERTE\s+F[ÉE]RIAS[\s-]?PR[ÊE]MIO\s+EM\s+ESP[ÉE]CIE/i, prioridade: 9 },
    { id: "afastamento_docencia", padrao: /AFASTAMENTO\s+DE\s+DOC[ÊE]NCIA/i, prioridade: 8 },
    { id: "afastamento_regencia", padrao: /AFASTAMENTO\s+DE\s+REG[ÊE]NCIA/i, prioridade: 8 },
    { id: "afastamento_preliminar_invalidez", padrao: /AFASTAMENTO\s+PRELIMINAR/i, prioridade: 7, desambiguar: (c) => /INVALIDEZ|INCAPACIDADE/i.test(c) },
    { id: "afastamento_preliminar_compulsoria", padrao: /AFASTAMENTO\s+PRELIMINAR/i, prioridade: 7, desambiguar: (c) => /COMPULS/i.test(c) },
    { id: "afastamento_preliminar_aposentadoria", padrao: /AFASTAMENTO\s+PRELIMINAR/i, prioridade: 5, desambiguar: (c) => !/INVALIDEZ|INCAPACIDADE|COMPULS/i.test(c) },
    { id: "alteracao_nome", padrao: /ALTERA(?:[ÇC][ÃA]O)?\s+DE\s+NOME/i, prioridade: 8 },
    { id: "ampliacao_carga_horaria", padrao: /AMPLIA(?:[ÇC][ÃA]O)?\s+(?:DE\s+)?CARGA\s+HOR[ÁA]RIA/i, prioridade: 8 },
    { id: "reducao_carga_horaria", padrao: /REDU[ÇC][ÃA]O\s+DE\s+CARGA\s+HOR[ÁA]RIA/i, prioridade: 8 },
    { id: "lotacao", padrao: /MUDAN[ÇC]A\s+DE\s+LOTA[ÇC][ÃA]O|\bLOTA[ÇC][ÃA]O\b/i, prioridade: 6 },
    { id: "remanejamento", padrao: /\bREMANEJAMENTO\b/i, prioridade: 6 },
    { id: "remocao", padrao: /\bREMO[ÇC][ÃA]O\b/i, prioridade: 6 },
    { id: "processo_administrativo", padrao: /PROCESSO\s+ADMINISTRATIVO/i, prioridade: 4 },
    { id: "retificacao", padrao: /\bRETIFICA(?:[ÇC][ÃA]O)?\b/i, prioridade: 4 },
    { id: "revogacao", padrao: /\bREVOGA(?:[ÇC][ÃA]O)?\b/i, prioridade: 4 },
    { id: "anulacao", padrao: /\bANULA(?:[ÇC][ÃA]O)?\b/i, prioridade: 4 },
    { id: "licenca_maternidade", padrao: /LICEN[ÇC]A[\s-]*MATERNIDADE|LICEN[ÇC]A[\s-]*(?:À|A)\s*GESTANTE/i, prioridade: 12 },
    { id: "licenca_paternidade", padrao: /LICEN[ÇC]A[\s-]*PATERNIDADE/i, prioridade: 12 },
    { id: "afastamento_casamento", padrao: /AFASTAMENTO\s+POR\s+MOTIVO\s+DE\s+CASAMENTO/i, prioridade: 12 },
    { id: "afastamento_luto", padrao: /AFASTAMENTO\s+POR\s+MOTIVO\s+DE\s+LUTO/i, prioridade: 12 },
    { id: "ferias_premio_concessao", padrao: /F[ÉE]RIAS[\s–—\/-]*PR[ÊE]MIO[\s–—\/-]*(?:CONCESS[ÃA]O)|CONCEDE\s+TR[ÊE]S\s+MESES\s+DE\s+F[ÉE]RIAS[\s-]*PR[ÊE]MIO/i, prioridade: 11 },
    { id: "ferias_premio_afastamento", padrao: /F[ÉE]RIAS[\s–—\/-]*PR[ÊE]MIO[\s–—\/-]*AFASTAMENTO|AUTORIZA\s+AFASTAMENTO\s+PARA\s+GOZO\s+DE\s+F[ÉE]RIAS[\s-]*PR[ÊE]MIO/i, prioridade: 11 },
    { id: "licenca_saude", padrao: /LICEN[ÇC]A(?:S)?\s+(?:PARA\s+)?TRATAMENTO\s+DE\s+SA[ÚU]DE/i, prioridade: 6 },
];
// Tipos comuns no Diário que a DIPE NÃO emite I.A. — se o gatilho negativo
// for o mais forte no bloco, o bloco inteiro é ignorado (nunca cai por
// engano no tipo mais próximo do catálogo).
const GATILHOS_NAO_RASTREADOS = [
    /AUTORIZA[ÇC][ÃA]O\s+ESPECIAL\s+DE\s+EXERC[ÍI]CIO/i,
    /\bEXONERA(?:[ÇC][ÃA]O)?\b/i,
    /\bNOMEA(?:[ÇC][ÃA]O)?\b/i,
    /GRATIFICA[ÇC][ÃA]O\s+TEMPOR[ÁA]RIA\s+ESTRAT[ÉE]GICA/i,
];
/** Classifica o tipo de UM bloco de ato inteiro (título + ementa + corpo) —
 *  nunca a "janela mais próxima" de um servidor específico. Isso é o que
 *  impede o tipo de um ato vazar para os servidores de outro (seção 6.3). */
function classificarTipoDoBloco(blocoTexto) {
    const texto = blocoTexto.slice(0, 2000); // título/ementa sempre no início do bloco
    let melhor = null;
    for (const g of GATILHOS_TIPO) {
        const rx = new RegExp(g.padrao.source, g.padrao.flags.includes("g") ? g.padrao.flags : g.padrao.flags + "g");
        let m;
        while ((m = rx.exec(texto)) !== null) {
            const contexto = texto.slice(Math.max(0, m.index - 200), m.index + m[0].length + 200);
            if (g.desambiguar && !g.desambiguar(contexto))
                continue;
            // Prioriza o gatilho mais PRÓXIMO DO INÍCIO do bloco (título/ementa),
            // não o mais próximo de um servidor específico.
            if (!melhor || m.index < melhor.pos || (m.index === melhor.pos && g.prioridade > melhor.prioridade)) {
                melhor = { pos: m.index, prioridade: g.prioridade, id: g.id };
            }
            if (m.index === rx.lastIndex)
                rx.lastIndex++;
        }
    }
    if (!melhor)
        return null;
    for (const rxNeg of GATILHOS_NAO_RASTREADOS) {
        const m = rxNeg.exec(texto);
        if (m && m.index <= melhor.pos)
            return null; // gatilho negativo antecede/domina o bloco
    }
    return melhor.id;
}
// ============================================================================
// 4) VALIDAÇÃO DE NOME — rejeita frases administrativas (seção 6.4/16)
// ============================================================================
const TERMOS_CONECTORES_INVALIDOS = [
    "e ", "de ", "do ", "da ", "dos ", "das ", "ou ", "que ", "para ", "ocupante", "cargo",
    "admiss", "referente", "conforme", "processo", "portaria", "resolu",
    "decreto", "lei ", "nos termos", "com fundamento", "instaurado", "em ",
    "seu procurador", "sua procuradora", "deverá ser", "cumprir os requisitos",
    "requisitos da legislação", "requisitos na legislação",
];
// Palavras/fragmentos que, aparecendo DENTRO do nome capturado (não só no
// início), denunciam que o regex "vazou" para texto administrativo ou para
// um código de cargo colado — mesmo com tudo em maiúsculas.
const RE_VAZAMENTO_NO_NOME = /\b(PROCURADOR|PROCURADORA|REQUISITOS|LEGISLAÇÃO|LEGISLACAO|REQUERIDA|CUMPRIR|DEVERÁ|DEVERA|PORTARIA|PROCESSO|DECRETO|RESOLUÇÃO|RESOLUCAO|PUBLICAÇÃO|PUBLICACAO|MASP|CARGO|ADMISSÃO|ADMISSAO)\b/;
// Código de cargo colado ao fim do nome (ex.: "DANIELLE PEBIE") — a sigla
// funcional (PEB/ATB/ANE/AEB/EEB/TDE + dígito) nunca é sobrenome.
// Aceita tanto o formato correto (PEB1E) quanto a variação sem dígito que
// o OCR às vezes produz (PEBIE, onde o "1" virou "I") — em ambos os casos
// é sempre código de cargo, nunca sobrenome.
const RE_CODIGO_CARGO_COLADO = /\b(?:PEB|ATB|ANE|AEB|EEB|TDE)[A-Z0-9]{1,4}$/i;
function nomePlausivel(nome) {
    const nl = nome.trim().toLowerCase();
    if (TERMOS_CONECTORES_INVALIDOS.some((c) => nl.startsWith(c)))
        return false;
    if (RE_VAZAMENTO_NO_NOME.test(baseText(nome)))
        return false;
    if (RE_CODIGO_CARGO_COLADO.test(nome.trim()))
        return false;
    const palavras = nome.trim().split(/\s+/);
    if (palavras.length > 8)
        return false; // seção 16: mais de 7-8 palavras sem prova é suspeito
    return validarNomeServidor(nome).valido;
}
/** Quando a captura "vazou" para dentro de uma frase administrativa (ex.:
 *  "WARLISON FRANCISCO MAGALHÃES CUMPRIR OS REQUISITOS..."), corta o nome
 *  ANTES da primeira palavra de vazamento e tenta validar de novo — em vez
 *  de simplesmente descartar a ocorrência inteira. Se o resultado cortado
 *  não for um nome plausível também, devolve "" (nunca inventa). */
function truncarNoVazamento(nomeBruto) {
    const m = RE_VAZAMENTO_NO_NOME.exec(baseText(nomeBruto));
    if (!m || m.index <= 0)
        return "";
    const cortado = normalizarNome(nomeBruto.slice(0, m.index));
    return nomePlausivel(cortado) ? cortado : "";
}
// ============================================================================
// 5) EXTRAÇÃO DE OCORRÊNCIAS DENTRO DE UM BLOCO JÁ DELIMITADO
// ============================================================================
// IMPORTANTE: o achatamento de quebras de linha (\n -> espaço) só acontece
// AQUI, sobre um bloco de ato já isolado — nunca sobre a página inteira
// (era exatamente esse achatamento prematuro que fundia colunas/linhas).
// A negativa `(?!\bMASP\b)` dentro do grupo do nome impede que a captura
// atravesse até o MaSP do PRÓXIMO servidor quando não há vírgula entre os
// dois (linhas de tabela sem pontuação, "fundidas" pelo achatamento
// controlado do bloco) — sem vírgula antes do próximo MASP, o regex
// simplesmente não casa ali, e a ocorrência seguinte é pega do zero na
// próxima iteração (seção 6.5: nunca fundir dois servidores).
// O grupo do nome é PREGUIÇOSO (`{2,89}?`) de propósito: precisa parar no
// PRIMEIRO "," encontrado, não no último dentro do alcance — capturar
// guloso faz o nome "vazar" para dentro de frases administrativas que só
// têm vírgula mais adiante (ex.: "WARLISON FRANCISCO MAGALHÃES, para
// cumprir os requisitos da legislação, ..." viraria "WARLISON FRANCISCO
// MAGALHÃES, para cumprir os requisitos" se fosse guloso).
// O terceiro grupo (resto: cargo/vigência/quinquênio) também tem a
// negativa `(?!\bMASP\b)`: sem ela, sendo o último grupo da regex e usando
// dotall, ele consumia gulosamente até 260 caracteres SEM PARAR no próximo
// "MASP" — o que fazia o match inteiro engolir a ocorrência seguinte e o
// rx.lastIndex pular direto por cima dela, perdendo o próximo servidor
// inteiro (não só misturando campos: a pessoa seguinte nunca era
// encontrada). Agora o match sempre termina antes do próximo MaSP.
// Regressão real (Diário 17/07/2026, pág. 36, Férias-Prêmio/Conversão em
// Espécie 13-15/2026): esta edição separou nome e cargo com HÍFEN em vez
// de vírgula ("MASP 857275-2, JULIANO CORDEIRO- PEBIII P"). Como o único
// separador aceito entre nome e resto era a vírgula, a ocorrência inteira
// não casava — o servidor ficava de fora do primeiro passe e só reaparecia
// (quando reaparecia) via recuperação Ctrl+F, sujeito à limpeza anti-
// contaminação mais adiante. Aceitar hífen aqui resolve na origem.
const RE_SERVIDOR = /MASP\s*[:.]?\s*(\d[\d.\s]{1,13}\d\s*-\s*\d{1,2})\b\s*[,:\-]?\s+([A-ZÀ-Ü](?:(?!\bMASP\b)[A-Za-zÀ-ÿ'.\s]){2,89}?)\s*[,\-]\s*((?:(?!\bMASP\b)[\s\S]){0,260})/gis;
const RE_NUMERO_ATO = /(?:ATO|PORTARIA)\s*N[ºo°.]*\s*([\d.]+\s*\/\s*\d{4})/i;
const RE_VIGENCIA = /(a\s+contar\s+d[eoa]s?|a\s+partir\s+d[eoa]s?|aposentad[oa]\s+em|exonerad[oa]\s+em)\s+(\d{1,2}\/\d{1,2}\/\d{2,4}|public[aã][çc][ãa]o)/i;
const RE_QUINQUENIO = /\b(\d{1,2})\s*[º°o]?\s*quinqu[eê]nio/i;
function cortarResto(texto) {
    const idxMasp = texto.search(/\bMASP\b/i);
    const limite = idxMasp >= 0 ? idxMasp : texto.length;
    let trecho = texto.slice(0, limite);
    // Blindagem contra o campo "grudado": texto de ato de retificação/anulação
    // real acabou vazando inteiro para dentro de "cargo" quando não havia
    // ponto/ponto-e-vírgula cedo o bastante para cortar (ex.: "... referente
    // ao cargo em 01/07/2026, por motivo de duplicidade de publicação,
    // ficando ..."). Essas expressões nunca fazem parte de um cargo real —
    // são prosa administrativa/legal. Cortamos ali, antes do limite de
    // tamanho, para o campo não virar um parágrafo inteiro.
    const RE_PROSA_ADMINISTRATIVA = /\b(por\s+motivo\s+de|ficando|considerando|tendo\s+em\s+vista|nos\s+termos\s+do|em\s+raz[ãa]o\s+de|referente\s+ao\s+cargo\s+em|documento\s+assinado\s+eletronicamente|a\s+autenticidade\s+deste\s+documento|secret[áa]rio\s+de\s+estado|superintend[êe]ncia\s+de)\b/i;
    const mProsa = RE_PROSA_ADMINISTRATIVA.exec(trecho);
    if (mProsa && mProsa.index > 0) {
        trecho = trecho.slice(0, mProsa.index);
    }
    // Código de controle de página ("16 2237077 - 1"): quando o último
    // servidor do bloco também é o último texto da página, não existe próximo
    // MASP nem pontuação cedo o bastante para cortar (a reconstrução
    // geométrica às vezes perde o ponto final da frase, ex.: "...108 h/a" sem
    // o "."). Sem este corte o cargo engolia esse código de rodapé inteiro.
    const RE_CODIGO_CONTROLE = /\b\d{1,3}\s+\d{5,9}\s*-\s*\d\b/;
    const mCodigo = RE_CODIGO_CONTROLE.exec(trecho);
    if (mCodigo && mCodigo.index > 0) {
        trecho = trecho.slice(0, mCodigo.index);
    }
    // Início do PRÓXIMO servidor sem MaSP ainda visível: mesma perda de ponto
    // final da reconstrução geométrica ("...saldo de 3 meses SANTA BÁRBARA –
    // MaSP...", sem o "." antes de "SANTA BÁRBARA"). O corte por próximo-MaSP
    // (limite acima) já tira o "MASP" do fim de `trecho`, então o município
    // que sobra fica colado bem no final — por isso o "$" entra como
    // alternativa ao lookahead de escola/MASP. Município pode ter mais de uma
    // palavra ("SANTA BÁRBARA", "BELO VALE"), daí o `\s` na classe do meio.
    const RE_PROXIMA_LOCALIDADE = /[A-ZÀ-Ü][A-ZÀ-Üa-zà-ÿ\s]{2,40}\s*[–-]\s*(?=(?:E\.?\s*E\.?|EE|ESCOLA\s+ESTADUAL|MASP|MaSP)\b|$)/;
    const mLocalidade = RE_PROXIMA_LOCALIDADE.exec(trecho);
    if (mLocalidade && mLocalidade.index > 0) {
        trecho = trecho.slice(0, mLocalidade.index);
    }
    const ABREVIACOES = new Set(["adm", "art", "arts", "n", "no", "nº", "sr", "sra", "dr", "dra", "ltda", "av", "cel", "reg", "cod", "pag", "pág"]);
    const rxPontuacao = /[.;]/g;
    let m;
    while ((m = rxPontuacao.exec(trecho)) !== null) {
        if (trecho[m.index] === ";")
            return trecho.slice(0, m.index);
        const antes = /([A-Za-zÀ-ÿ]{1,6})$/.exec(trecho.slice(0, m.index));
        if (antes && ABREVIACOES.has(antes[1].toLowerCase()))
            continue;
        const depois = trecho[m.index + 1];
        if (depois && /\d/.test(depois))
            continue;
        return trecho.slice(0, m.index);
    }
    return trecho;
}
// "admissão 1" / "admissão 01" / "adm. 1" / "adm 01" / "1º cargo" — nunca
// confundir com quinquênio (que exige a palavra "quinq"/"qq" por perto).
const RE_ADMISSAO = /\b(?:admiss[ãa]o|adm\.?)\s*[:.]?\s*(\d{1,2})\b(?!\s*[º°o]?\s*(?:quinq|qq))|\b(\d{1,2})\s*[º°o]\s*cargo\b|\bcargo\s*[:.]?\s*(\d{1,2})\b/i;
function extrairAdmissao(resto) {
    const m = RE_ADMISSAO.exec(resto);
    if (!m)
        return { admissao: "", restoSemAdmissao: resto };
    const numero = (m[1] || m[2] || m[3] || "").padStart(2, "0");
    const restoSemAdmissao = (resto.slice(0, m.index) + " " + resto.slice(m.index + m[0].length))
        .replace(/\s*,\s*(,\s*)+/g, ", ").trim();
    return { admissao: numero, restoSemAdmissao };
}
function separarCargoVigencia(resto) {
    let quinquenio = "";
    const mq = RE_QUINQUENIO.exec(resto);
    if (mq)
        quinquenio = `${mq[1]}º`;
    const { admissao, restoSemAdmissao } = extrairAdmissao(resto);
    // Observações individuais pertencem ao servidor imediatamente anterior e
    // não podem vazar para o campo Cargo nem para o próximo MaSP.
    const reObs = /\b(para\s+regularizar\s+a\s+situa[çc][ãa]o\s+funcional\s+d[oa]\s+servidor[a]?)\b/i;
    const mo = reObs.exec(restoSemAdmissao);
    const observacao = mo ? normalizarLinha(mo[1]) : "";
    const semObs = mo
        ? (restoSemAdmissao.slice(0, mo.index) + " " + restoSemAdmissao.slice(mo.index + mo[0].length)).trim()
        : restoSemAdmissao;
    const mv = RE_VIGENCIA.exec(semObs);
    let vigencia = "", cargo = semObs;
    if (mv) {
        vigencia = `${mv[1].trim()} ${mv[2].trim()}`;
        cargo = (semObs.slice(0, mv.index) + " " + semObs.slice(mv.index + mv[0].length)).trim();
    }
    cargo = cargo
        .replace(/\b(?:referente\s+ao|ao\(s\)?)\s+servidor(?:es)?\b.*$/i, "")
        .replace(/\s*,\s*(,\s*)+/g, ", ")
        .replace(/^\s*,\s*|\s*,\s*$/g, "")
        .trim();
    return { cargo: normalizarLinha(cargo), admissao, vigencia, quinquenio, observacao };
}
// Rótulo explícito "MUNICÍPIO: X" ou "MUNICÍPIO - X".
const RE_MUNICIPIO_ROTULADO = /MUNIC[ÍI]PIO\s*[:\-]\s*([A-ZÀ-Üa-zà-ü\s]{3,40}?)(?=[.,;\n]|$)/i;
// "Cidade – " / "Cidade -" logo antes de SRE, código de escola ou "E.E."/"EE"
// — cobre "Belo Horizonte – [escola]" e "Dona Euzébia – código – escola".
const RE_MUNICIPIO_TRAVESSAO = /\b([A-ZÀ-Ü][a-zà-üA-ZÀ-Ü]+(?:\s+(?:d[eoa]s?\s+)?[A-ZÀ-Ü][a-zà-üA-ZÀ-Ü]+){0,3})\s*[–-]\s*(?=SRE\b|\d{3,7}\s*[-–]|E\.?E\.?\b)/;
function limparMunicipioCandidato(txt) {
    const cand = normalizarLinha(txt).replace(/^[,;:.\-–—\s]+|[,;:.\-–—\s]+$/g, "").toUpperCase();
    if (!cand || cand.length < 3 || cand.length > 45)
        return "";
    if (/\b(ATO|CONCEDE|REGISTRA|AFASTAMENTO|LICEN[ÇC]A|F[ÉE]RIAS|SERVIDOR|ART|LEI|DECRETO|RESOLU[ÇC][ÃA]O|SRE)\b/i.test(cand))
        return "";
    if (/\d/.test(cand))
        return "";
    return cand;
}
/** Localidade por contexto acumulado DENTRO do mesmo ato. A janela recebida
 * vai do início do bloco até o MaSP atual; portanto o último município/escola
 * publicado continua valendo para os MaSP seguintes até que outro contexto
 * apareça (formato típico do Diário narrativo). */
function extrairLocalidade(janela) {
    let sre = "";
    const sreMatches = [...janela.matchAll(/\bSRE\s*(?:de\s+|[–-]\s*)?([A-Za-zÀ-ÿ ]{2,50})/gi)];
    if (sreMatches.length) {
        const nome = normalizarLinha(sreMatches[sreMatches.length - 1][1]).replace(/[,;:].*$/, "");
        if (nome)
            sre = `SRE ${nome}`;
    }
    let municipio = "";
    let codigoEscola = "";
    let escolaOrgao = "";
    // Formas: "BELO HORIZONTE – EE Escola, MaSP..." e
    // "Cidade - 1234 - EE Escola, MaSP...". Pegamos SEMPRE a última escola
    // antes do MaSP atual, o que implementa a herança correta entre pessoas.
    const escolaRx = /(?:(\d{3,7})\s*[-–]\s*)?((?:E\.?\s*E\.?|EE|ESCOLA\s+ESTADUAL)\s+[^,;\n]{2,85})(?=\s*,?\s*(?:MASP|MaSP)|\s*;|$)/gi;
    const escolas = [...janela.matchAll(escolaRx)];
    if (escolas.length) {
        const e = escolas[escolas.length - 1];
        codigoEscola = e[1] || "";
        // CAIXA ALTA porque é assim que a escola sai em todo o resto do Painel:
        // no formulário manual, no extrator tabular e no `orgao_sre`. O Diário
        // narrativo escreve "EE Padre Pedro Thysen"; deixar essa grafia passar
        // produziria I.A.s com o mesmo campo em dois formatos diferentes.
        escolaOrgao = normalizarLinha(e[2])
            .replace(/^E\.\s*E\.?\s*/i, "EE ")
            .replace(/\s+MASP\s*$/i, "")
            .toUpperCase();
        const antes = janela.slice(Math.max(0, (e.index ?? 0) - 80), e.index ?? 0);
        // Sem "/i": o município pode ter mais de uma palavra e a primeira letra
        // de cada palavra é maiúscula, mas o "i" tornava o padrão tolerante
        // demais e casava prosa em minúsculas vinda do parágrafo anterior
        // (ex.: "...saldo de 3 meses SANTA BÁRBARA" virava "meses SANTA BÁRBARA").
        const mm = /([A-ZÀ-Ü][A-ZÀ-Üa-zà-ÿ\s]{2,45})\s*[–-]\s*(?:\d{3,7}\s*[-–]\s*)?$/.exec(antes);
        if (mm)
            municipio = limparMunicipioCandidato(mm[1]);
        // Quando o Diário troca apenas a escola e mantém o município (ex.:
        // "BELO HORIZONTE – EE Bolivar..., MaSP A; EE Laudieme..., MaSP B"),
        // o segundo MaSP precisa herdar BELO HORIZONTE. Procura o último
        // marcador município→escola anterior ao servidor atual, sem exigir que
        // esteja imediatamente antes da escola atual.
        if (!municipio) {
            const prefixo = janela.slice(0, e.index ?? 0);
            const pares = [...prefixo.matchAll(/([A-ZÀ-Ü][A-ZÀ-Üa-zà-ÿ\s]{2,45})\s*[–-]\s*(?=(?:\d{3,7}\s*[-–]\s*)?(?:E\.?\s*E\.?|EE|ESCOLA\s+ESTADUAL)\b)/g)];
            for (let i = pares.length - 1; i >= 0 && !municipio; i--) {
                municipio = limparMunicipioCandidato(pares[i][1]);
            }
        }
    }
    if (!municipio) {
        // "SRE"/"METROPOLITANA"/"A" tolerantes a Title-Case ("SRE Metropolitana
        // A"), não só CAIXA ALTA — o Diário narrativo escreve o cabeçalho assim
        // e o "/i" sozinho não bastava porque o grupo do MUNICÍPIO (antes da
        // vírgula) precisa continuar exigindo maiúscula inicial para não casar
        // prosa comum; por isso as letras de SRE/METROPOLITANA/A viram classes
        // de caractere em vez de uma flag global.
        const msre = [...janela.matchAll(/([A-ZÀ-Ü][A-ZÀ-Üa-zà-ÿ\s]{2,45})\s*,\s*[Ss][Rr][Ee]\s*[-–]?\s*[Mm][Ee][Tt][Rr][Oo][Pp][Oo][Ll][Ii][Tt][Aa][Nn][Aa]\s*[Aa]\b/g)];
        if (msre.length)
            municipio = limparMunicipioCandidato(msre[msre.length - 1][1]);
    }
    if (!municipio) {
        const msemEscola = [...janela.matchAll(/([A-ZÀ-Ü][A-ZÀ-Üa-zà-ÿ\s]{2,45})\s*[–-]\s*(?=(?:MASP|MaSP)\b)/g)];
        if (msemEscola.length)
            municipio = limparMunicipioCandidato(msemEscola[msemEscola.length - 1][1]);
    }
    if (!municipio) {
        const mRotulado = RE_MUNICIPIO_ROTULADO.exec(janela);
        if (mRotulado)
            municipio = limparMunicipioCandidato(mRotulado[1]);
    }
    // Não usa "SRE Metropolitana A" como escola de reserva: todo registro
    // deste painel já É da Metropolitana A (é o escopo inteiro), então repetir
    // isso no campo escola não informa nada — só some com um campo que devia
    // ficar vazio (revisável) quando o ato realmente não cita escola.
    if (!escolaOrgao && sre && !ehMetropolitanaA(sre))
        escolaOrgao = sre.toUpperCase();
    return { sre, municipio, codigoEscola, escolaOrgao };
}
/** Extrai as ocorrências (servidor + campos) de dentro de UM bloco de ato
 *  já isolado. Cada ocorrência usa só o texto ENTRE o seu MaSP e o próximo
 *  MaSP do mesmo bloco — nunca alcança a linha/servidor seguinte nem
 *  atravessa para o próximo bloco (seção 6.5). */
function extrairOcorrenciasDoBloco(blocoTextoOriginal) {
    // Achatamento controlado: só aqui, só dentro do bloco já delimitado.
    const bloco = blocoTextoOriginal.replace(/\s*\n\s*/g, " ").trim();
    if (!bloco)
        return [];
    const ocorrencias = [];
    const rx = new RegExp(RE_SERVIDOR.source, "gis");
    let m;
    let prevFim = 0;
    while ((m = rx.exec(bloco)) !== null) {
        let nomeBruto = normalizarNome(m[2]);
        let nomeTruncado = false;
        if (!nomePlausivel(nomeBruto)) {
            const cortado = truncarNoVazamento(m[2]);
            if (!cortado) {
                prevFim = m.index + m[0].length;
                continue;
            }
            nomeBruto = cortado;
            nomeTruncado = true;
        }
        const resto = cortarResto(m[3]);
        const { cargo, admissao, vigencia, quinquenio, observacao } = separarCargoVigencia(resto);
        const masp = normalizarMasp(m[1]);
        // Inclui o token `MASP` do servidor atual na janela de contexto. O
        // extrator de escola usa `..., MaSP` como âncora estrutural; cortar a
        // janela exatamente antes do M fazia o PRIMEIRO servidor de cada
        // município/escola perder a localidade, enquanto apenas o segundo
        // conseguia herdá-la. Não inclui o restante do servidor, portanto não
        // há risco de puxar município/escola da ocorrência seguinte.
        const janela = bloco.slice(0, Math.min(bloco.length, m.index + 4));
        const { sre, municipio, codigoEscola, escolaOrgao } = extrairLocalidade(janela);
        ocorrencias.push({
            masp, nome: nomeBruto, nomeTruncado, cargo, admissao, vigencia, quinquenio, observacao,
            sre, municipio, codigoEscola, escolaOrgao,
            blocoOrigemTrecho: bloco.slice(Math.max(prevFim, m.index - 200), m.index + m[0].length),
        });
        prevFim = m.index + m[0].length;
    }
    return ocorrencias;
}
// ALTERAÇÃO DE NOME tem uma gramática própria, sem cargo/admissão/vigência:
// "MUNICÍPIO: MaSP 000000-0, Nome Antigo para Nome Novo para <motivo>;" —
// nunca há vírgula seguida de cargo/admissão depois do nome, então nenhuma
// das redes de RE_SERVIDOR/fallback/auditoria (todas ancoradas em vírgula +
// código de cargo) casa nada aqui — o ato inteiro saía sem NENHUM servidor.
// Regra real observada: "MASP X, VELHO para NOVO para MOTIVO".
const RE_ALTERACAO_NOME = /MASP\s*[:.]?\s*(\d[\d.\s]{1,13}\d\s*-\s*\d{1,2})\s*,\s*([A-ZÀ-Ü][A-Za-zÀ-ÿ'.\s]{2,89}?)\s+para\s+([A-ZÀ-Ü][A-Za-zÀ-ÿ'.\s]{2,89}?)(?=\s+para\s+|\s*[;.]|$)/gis;
// Rótulos de grupo que aparecem antes do município real neste ato (ex.:
// "EM PROCESSO DE APOSENTADORIA:") e não podem ser confundidos com ele.
const RE_ROTULO_GRUPO_ALTERACAO = /\b(?:EM\s+PROCESSO|APOSENTADORIA|SERVIDOR|SERVIDORA)\b/i;
function extrairMunicipioAlteracaoNome(janela) {
    const candidatos = [...janela.matchAll(/([A-ZÀ-Ü][A-ZÀ-Üa-zà-ÿ\s]{2,40})\s*:\s*(?=MASP|MaSP)/g)];
    for (let i = candidatos.length - 1; i >= 0; i--) {
        const cand = normalizarLinha(candidatos[i][1]);
        if (cand && !RE_ROTULO_GRUPO_ALTERACAO.test(cand))
            return cand.toUpperCase();
    }
    return "";
}
/** Extrator dedicado do ato ALTERAÇÃO DE NOME (gramática própria, ver
 *  RE_ALTERACAO_NOME). O nome anterior vai para `observacao` — cargo não
 *  se aplica a este tipo de ato mesmo. */
function extrairOcorrenciasAlteracaoNome(blocoTextoOriginal) {
    const bloco = blocoTextoOriginal.replace(/\s*\n\s*/g, " ").trim();
    if (!bloco)
        return [];
    const ocorrencias = [];
    const rx = new RegExp(RE_ALTERACAO_NOME.source, "gis");
    let m;
    let prevFim = 0;
    while ((m = rx.exec(bloco)) !== null) {
        const nomeAntigo = normalizarNome(m[2]);
        const nomeNovo = normalizarNome(m[3]);
        if (!nomePlausivel(nomeNovo)) {
            prevFim = m.index + m[0].length;
            continue;
        }
        const masp = normalizarMasp(m[1]);
        const janela = bloco.slice(0, Math.min(bloco.length, m.index + 4));
        const municipio = extrairMunicipioAlteracaoNome(janela);
        ocorrencias.push({
            masp, nome: nomeNovo, nomeTruncado: false,
            cargo: "", admissao: "", vigencia: "", quinquenio: "",
            observacao: nomeAntigo && baseText(nomeAntigo) !== baseText(nomeNovo) ? `Nome anterior: ${nomeAntigo}` : "",
            sre: "", municipio, codigoEscola: "", escolaOrgao: "",
            blocoOrigemTrecho: bloco.slice(Math.max(prevFim, m.index - 200), m.index + m[0].length),
        });
        prevFim = m.index + m[0].length;
    }
    return ocorrencias;
}
/** Segunda rede de segurança: procura MaSP + nome dentro de um bloco JÁ
 * confirmado como Metropolitana A e JÁ delimitado por ato. Ela é
 * deliberadamente mais tolerante que RE_SERVIDOR (aceita nome seguido por
 * hífen/cargo e quebras de linha no MaSP), mas nunca atravessa o próximo
 * MaSP. Os registros recuperados são marcados para revisão no chamador.
 */
function extrairOcorrenciasFallbackDoBloco(blocoTextoOriginal) {
    const bloco = blocoTextoOriginal.replace(/\s*\n\s*/g, " ").replace(/\s+/g, " ").trim();
    if (!bloco)
        return [];
    const rx = /\bMASP\s*[:.]?\s*(\d[\d.\s]{1,13}\d\s*-\s*\d{1,2})\b\s*[,;:\-]?\s*([A-ZÀ-Ü][A-Za-zÀ-ÿ'.\s]{2,90}?)(?=\s*,\s*(?:(?:PEB|ATB|ANEI?|AEB|EEB|ASB|TDE|PA)\w*|cargo|admiss|adm\.?|a\s+partir|a\s+contar|ref\.?|referente)|\s*[-–—]\s*(?:PEB|ATB|ANEI?|AEB|EEB|ASB|TDE|PA)\w*|\s*;|\s*\.\s|$)/gis;
    const saida = [];
    let m;
    while ((m = rx.exec(bloco)) !== null) {
        let nome = normalizarNome(m[2]);
        let nomeTruncado = false;
        if (!nomePlausivel(nome)) {
            const cortado = truncarNoVazamento(m[2]);
            if (!cortado)
                continue;
            nome = cortado;
            nomeTruncado = true;
        }
        const masp = normalizarMasp(m[1]);
        const fimNome = m.index + m[0].length;
        const proximoMaspRel = bloco.slice(fimNome).search(/\bMASP\b/i);
        const fim = proximoMaspRel >= 0 ? fimNome + proximoMaspRel : Math.min(bloco.length, fimNome + 300);
        const resto = cortarResto(bloco.slice(fimNome, fim));
        const campos = separarCargoVigencia(resto);
        const janela = bloco.slice(0, Math.min(bloco.length, m.index + 4));
        const loc = extrairLocalidade(janela);
        saida.push({
            masp, nome, nomeTruncado,
            cargo: campos.cargo, admissao: campos.admissao, vigencia: campos.vigencia,
            quinquenio: campos.quinquenio,
            observacao: [campos.observacao, 'RECUPERADO_FALLBACK_MASP'].filter(Boolean).join(' | '),
            sre: loc.sre, municipio: loc.municipio, codigoEscola: loc.codigoEscola,
            escolaOrgao: loc.escolaOrgao,
            blocoOrigemTrecho: bloco.slice(Math.max(0, m.index - 220), Math.min(bloco.length, fim)),
        });
    }
    return saida;
}
/** Última rede de segurança, propositalmente simples: dentro de um bloco
 * que JÁ está confirmado como Metropolitana A e cujo tipo de ato JÁ foi
 * reconhecido, todo padrão "MaSP número, NOME," é um candidato a servidor.
 * Não tenta decidir SRE, ato ou escopo; essas decisões já ocorreram antes.
 * Serve apenas para impedir que pequenas variações de cargo/data façam um
 * nome publicado desaparecer silenciosamente. */
function listarMaspsPublicadosNoBloco(blocoTextoOriginal) {
    // Auditoria independente da extração principal. Conta cada ocorrência de
    // MaSP publicada, inclusive repetições legítimas do mesmo servidor em
    // admissões/vínculos diferentes. O bloco já está delimitado à Metropolitana A
    // e a um único ato, então um MaSP que não aparece em `ocorrencias` nunca pode
    // desaparecer silenciosamente.
    const saida = [];
    const rx = /\bMASP\s*(?:N[ºO°.]\s*)?[:.]?\s*(\d[\d.\/\s]{3,15}(?:[-–]\s*\d{1,2})?)/gi;
    let m;
    while ((m = rx.exec(blocoTextoOriginal)) !== null) {
        const masp = normalizarMasp(m[1]);
        if (masp && /\d/.test(masp))
            saida.push(masp);
        if (rx.lastIndex === m.index)
            rx.lastIndex++;
    }
    return saida;
}
// Detecta o caso em que o PRÓPRIO Diário publicou a MaSP sem nenhum nome
// junto — "MaSP 1142971-9, PEBD1A, Adm 01, a contar de 13/09/2026", direto
// da MaSP pro código de cargo, sem nenhuma palavra de nome no meio. Preciso
// e restrito de propósito: uma MaSP seguida de texto qualquer não-nome
// ("PARA CONCESSÕES POSTERIORES", um trecho de prosa genérico sem relação
// com uma pessoa específica) NÃO deve virar um registro fantasma — só o
// caso em que o nome está genuinamente ausente, indo direto pro cargo.
const RE_CARGO_LOGO_APOS_MASP = /\b(?:PEB|EEB|ATB|ANEI?|AEB|ASB|TDE|ASE|ATE|D|DV|DIV|FGD)[A-Z0-9]*\b/i;
function maspPublicadaSemNomeNoBloco(blocoTextoOriginal, maspAlvo) {
    const rx = /\bMASP\s*(?:N[ºO°.]\s*)?[:.]?\s*(\d[\d.\/\s]{3,15}(?:[-–]\s*\d{1,2})?)\s*,?\s*/gi;
    let m;
    while ((m = rx.exec(blocoTextoOriginal)) !== null) {
        if (normalizarMasp(m[1]) === maspAlvo) {
            const depois = blocoTextoOriginal.slice(m.index + m[0].length, m.index + m[0].length + 20);
            if (RE_CARGO_LOGO_APOS_MASP.test(depois.trim().split(/\s+/)[0] || ""))
                return true;
        }
        if (rx.lastIndex === m.index)
            rx.lastIndex++;
    }
    return false;
}
function extrairOcorrenciasAuditoriaBasica(blocoTextoOriginal) {
    const bloco = blocoTextoOriginal.replace(/\s*\n\s*/g, " ").replace(/\s+/g, " ").trim();
    if (!bloco)
        return [];
    const rx = /\bMASP\s*[:.]?\s*(\d[\d.\s]{1,13}\d\s*-\s*\d{1,2})\s*[,;:\-]?\s*([A-ZÀ-Ü][A-Za-zÀ-ÿ'.\s]{2,90}?)(?=\s*,|\s*;|\s*[-–—]\s*(?:PEB|ATB|ANEI?|AEB|EEB|ASB|TDE|PA)\w*|$)/gis;
    const saida = [];
    let m;
    while ((m = rx.exec(bloco)) !== null) {
        const masp = normalizarMasp(m[1]);
        const nome = normalizarNome(m[2]);
        if (!nomePlausivel(nome))
            continue;
        const fimNome = m.index + m[0].length;
        const prox = bloco.slice(fimNome).search(/\bMASP\b/i);
        const fim = prox >= 0 ? fimNome + prox : Math.min(bloco.length, fimNome + 320);
        const campos = separarCargoVigencia(cortarResto(bloco.slice(fimNome, fim)));
        const loc = extrairLocalidade(bloco.slice(0, Math.min(bloco.length, m.index + 4)));
        saida.push({
            masp, nome, nomeTruncado: false,
            cargo: campos.cargo, admissao: campos.admissao, vigencia: campos.vigencia,
            quinquenio: campos.quinquenio,
            observacao: [campos.observacao, 'RECUPERADO_AUDITORIA_BASICA'].filter(Boolean).join(' | '),
            sre: loc.sre, municipio: loc.municipio, codigoEscola: loc.codigoEscola,
            escolaOrgao: loc.escolaOrgao,
            blocoOrigemTrecho: bloco.slice(Math.max(0, m.index - 220), Math.min(bloco.length, fim)),
        });
    }
    return saida;
}
function extrairTituloOriginalDoBloco(blocoTexto, tipoLabel, numeroAto) {
    const limpo = blocoTexto.replace(/\r/g, "");
    // Recorta somente o título, mesmo quando o OCR cola texto da ementa na mesma linha.
    const m = /^[ \t]*([^\n]{0,150}?(?:ATO|PORTARIA)\s*N[ºo°.]*\s*[\d.]+\s*\/\s*\d{4})/im.exec(limpo);
    if (m)
        return normalizarLinha(m[1]);
    const linhas = limpo.split("\n").map((l) => normalizarLinha(l)).filter(Boolean);
    const linhaTitulo = linhas.find((l) => /(?:ATO|PORTARIA)\s*N[ºo°.]/i.test(l) && l.length <= 180);
    if (linhaTitulo)
        return linhaTitulo;
    return `${tipoLabel.toUpperCase()}${numeroAto ? ` - ATO Nº ${numeroAto}` : ""}`;
}
/** Retorna somente a ementa/fundamentação FIXA do ato.
 *
 * Regra: o cabeçalho termina na expressão que anuncia a lista de servidores
 * ("ao(s) servidor(es):", "às servidoras:", etc.). Município/escola que vêm
 * depois desse dois-pontos pertencem ao primeiro servidor e NÃO podem entrar
 * no cabeçalho compartilhado.
 */
function extrairTextoLegalDoBloco(blocoTexto) {
    const limpo = blocoTexto.replace(/\r/g, "");
    const mLista = /\bSERVIDOR(?:A)?\s*(?:\(\s*S\s*\)|\(\s*ES\s*\)|AS|ES|S)?\s*:/i.exec(limpo);
    const indices = [
        mLista ? mLista.index + mLista[0].length : -1,
        limpo.search(/\bMASP\b/i),
        limpo.search(/LOCALIDADE\s+ESCOLA\s+MASP\s+NOME/i),
    ].filter((x) => x >= 0);
    const fim = indices.length ? Math.min(...indices) : Math.min(limpo.length, 1600);
    const cabecalho = limpo.slice(0, Math.min(fim, 1600));
    const linhas = cabecalho.split("\n").map((l) => normalizarLinha(l)).filter(Boolean);
    const idxTitulo = linhas.findIndex((l) => /(?:ATO|PORTARIA)\s*N[ºo°.]/i.test(l));
    const corpo = idxTitulo >= 0 ? linhas.slice(idxTitulo + 1) : linhas;
    return normalizarLinha(corpo.join(" "));
}
// ============================================================================
// 6) PIPELINE PÚBLICO
// ============================================================================
const MESES_PT = {
    janeiro: "01", fevereiro: "02", março: "03", marco: "03", abril: "04",
    maio: "05", junho: "06", julho: "07", agosto: "08", setembro: "09",
    outubro: "10", novembro: "11", dezembro: "12",
};
/** A data de publicação é do CABEÇALHO da edição, comum a todos os atos —
 *  nunca fica vazia só porque não está do lado do servidor (seção
 *  "MAPEAMENTO DA PUBLICAÇÃO"). Procura nas primeiras páginas, tanto no
 *  formato numérico quanto por extenso ("1º de agosto de 2026"). */
function extrairDataEdicao(paginas) {
    // A data de publicação deve vir do CABEÇALHO da edição, nunca de uma lei
    // citada dentro do ato. Por isso a busca é conservadora: primeiro aceita a
    // forma por extenso típica do jornal; para datas numéricas exige contexto
    // de cabeçalho. Como último recurso, usa uma data ISO presente no nome do
    // arquivo (ex.: Diario_do_Executivo_2026-07-17.pdf).
    const cabecalho = paginas.slice(0, 2).map((p) => p.texto).join("\n").slice(0, 3000);
    const inicioCabecalho = cabecalho.slice(0, 700);
    const reExtenso = /\b(\d{1,2})(?:º)?\s+de\s+([a-zçã]+)\s+de\s+(\d{4})\b/gi;
    for (const m of inicioCabecalho.matchAll(reExtenso)) {
        const idx = m.index ?? 0;
        const contextoAntes = baseText(inicioCabecalho.slice(Math.max(0, idx - 220), idx));
        const pareceCabecalho = /MINAS GERAIS|DIARIO DO EXECUTIVO|BELO HORIZONTE|(?:SEGUNDA|TERCA|QUARTA|QUINTA|SEXTA)-?FEIRA|SABADO|DOMINGO/.test(contextoAntes);
        if (!pareceCabecalho)
            continue;
        const mes = MESES_PT[semAcento(m[2]).toLowerCase()];
        if (mes)
            return `${m[1].padStart(2, "0")}/${mes}/${m[3]}`;
    }
    const reNumerico = /\b(\d{2})\/(\d{2})\/(\d{4})\b/g;
    for (const m of inicioCabecalho.matchAll(reNumerico)) {
        const idx = m.index ?? 0;
        // Só considera marcadores que aparecem ANTES da data e muito perto dela.
        // Isso evita confundir datas de posse/exercício ou leis com a publicação.
        const contextoAntes = baseText(inicioCabecalho.slice(Math.max(0, idx - 180), idx));
        if (/MINAS GERAIS|DIARIO DO EXECUTIVO|EDICAO|PUBLICACAO/.test(contextoAntes))
            return m[0];
    }
    const arquivo = paginas[0]?.arquivo || "";
    const mIsoArquivo = /(?:^|[^0-9])(20\d{2})[-_.](0[1-9]|1[0-2])[-_.]([0-2]\d|3[01])(?:[^0-9]|$)/.exec(arquivo);
    if (mIsoArquivo)
        return `${mIsoArquivo[3]}/${mIsoArquivo[2]}/${mIsoArquivo[1]}`;
    return "";
}
/** Localiza TODAS as janelas estruturais de SRE Metropolitana A como um
 * Ctrl+F no texto integral da página. Cada janela termina no próximo
 * cabeçalho de QUALQUER outra SRE/regional. Assim Metropolitana B, C, D...
 * e também "SRE de ..." nunca contaminam a Metropolitana A.
 *
 * Esta busca é uma segunda passagem de RECUPERAÇÃO. A ordem geométrica
 * continua sendo a fonte principal; o Ctrl+F apenas recupera blocos A que
 * ficaram fora do fluxo por mudança de seção/página/coluna.
 */
function janelasControleFMetropolitanaA(texto) {
    if (!texto || !texto.trim())
        return [];
    const eventos = [];
    const padroes = [
        /^[ \t]*-?\s*SRE\s+(?:DE\s+)?([^\n:]{2,70})\s*:?\s*$/gim,
        /^[ \t]*SUPERINTEND[ÊE]NCIA\s+REGIONAL\s+DE\s+ENSINO\s*[-–—:]?\s*([^\n:]{2,70})\s*:?\s*$/gim,
        /^[ \t]*[-–—•]?\s*METROPOLITANA\s*([A-Z])\s*[-–—:]?\s*$/gim,
        // Também captura fronteira inline após ':'/';', comum em atos LIP:
        // 'referente à servidora: SRE METROPOLITANA B – CONTAGEM ...'.
        /(?:^|[:;]\s*)SRE\s+(?:DE\s+)?METROPOLITANA\s*([A-Z])\b/gim,
    ];
    for (const rx0 of padroes) {
        const rx = new RegExp(rx0.source, rx0.flags);
        let m;
        while ((m = rx.exec(texto)) !== null) {
            const nome = String(m[1] || '');
            eventos.push({ pos: m.index, fim: m.index + m[0].length, ehA: ehMetropolitanaA(nome) || /^A$/i.test(nome.trim()) });
            if (rx.lastIndex === m.index)
                rx.lastIndex++;
        }
    }
    eventos.sort((a, b) => a.pos - b.pos || a.fim - b.fim);
    for (let i = eventos.length - 1; i > 0; i--)
        if (eventos[i].pos === eventos[i - 1].pos)
            eventos.splice(i, 1);
    const saida = [];
    let bloqueado = false;
    let ultimaFronteira = 0;
    let abriuA = false;
    const houveNovaSecao = (ini, fim) => {
        const trecho = texto.slice(Math.max(0, ini), Math.max(ini, fim));
        return /(?:^|\n)\s*(?:-?\s*)?(?:SECRETARIA\s+DE\s+ESTADO\s+DE\s+(?:EDUCA[CÇ][AÃ]O|PLANEJAMENTO\s+E\s+GEST[AÃ]O)|DIRETORIA\s+CENTRAL\s+DE\s+GEST[AÃ]O\s+DE\s+DIREITOS\s+DO\s+SERVIDOR)\b/im.test(trecho);
    };
    for (let i = 0; i < eventos.length; i++) {
        const ev = eventos[i];
        if (!ev.ehA) {
            if (abriuA)
                bloqueado = true;
            ultimaFronteira = ev.fim;
            continue;
        }
        if (bloqueado && !houveNovaSecao(ultimaFronteira, ev.pos))
            continue;
        bloqueado = false;
        abriuA = true;
        let fim = texto.length;
        for (let j = i + 1; j < eventos.length; j++) {
            if (!eventos[j].ehA) {
                fim = eventos[j].pos;
                break;
            }
        }
        // Não deixa uma janela Ctrl+F da SRE herdar atos de uma nova unidade
        // administrativa do órgão central (ex.: Superintendência de Gestão de
        // Pessoas e Normas) NEM de um órgão totalmente diferente da SEE/MG, como
        // o Conselho Estadual de Educação (CEE/MG) — que publica pareceres e
        // atos próprios sem reabrir nenhum cabeçalho de SRE. Regressão real
        // (Diário 05/09/2026, pág. 39): sem esta fronteira, a janela Ctrl+F da
        // Metropolitana A ia até o fim da página e "recuperava" um servidor do
        // CEE/MG (outro órgão, sem nenhuma relação com a Metropolitana A) como
        // se fosse mais um servidor do ato anterior da SEE/MG.
        const aposA = texto.slice(ev.fim, fim);
        const mUnidade = /(?:^|\n)\s*(?:SUPERINTEND[ÊE]NCIA\s+(?!REGIONAL\s+DE\s+ENSINO)[^\n]{3,100}|SUBSECRETARIA\s+DE\s+[^\n]{3,100}|DIRETORIA\s+(?!CENTRAL\s+DE\s+GEST[ÃA]O\s+DE\s+DIREITOS\s+DO\s+SERVIDOR)[^\n]{3,100}|CONSELHO\s+ESTADUAL\s+DE\s+EDUCA[ÇC][ÃA]O[^\n]{0,100})\s*(?:\n|$)/im.exec(aposA);
        if (mUnidade)
            fim = Math.min(fim, ev.fim + (mUnidade.index || 0));
        const janela = texto.slice(ev.pos, fim).trim();
        if (janela)
            saida.push(janela);
    }
    return saida;
}
// Mesmos padrões de cabeçalho de SRE usados em `janelasControleFMetropolitanaA`,
// mas aqui o texto já está "dentro" de uma janela Metropolitana A aberta na
// página anterior (ver uso abaixo) — não precisamos achar ONDE ela abre,
// só onde ela PODE fechar: o primeiro cabeçalho de QUALQUER outra SRE.
function cortarNoPrimeiroCabecalhoDeOutraSre(texto) {
    if (!texto)
        return texto;
    const padroes = [
        /^[ \t]*-?\s*SRE\s+(?:DE\s+)?([^\n:]{2,70})\s*:?\s*$/gim,
        /^[ \t]*SUPERINTEND[ÊE]NCIA\s+REGIONAL\s+DE\s+ENSINO\s*[-–—:]?\s*([^\n:]{2,70})\s*:?\s*$/gim,
        /^[ \t]*[-–—•]?\s*METROPOLITANA\s*([A-Z])\s*[-–—:]?\s*$/gim,
        /(?:^|[:;]\s*)SRE\s+(?:DE\s+)?METROPOLITANA\s*([A-Z])\b/gim,
    ];
    let primeiraOutra = -1;
    for (const rx0 of padroes) {
        const rx = new RegExp(rx0.source, rx0.flags);
        let m;
        while ((m = rx.exec(texto)) !== null) {
            const nome = String(m[1] || '');
            if (!ehMetropolitanaA(nome) && !/^A$/i.test(nome.trim())) {
                if (primeiraOutra < 0 || m.index < primeiraOutra)
                    primeiraOutra = m.index;
            }
            if (rx.lastIndex === m.index)
                rx.lastIndex++;
        }
    }
    return primeiraOutra >= 0 ? texto.slice(0, primeiraOutra) : texto;
}
function chaveRegistroRecuperacao(r) {
    // Uma tabela larga de Férias-Prêmio pode repetir o MESMO MaSP várias
    // vezes no MESMO ato — uma linha por quinquênio de referência concedido,
    // todas com tipo/admissão/página/nome idênticos, mudando só a
    // "observacao" (quinquênio + data). Sem incluir a observacao na chave
    // para esse caso, a chave ficava igual para as várias linhas e a
    // recuperação Ctrl+F descartava as extras como se fossem duplicatas do
    // mesmo registro — apagando quinquênios genuinamente concedidos
    // (Diário 05/09/2026, pág. 38: Lilian de Souza tinha 4 linhas na tabela
    // e só 1 sobrevivia). Não se aplica a atos narrativos comuns, onde a
    // observacao varia de propósito entre as camadas de extração (tags como
    // "RECUPERADO_..." vs vazio) e por isso NÃO pode entrar na chave sem
    // recriar duplicatas do mesmo servidor.
    const ehTabelaLarga = (r.problemas_validacao || []).some((p) => p.startsWith('TABELA_LARGA_DIARIO'));
    return [
        r.tipo_ato || '', normalizarMasp(r.masp || ''), r.numero_ato || '',
        r.admissao || '', r.fonte_pagina || 0, normalizarNome(r.nome_servidor || ''),
        ehTabelaLarga ? (r.observacao || '') : '',
    ].join('|').toUpperCase();
}
/** Extrai os atos de um conjunto de páginas do Diário — devolve zero, um ou
 *  vários registros por página, um por servidor identificado, restrito a
 *  SEE/MG e SEPLAG/MG. */
export function parsearAtosDiario(paginas, tiposAtivos, _modoRecuperacaoCtrlF = false) {
    const logs = [];
    const registros = [];
    const setTipos = new Set(tiposAtivos);
    const vistos = new Set();
    // Registros recuperados pela segunda passagem "Ctrl+F" (ver mais abaixo)
    // vêm de uma chamada RECURSIVA e independente de parsearAtosDiario, cujo
    // próprio contador de trecho (trechoBase) reinicia do zero — o ordem_fonte
    // desses registros não é comparável ao ordem_fonte calculado pela
    // passagem principal da MESMA página. A âncora da Lotação (mais abaixo)
    // usa ordem_fonte para decidir o que descartar; sem esta marcação ela
    // sempre trata todo registro recuperado como "anterior" à Lotação da
    // passagem principal e apaga a recuperação inteira. Regressão real
    // (Diário 05/09/2026, pág. 38): 29 servidores de 3 tabelas largas,
    // corretamente recuperados pelo Ctrl+F, desapareciam de novo aqui.
    const recuperadosCtrlF = new Set();
    const dataEdicao = extrairDataEdicao(paginas);
    if (!dataEdicao) {
        logs.push({ nivel: "aviso", origem: "Diário", mensagem: "Data da edição não localizada no cabeçalho — coluna Publicação ficará vazia em todos os registros." });
    }
    // O ato de Acumulação da SEPLAG usa a ordem NOME -> MaSP e contém a SEE
    // como órgão listado DENTRO do ato. Ele é processado por um extrator
    // específico antes do fluxo narrativo genérico, sempre com fronteira
    // rígida no próximo cabeçalho de SRE.
    if (setTipos.has("acumulacao_cargos")) {
        const especial = extrairAcumulacoesMetropolitanaA(paginas, dataEdicao);
        registros.push(...especial.registros);
        logs.push(...especial.logs);
        for (const r of especial.registros) {
            vistos.add(`especial|${r.tipo_ato}|${r.masp}|${r.fonte_pagina}|${r.bloco_origem}`);
        }
    }
    let secretariaAtiva = "OUTRA";
    let sreAtiva = "DESCONHECIDA";
    let ultimaSecretariaTrecho = "OUTRA";
    let paginasForaDeEscopo = 0;
    let trechosOutrasSres = 0;
    // Campos opcionais (numeroAto/tipoLabel/tituloAto/textoLegal) só são
    // preenchidos pelo ramo de tabela larga (ver mais abaixo) — servem para
    // que uma tabela larga que atravessa página/coluna sem repetir o próprio
    // título ("FÉRIAS-PRÊMIO/CONCESSÃO - ATO Nº...") herde o número/título do
    // ato em vez de ficar com esses campos em branco na continuação.
    let ultimoAtoAtivo = null;
    // true quando a página ANTERIOR terminou no meio de uma tabela larga sem
    // nenhuma fronteira real (ver `PaginaPDF.terminaTabelaLarga`, encadeado
    // por `aplicarOrdemGeometricaDiario`/`extrairPaginasDiario`). Usado
    // abaixo para a página seguinte NÃO perder o escopo Metropolitana A só
    // porque outra SRE apareceu DEPOIS da tabela, ainda na página anterior —
    // ver o comentário de `sreAtiva === "ENCERRADA"`.
    let tabelaLargaContinuaDaPaginaAnterior = false;
    for (const pagina of paginas) {
        if (!pagina.texto || !pagina.texto.trim()) {
            tabelaLargaContinuaDaPaginaAnterior = !!pagina.terminaTabelaLarga;
            continue;
        }
        // Uma mesma página pode conter MAIS DE UM trecho independente da SRE
        // Metropolitana A (ex.: Diário 05/09/2026, pág. 38 — duas seções A/B/C
        // separadas na mesma página). `bloco.inicio` é um offset de caractere
        // DENTRO do texto de cada trecho, então reinicia em ~0 a cada novo
        // trecho — dois trechos diferentes podem gerar o MESMO ordem_fonte
        // pequeno mesmo estando um bem depois do outro na página. `trechoBase`
        // soma um deslocamento crescente a cada trecho para que a ordem entre
        // trechos nunca colida nem se inverta.
        let trechoIndexNaPagina = 0;
        // ENCERRADA vale somente para a página/seção onde outra SRE apareceu.
        // Ao avançar no Diário, voltamos a procurar um novo cabeçalho A, como
        // faria um Ctrl+F no documento inteiro. Se a página anterior terminou
        // ainda em A (sem outra SRE), o estado METROPOLITANA_A continua.
        //
        // Regressão real (Diário 02/10/2026, pág. 38→39): a tabela larga de
        // Férias-Prêmio da Metropolitana A terminava a página 38, mas OUTRAS
        // seções (Pouso Alegre, Uberlândia) vinham impressas DEPOIS dela, na
        // MESMA página — encerrando A ali mesmo. A página 39 (pura continuação
        // da tabela, sem repetir cabeçalho nenhum) então caía em DESCONHECIDA
        // em vez de retomar METROPOLITANA_A, e ficava inteira fora do escopo
        // permitido — mesmo com o texto corretamente reconstruído. Quando a
        // camada geométrica confirma que a tabela larga ainda estava aberta ao
        // fim da página anterior (`terminaTabelaLarga`), a página seguinte
        // retoma METROPOLITANA_A diretamente: outras seções impressas DEPOIS
        // da tabela, na página anterior, não mudam o fato de que esta nova
        // página começa onde a tabela parou.
        if (sreAtiva === "ENCERRADA") {
            sreAtiva = tabelaLargaContinuaDaPaginaAnterior ? "METROPOLITANA_A" : "DESCONHECIDA";
        }
        let divisaoSecretaria = dividirPorSecretaria(pagina.texto, secretariaAtiva);
        // Fotos/páginas isoladas da própria SRE frequentemente não repetem o
        // cabeçalho "Secretaria de Estado de Educação". Se a página não abriu
        // nenhuma secretaria mas traz um cabeçalho explícito SRE Metropolitana A,
        // é seguro tratá-la como SEE: SRE é uma estrutura da Educação.
        const soFora = divisaoSecretaria.trechos.every((t) => t.secretaria === "OUTRA");
        if (soFora && temCabecalhoExplicitoMetropolitanaA(pagina.texto)) {
            divisaoSecretaria = { trechos: [{ texto: pagina.texto, secretaria: "SEE" }], secretariaFinal: "SEE" };
            logs.push({ nivel: "info", origem: "Diário/Filtro", pagina: pagina.numero, mensagem: "Cabeçalho SRE Metropolitana A detectado em página isolada; página tratada como seção da SEE." });
        }
        secretariaAtiva = divisaoSecretaria.secretariaFinal;
        let algumTrechoNoEscopo = false;
        for (const trecho of divisaoSecretaria.trechos) {
            if (trecho.secretaria === "OUTRA") {
                ultimoAtoAtivo = null;
                sreAtiva = "DESCONHECIDA";
                ultimaSecretariaTrecho = "OUTRA";
                continue;
            }
            if (trecho.secretaria !== ultimaSecretariaTrecho) {
                sreAtiva = "DESCONHECIDA";
                ultimoAtoAtivo = null;
                ultimaSecretariaTrecho = trecho.secretaria;
            }
            const divisaoSre = dividirPorSreMetropolitanaA(trecho.texto, sreAtiva);
            sreAtiva = divisaoSre.sreFinal;
            for (const trechoSre of divisaoSre.trechos) {
                const trechoBase = trechoIndexNaPagina * 10000000;
                trechoIndexNaPagina++;
                if (trechoSre.sre !== "METROPOLITANA_A") {
                    if (trechoSre.sre === "OUTRA")
                        trechosOutrasSres++;
                    continue;
                }
                algumTrechoNoEscopo = true;
                const blocos = segmentarBlocosAto(trechoSre.texto);
                for (let bi = 0; bi < blocos.length; bi++) {
                    const blocoOriginal = blocos[bi];
                    // `inicio` recebe o deslocamento do trecho (ver `trechoBase` acima)
                    // para que o ordem_fonte calculado adiante nunca confunda a ordem
                    // relativa entre dois trechos A/B/C distintos da mesma página.
                    const bloco = { ...blocoOriginal, texto: recortarBlocoNoProximoTitulo(blocoOriginal.texto), inicio: trechoBase + blocoOriginal.inicio };
                    let tipoId = classificarTipoDoBloco(bloco.texto);
                    // `tipoHerdado` marca quando ESTE bloco não tem título/cabeçalho
                    // próprio e está reaproveitando o tipo do último ato ativo — ou
                    // seja, é a CONTINUAÇÃO de um ato que começou antes (em página,
                    // coluna ou trecho anterior), não um ato novo. Usado abaixo para
                    // que a tabela larga continue lendo linhas sem exigir de novo o
                    // cabeçalho "MUNICÍPIO ÓRGÃO DE LOTAÇÃO/EXERCÍCIO..." que só
                    // aparece uma vez, no topo da tabela.
                    let tipoHerdado = false;
                    if (!tipoId && bi === 0 && ultimoAtoAtivo && ultimoAtoAtivo.secretaria === trecho.secretaria) {
                        tipoId = ultimoAtoAtivo.tipoId;
                        tipoHerdado = true;
                    }
                    if (tipoId && !tipoHerdado)
                        ultimoAtoAtivo = { secretaria: trecho.secretaria, tipoId };
                    // Lotação tabular: cada linha é um servidor e não contém a palavra
                    // "MASP" antes do número, então o extrator narrativo não serve.
                    if (tipoId === "lotacao" && setTipos.has("lotacao")) {
                        const lotacoes = extrairLotacaoTabelaMetropolitanaA(bloco.texto, {
                            arquivo: pagina.arquivo,
                            pagina: pagina.numero,
                            dataEdicao,
                            secretaria: trecho.secretaria === "SEPLAG" ? "SEPLAG/MG" : "SEE/MG",
                            ordemBase: bloco.inicio,
                        });
                        if (lotacoes.length > 0) {
                            for (const reg of lotacoes) {
                                // Validação secundária com as planilhas de escolas fornecidas.
                                // O corte estrutural por SRE continua sendo a regra principal;
                                // esta lista serve apenas para bloquear contaminação inequívoca.
                                if (escolaEhExclusivaMetropolitanaB(reg.codigo_escola, reg.localidade_escola)) {
                                    logs.push({
                                        nivel: "aviso", origem: "Diário/Filtro", pagina: pagina.numero,
                                        mensagem: `Registro descartado: escola identificada exclusivamente na lista da SRE Metropolitana B — ${reg.localidade_escola || reg.codigo_escola || reg.nome_servidor}.`,
                                    });
                                    continue;
                                }
                                const chaveLot = `lotacao|${reg.id}`; // id inclui a posição da linha: repetições legítimas no próprio ato são preservadas
                                if (vistos.has(chaveLot))
                                    continue;
                                vistos.add(chaveLot);
                                registros.push(reg);
                                logs.push({ nivel: reg.confianca === "alta" ? "info" : "aviso", origem: "Diário/SEE", pagina: pagina.numero, mensagem: `[SRE METROPOLITANA A] Lotação: ${reg.nome_servidor} | MaSP ${reg.masp}.` });
                            }
                            continue;
                        }
                    }
                    // Tabela larga de Férias-Prêmio/Retificação (mesma armadilha da
                    // Lotação: o MaSP aparece sem a palavra "MASP" antes do número,
                    // só no cabeçalho da tabela, e nenhum extrator narrativo abaixo
                    // encontra ninguém). Regressão real (Diário 05/09/2026, pág. 38):
                    // 3 tabelas desse tipo, ~31 servidores, desapareciam por completo.
                    //
                    // Regressão real (Diário 02/10/2026, pág. 38→39): a MESMA tabela
                    // larga pode atravessar uma quebra de página/coluna do jornal sem
                    // repetir nem o título do ato ("FÉRIAS-PRÊMIO/CONCESSÃO - ATO
                    // Nº..."), nem o cabeçalho de colunas ("MUNICÍPIO ÓRGÃO DE
                    // LOTAÇÃO/EXERCÍCIO...") — a página seguinte só traz mais linhas
                    // de servidor direto, depois do timbre padrão "Documento assinado
                    // eletronicamente..." (um rodapé que aparece em TODA página do
                    // Diário, não um marcador de fim de tabela/ato). Sem herdar
                    // `numeroAtoTabela`/`tituloTabela`/`textoLegalTabela` do ato
                    // anterior quando o bloco não tem os seus próprios (ver
                    // `tipoHerdado`), a continuação até era lida (ver `emContinuacao`
                    // abaixo), mas como um ato "órfão" sem número/título.
                    if (tipoId && setTipos.has(tipoId)) {
                        const heranca = tipoHerdado ? ultimoAtoAtivo : null;
                        // Só entra em "modo continuação" (lê linha por linha sem exigir
                        // o cabeçalho da tabela de novo) quando o ato herdado já tinha
                        // sido lido como tabela larga da última vez — o mesmo tipoId
                        // herdado de um ato NARRATIVO (prosa comum) nunca ativa isso,
                        // então não tenta ler linhas de prosa como se fossem linha de
                        // tabela.
                        const emContinuacaoDeTabela = !!heranca?.formatoTabelaLarga;
                        const numeroAtoTabela = RE_NUMERO_ATO.exec(bloco.texto)?.[1]?.replace(/\s+/g, "") || heranca?.numeroAto || "";
                        const tipoLabelTabela = TIPO_ATO_LABEL[tipoId] || tipoId;
                        // Numa CONTINUAÇÃO de tabela (sem cabeçalho/título próprios), o
                        // bloco é só linha de servidor colada — sem nenhum marcador
                        // "MASP"/"SERVIDOR:" pra `extrairTextoLegalDoBloco` ancorar.
                        // Regressão real (Diário 02/10/2026, pág. 39): sem marcador, a
                        // função devolvia os ~1600 primeiros caracteres do bloco inteiro
                        // (a TABELA toda, linha após linha, sem quebra) como se fosse o
                        // texto legal do ato — e isso ia parar, repetido, em CADA
                        // servidor da Conferência Geral e da lista da tela. Em
                        // continuação, o texto legal nunca muda: usa sempre o herdado
                        // primeiro, só tentando extrair de novo se não há herança.
                        const textoLegalTabela = emContinuacaoDeTabela
                            ? (heranca?.textoLegal || extrairTextoLegalDoBloco(bloco.texto) || "")
                            : (extrairTextoLegalDoBloco(bloco.texto) || heranca?.textoLegal || "");
                        const tituloTabela = emContinuacaoDeTabela
                            ? (heranca?.tituloAto || extrairTituloOriginalDoBloco(bloco.texto, tipoLabelTabela, numeroAtoTabela) || "")
                            : (extrairTituloOriginalDoBloco(bloco.texto, tipoLabelTabela, numeroAtoTabela) || heranca?.tituloAto || "");
                        const tabelaLarga = extrairTabelaLargaFeriasPremio(bloco.texto, {
                            arquivo: pagina.arquivo,
                            pagina: pagina.numero,
                            dataEdicao,
                            secretaria: trecho.secretaria === "SEPLAG" ? "SEPLAG/MG" : "SEE/MG",
                            tipoAto: tipoId,
                            tipoLabel: tipoLabelTabela,
                            tituloAto: tituloTabela,
                            numeroAto: numeroAtoTabela,
                            anoAto: numeroAtoTabela.split("/")[1] || "",
                            textoLegal: textoLegalTabela,
                            ordemBase: bloco.inicio,
                        }, { emContinuacao: emContinuacaoDeTabela });
                        if (tabelaLarga.length > 0) {
                            // Guarda número/título/texto legal para uma PRÓXIMA página ou
                            // coluna que continue esta mesma tabela sem repeti-los.
                            ultimoAtoAtivo = { secretaria: trecho.secretaria, tipoId, numeroAto: numeroAtoTabela, tipoLabel: tipoLabelTabela, tituloAto: tituloTabela, textoLegal: textoLegalTabela, formatoTabelaLarga: true };
                            for (const reg of tabelaLarga) {
                                if (escolaEhExclusivaMetropolitanaB(reg.codigo_escola, reg.localidade_escola)) {
                                    logs.push({
                                        nivel: "aviso", origem: "Diário/Filtro", pagina: pagina.numero,
                                        mensagem: `Registro descartado: escola identificada exclusivamente na lista da SRE Metropolitana B — ${reg.localidade_escola || reg.codigo_escola || reg.nome_servidor}.`,
                                    });
                                    continue;
                                }
                                const chaveTab = `tabela_larga|${reg.id}`;
                                if (vistos.has(chaveTab))
                                    continue;
                                vistos.add(chaveTab);
                                registros.push(reg);
                                logs.push({
                                    nivel: "aviso", origem: "Diário/SEE", pagina: pagina.numero,
                                    mensagem: `[SRE METROPOLITANA A] ${tipoLabelTabela} (tabela larga): ${reg.nome_servidor} | MaSP ${reg.masp} — revisão necessária.`,
                                });
                            }
                            continue;
                        }
                    }
                    // Alteração de Nome usa "Velho para Novo" em vez de "Nome, Cargo,
                    // Admissão..." — nenhuma das redes abaixo (todas ancoradas em
                    // vírgula + código de cargo) encontra ninguém neste tipo de ato.
                    const ocorrenciasPrincipais = tipoId === "alteracao_nome"
                        ? extrairOcorrenciasAlteracaoNome(bloco.texto)
                        : extrairOcorrenciasDoBloco(bloco.texto);
                    const chavesOcorrencias = new Set(ocorrenciasPrincipais.map((o) => `${normalizarMasp(o.masp)}|${normalizarNome(o.nome)}`));
                    const recuperadas = tipoId === "alteracao_nome" ? [] : extrairOcorrenciasFallbackDoBloco(bloco.texto)
                        .filter((o) => !chavesOcorrencias.has(`${normalizarMasp(o.masp)}|${normalizarNome(o.nome)}`));
                    for (const o of recuperadas)
                        chavesOcorrencias.add(`${normalizarMasp(o.masp)}|${normalizarNome(o.nome)}`);
                    const auditadas = tipoId === "alteracao_nome" ? [] : extrairOcorrenciasAuditoriaBasica(bloco.texto)
                        .filter((o) => !chavesOcorrencias.has(`${normalizarMasp(o.masp)}|${normalizarNome(o.nome)}`));
                    const ocorrencias = [...ocorrenciasPrincipais, ...recuperadas, ...auditadas];
                    // Regressão real (Diário 05/09/2026, pág. 38): um ato de
                    // Férias-Prêmio/Afastamento redigido no SINGULAR ("ao servidor:",
                    // nunca "ao(s) servidor(es):") só tem, por definição, UM servidor.
                    // Quando a colagem de coluna deixa um trecho de OUTRO ato (sem
                    // nenhum título reconhecível no início) grudado logo depois da
                    // frase desse servidor único, o extrator encontra mais de uma
                    // ocorrência e atribuiria todas ao mesmo ato — com confiança
                    // "alta" mesmo sendo estruturalmente impossível (ex.: "ato Nº
                    // 621/2026" ficou com 6 pessoas em vez de 1, a 2ª em diante
                    // pertencendo de verdade ao ato de Luto Nº 26/2026 vizinho). Só a
                    // 1ª ocorrência (a mais próxima da frase singular) mantém a
                    // confiança normal; as demais são sempre REVISAR.
                    const RE_SERVIDOR_SINGULAR = /\b(?:AO|[ÀA])\s+SERVIDOR(?:A)?\s*:/i;
                    const RE_SERVIDOR_PLURAL = /\bSERVIDOR(?:A)?\s*(?:\(\s*S\s*\)|\(\s*ES\s*\)|AS|ES|S)\s*:/i;
                    const ehAtoDeServidorUnico = RE_SERVIDOR_SINGULAR.test(bloco.texto) && !RE_SERVIDOR_PLURAL.test(bloco.texto);
                    // AUDITORIA OBRIGATÓRIA MaSP x registros, ainda dentro do ato.
                    // Compara frequências, não apenas conjunto, para preservar casos
                    // como o mesmo MaSP em duas admissões diferentes.
                    //
                    // Auditada sobre `blocoOriginal.texto` (ANTES do corte de
                    // recortarBlocoNoProximoTitulo), não sobre `bloco.texto`. Regressão
                    // real (Diário 17/07/2026, pág. 36, Abono de Permanência 46/2026):
                    // quando quatro títulos de atos diferentes colam na MESMA linha
                    // logo no início do bloco ("ABONO... 46/2026 ANULAÇÃO... 32/2026
                    // REDUÇÃO... FÉRIAS-PRÊMIO... 513/2026"), o corte acontece a
                    // poucos caracteres do próprio título do bloco — antes mesmo do
                    // corpo real do ato aparecer. O servidor (Regina Barbosa Pereira,
                    // MASP 858904-6) ficava truncado fora do texto E fora da própria
                    // auditoria, que também rodava sobre o texto já cortado: a pessoa
                    // desaparecia em silêncio, sem nenhum aviso. Auditar o texto
                    // original garante que uma MaSP publicada e perdida no corte
                    // sempre vira um [AUDITORIA FALHOU] visível — nunca um sumiço
                    // silencioso — mesmo quando a extração automática não consegue
                    // atribuí-la ao ato certo com segurança.
                    // Acumulação de Cargos é tratada por um extrator próprio, chamado
                    // uma única vez para toda a página ANTES deste laço por bloco (ver
                    // `extrairAcumulacoesMetropolitanaA`) — os "ocorrencias" calculados
                    // aqui em cima usam os extratores narrativos genéricos, que não
                    // entendem o formato "NOME -Masp 0000000-0, cargo;" desse ato e por
                    // isso SEMPRE acusam falta, mesmo quando o extrator especializado já
                    // encontrou o servidor corretamente. Sem este desvio, a página fica
                    // com um [AUDITORIA FALHOU] falso-positivo permanente (Diário
                    // 05/09/2026, pág. 17) mesmo depois de os 9 servidores já terem
                    // sido corretamente recuperados.
                    //
                    // A lista de servidores da Acumulação às vezes fica isolada no seu
                    // PRÓPRIO trecho de SRE (o cabeçalho "-SRE METROPOLITANA A:" abre
                    // um trechoSre novo), separado do título do ato que fica um trecho
                    // antes — nesse caso o bloco desta lista nem chega a ser
                    // classificado (tipoId fica null), mas o formato "NOME -Masp
                    // 0000000-0," é inconfundível e nunca aparece em nenhum outro tipo
                    // de ato: detectá-lo aqui, independente do tipoId, evita o mesmo
                    // falso-positivo mesmo quando a classificação falha.
                    const pareceListaDeAcumulacao = /-\s*Masp\s*[\d.\s]{4,15}[-–]\s*\d{1,2}\s*,/i.test(blocoOriginal.texto);
                    // Mesmo desvio, mesmo motivo: a tabela larga de Férias-Prêmio
                    // (uma linha por servidor, cabeçalho "MUNICÍPIO ÓRGÃO DE
                    // LOTAÇÃO/EXERCÍCIO") é extraída por `extrairTabelaLargaFeriasPremio`,
                    // não pelos extratores narrativos genéricos usados aqui. Sem este
                    // desvio, toda MaSP dessa tabela (já corretamente capturada pelo
                    // extrator especializado) é acusada de "não virou registro" por
                    // esta auditoria genérica, que não entende o formato de tabela —
                    // um [AUDITORIA FALHOU] falso-positivo por servidor da tabela.
                    const pareceTabelaLargaFeriasPremio = RE_TABELA_LARGA_CABECALHO.test(blocoOriginal.texto);
                    if (tipoId !== "acumulacao_cargos" && !pareceListaDeAcumulacao && !pareceTabelaLargaFeriasPremio) {
                        const maspsPublicados = listarMaspsPublicadosNoBloco(blocoOriginal.texto);
                        const freqPublicado = new Map();
                        const freqExtraido = new Map();
                        for (const m of maspsPublicados)
                            freqPublicado.set(m, (freqPublicado.get(m) || 0) + 1);
                        for (const o of ocorrencias)
                            freqExtraido.set(o.masp, (freqExtraido.get(o.masp) || 0) + 1);
                        const faltantesNoAto = [];
                        for (const [m, qtd] of freqPublicado) {
                            const faltam = qtd - (freqExtraido.get(m) || 0);
                            for (let n = 0; n < faltam; n++)
                                faltantesNoAto.push(m);
                        }
                        if (faltantesNoAto.length) {
                            // Tenta recuperação de último recurso ANTES de só avisar: procura
                            // exatamente essas MaSPs (comprovadamente publicadas, mas
                            // ausentes) no texto ORIGINAL do bloco, sem o corte de
                            // recortarBlocoNoProximoTitulo. Cobre o caso de vários títulos de
                            // ato colados na MESMA linha logo no início do bloco (Diário
                            // 17/07/2026, pág. 36, Abono de Permanência 46/2026: "ABONO...
                            // 46/2026 ANULAÇÃO... 32/2026 REDUÇÃO... FÉRIAS-PRÊMIO...
                            // 513/2026" tudo numa linha só) — o corte acontece a poucos
                            // caracteres do próprio título, antes do corpo real do bloco
                            // existir, e nem a extração principal nem o fallback normal (que
                            // rodam sobre o texto já cortado) alcançam a pessoa. Como o
                            // texto original comprovou ter mais de um título de ato colado,
                            // o tipo atribuído aqui (o tipo classificado para O BLOCO
                            // INTEIRO) não é confiável sem conferência humana — por isso
                            // toda ocorrência recuperada por este caminho entra sempre como
                            // REVISAR (ver o `problemas.push` correspondente mais abaixo),
                            // nunca "alta", mesmo com MaSP/nome limpos.
                            const faltantesSet = new Set(faltantesNoAto);
                            const recuperadasDoOriginal = extrairOcorrenciasAuditoriaBasica(blocoOriginal.texto)
                                .filter((o) => {
                                const chave = `${normalizarMasp(o.masp)}|${normalizarNome(o.nome)}`;
                                return faltantesSet.has(normalizarMasp(o.masp)) && !chavesOcorrencias.has(chave);
                            });
                            for (const o of recuperadasDoOriginal) {
                                o.observacao = ["RECUPERADO_BLOCO_TITULOS_COLADOS", o.observacao.replace(/RECUPERADO_AUDITORIA_BASICA\s*\|?\s*/, "").trim()]
                                    .filter(Boolean).join(" | ");
                                chavesOcorrencias.add(`${normalizarMasp(o.masp)}|${normalizarNome(o.nome)}`);
                                ocorrencias.push(o);
                                logs.push({
                                    nivel: "aviso", origem: "Diário/Auditoria", pagina: pagina.numero,
                                    mensagem: `[RECUPERAÇÃO — TÍTULOS COLADOS] ${o.nome} | MaSP ${o.masp} recuperado(a) de um bloco com mais de um título de ato colado na mesma linha. Confira o TIPO do ato antes de aprovar — pode pertencer a um ato diferente do classificado aqui.`,
                                });
                            }
                            const aindaFaltando = faltantesNoAto.filter((m) => !recuperadasDoOriginal.some((o) => normalizarMasp(o.masp) === m));
                            if (aindaFaltando.length) {
                                logs.push({
                                    nivel: "aviso", origem: "Diário/Auditoria", pagina: pagina.numero,
                                    mensagem: `[AUDITORIA FALHOU] ${aindaFaltando.length} ocorrência(s) de MaSP publicada(s) no ato da SRE Metropolitana A não viraram registro: ${aindaFaltando.join(", ")}. O processamento deve permanecer em REVISAR.`,
                                });
                                // Regressão real (Diário 01/10/2026, pág. 34): a própria
                                // publicação, não a leitura, omite o nome do servidor junto a
                                // certos MaSPs ("MaSP 1142971-9, PEBD1A, Adm 01, a contar de
                                // 13/09/2026" — sem nome nenhum entre a MaSP e o cargo). Sem
                                // nome, nenhuma rede de extração acha uma ocorrência pra essa
                                // pessoa, e ela ficava só num log técnico — fácil de nunca
                                // ser visto por quem está conferindo a tela. Em vez de só
                                // logar, entra também como registro REVISAR (MaSP visível,
                                // nome em branco), pra aparecer na lista principal e na
                                // Conferência Geral — nunca some em silêncio, mesmo sem como
                                // adivinhar o nome.
                                for (const m of aindaFaltando) {
                                    if (!maspPublicadaSemNomeNoBloco(blocoOriginal.texto, m))
                                        continue;
                                    ocorrencias.push({
                                        masp: m, nome: "", nomeTruncado: false, cargo: "", admissao: "", vigencia: "", quinquenio: "",
                                        observacao: "NOME_NAO_PUBLICADO",
                                        sre: trecho.secretaria, municipio: "", codigoEscola: "", escolaOrgao: "",
                                        blocoOrigemTrecho: blocoOriginal.texto.slice(0, 1200),
                                    });
                                }
                            }
                        }
                    }
                    // V24: ato não classificado NÃO vira IA. Isso elimina registros de
                    // vice-diretor, assinaturas e outros textos administrativos que não
                    // pertencem ao catálogo de atos emitidos pela DIPE.
                    if (!tipoId || tipoId === "outro" || !setTipos.has(tipoId) || tipoId === "acumulacao_cargos")
                        continue;
                    const numeroAtoMatch = RE_NUMERO_ATO.exec(bloco.texto);
                    const numeroAto = numeroAtoMatch ? numeroAtoMatch[1].replace(/\s+/g, "") : "";
                    const tipoLabel = TIPO_ATO_LABEL[tipoId] || tipoId;
                    const textoLegal = extrairTextoLegalDoBloco(bloco.texto);
                    const tituloOriginal = extrairTituloOriginalDoBloco(bloco.texto, tipoLabel, numeroAto);
                    const cabecalhoFixo = [tituloOriginal, textoLegal].filter(Boolean).join("\n");
                    ocorrencias.forEach((oc, idxOcorrencia) => {
                        const chave = `${tipoId}|${oc.masp}|${numeroAto}|${pagina.numero}|${bloco.inicio}|${idxOcorrencia}`;
                        if (vistos.has(chave))
                            return;
                        vistos.add(chave);
                        // Segunda barreira contra vazamento de regional: se a escola/código
                        // pertence exclusivamente à lista oficial da Metropolitana B, o
                        // registro não pode entrar no escopo A, mesmo que OCR tenha
                        // misturado colunas. Registros sem escola continuam sendo decididos
                        // exclusivamente pelo cabeçalho/estado da SRE.
                        if (escolaEhExclusivaMetropolitanaB(oc.codigoEscola, oc.escolaOrgao)) {
                            logs.push({
                                nivel: "aviso", origem: "Diário/Filtro", pagina: pagina.numero,
                                mensagem: `Servidor descartado por escola exclusiva da SRE Metropolitana B: ${oc.nome} | MaSP ${oc.masp} | ${oc.escolaOrgao}.`,
                            });
                            return;
                        }
                        const vMasp = validarMasp(oc.masp);
                        const problemas = [];
                        if (!vMasp.valido)
                            problemas.push(`MaSP: ${vMasp.motivo}`);
                        if (oc.escolaOrgao) {
                            const vOrg = validarOrgao(oc.escolaOrgao);
                            if (!vOrg.valido)
                                problemas.push(`Escola/Órgão: ${vOrg.motivo}`);
                        }
                        if (oc.nomeTruncado)
                            problemas.push("Nome truncado antes de um trecho administrativo — confira o nome completo.");
                        // Recuperação por fallback não é erro por si só. Se MaSP, nome,
                        // ato e campos estruturais passaram nas validações, o registro é
                        // utilizável normalmente. REVISAR fica reservado a problema real.
                        if (tipoId === "outro")
                            problemas.push("ATO_NAO_CLASSIFICADO: ato da Metropolitana A detectado, mas o tipo não foi reconhecido automaticamente.");
                        // Diferente das outras recuperações: esta vem de um bloco cujo
                        // próprio texto original provou ter mais de um título de ato
                        // colado na mesma linha — o tipo aqui atribuído (o tipo
                        // classificado para o bloco inteiro) pode pertencer a um ato
                        // diferente do da pessoa recuperada. Nunca "alta" sem conferência.
                        if (/RECUPERADO_BLOCO_TITULOS_COLADOS/.test(oc.observacao)) {
                            problemas.push("RECUPERADO_BLOCO_TITULOS_COLADOS: mais de um título de ato colado no mesmo bloco — confira se este é mesmo o tipo do ato desta pessoa.");
                        }
                        if (/NOME_NAO_PUBLICADO/.test(oc.observacao)) {
                            problemas.push("NOME_NAO_PUBLICADO: esta MaSP foi publicada neste ato, mas sem nenhum nome de servidor junto a ela no texto original — confira a publicação impressa/original do Diário.");
                        }
                        if (ehAtoDeServidorUnico && idxOcorrencia > 0) {
                            problemas.push("SERVIDOR_EXTRA_EM_ATO_SINGULAR: o texto deste ato diz \"ao servidor\" (no singular), mas mais de uma pessoa foi encontrada — esta pode pertencer a um ato vizinho colado por engano de leitura de coluna.");
                        }
                        registros.push({
                            id: `dia_${pagina.arquivo}_${pagina.numero}_${slug(oc.masp)}_${registros.length}`,
                            selecionar: problemas.length === 0,
                            tipo_ato: tipoId,
                            tipo_label: tipoLabel,
                            titulo_ato: tituloOriginal,
                            cabecalho_ato: cabecalhoFixo,
                            numero_ato: numeroAto,
                            ano_ato: numeroAto.split("/")[1] || "",
                            texto_legal: textoLegal,
                            fundamentacao_legal: textoLegal,
                            masp: oc.masp,
                            nome_servidor: oc.nome,
                            secretaria: trecho.secretaria === "SEPLAG" ? "SEPLAG/MG" : "SEE/MG",
                            cargo: oc.cargo,
                            admissao: oc.admissao,
                            data_vigencia: oc.vigencia,
                            quinquenio: oc.quinquenio,
                            observacao: oc.observacao,
                            // Escala de página em 1e12 (não 1e9) para sobrar espaço de sobra
                            // ao deslocamento de `trechoBase` já somado em `bloco.inicio`
                            // (ver comentário sobre `trechoIndexNaPagina` acima) sem jamais
                            // invadir a faixa numérica da página seguinte.
                            ordem_fonte: pagina.numero * 1000000000000 + bloco.inicio * 100 + idxOcorrencia,
                            municipio: oc.municipio,
                            // O contexto da SRE é a fonte de verdade. Não reutiliza uma
                            // SRE extraída heurísticamente de linhas anteriores.
                            orgao_sre: "SRE METROPOLITANA A",
                            codigo_escola: oc.codigoEscola,
                            localidade_escola: oc.codigoEscola && oc.escolaOrgao
                                ? `${oc.codigoEscola} - ${oc.escolaOrgao}`
                                : (oc.escolaOrgao || ""),
                            pagina_jornal: `PÁG. ${pagina.numero}`,
                            data_jornal: dataEdicao,
                            texto_ato: oc.blocoOrigemTrecho,
                            fonte_arquivo: pagina.arquivo,
                            fonte_pagina: pagina.numero,
                            bloco_origem: oc.blocoOrigemTrecho,
                            texto_origem: pagina.texto,
                            confianca: problemas.length ? "revisar" : "alta",
                            problemas_validacao: problemas,
                            historico_alteracoes: [],
                        });
                    });
                }
            }
        }
        const registrosDestaPagina = registros.filter((r) => r.fonte_pagina === pagina.numero && (!r.fonte_arquivo || r.fonte_arquivo === pagina.arquivo));
        const basePagina = baseText(pagina.texto);
        const temMaspPublicado = /\bMASP\b/.test(basePagina);
        const temSinalDeAto = /ATO\s+N|LICENCA|AFASTAMENTO|FERIAS|RETIFICA|ANULA|CONCEDE|LOTACAO|ABONO|DESIGNA/.test(basePagina);
        if (algumTrechoNoEscopo && temMaspPublicado && temSinalDeAto && registrosDestaPagina.length === 0) {
            logs.push({
                nivel: "aviso", origem: "Diário/Leitura", pagina: pagina.numero,
                mensagem: `[LEITURA PARCIAL] PÁG. ${pagina.numero}: há sinais de ato + MaSP no trecho da SRE Metropolitana A, mas nenhum servidor foi validado. Confira a página original para garantir que nenhum servidor ficou sem I.A.`,
            });
        }
        if (!algumTrechoNoEscopo)
            paginasForaDeEscopo++;
        tabelaLargaContinuaDaPaginaAnterior = !!pagina.terminaTabelaLarga;
    }
    // SEGUNDA PASSAGEM "CTRL+F": procura TODAS as ocorrências explícitas de
    // Metropolitana A no texto integral, inclusive depois de uma Metropolitana
    // B/C anterior e inclusive em outra secretaria/seção do mesmo Diário.
    if (!_modoRecuperacaoCtrlF) {
        const virtuais = [];
        // Mesmo propósito de `tabelaLargaContinuaDaPaginaAnterior` acima, mas
        // para esta passagem Ctrl+F: ela abre uma janela por página, sempre
        // que acha um cabeçalho "SRE Metropolitana A" PRÓPRIO daquela página —
        // uma página de pura continuação (sem repetir cabeçalho nenhum) nunca
        // abria janela nenhuma, então a tabela nunca continuava aqui também.
        // Regressão real (Diário 02/10/2026, pág. 38→39): a janela da pág. 38
        // corretamente limitava a tabela aos 5 servidores ali (a camada
        // geométrica, sem cabeçalho repetido, vazava para o ato seguinte de
        // outra SRE impresso na coluna seguinte da MESMA página — ver o
        // cabeçalho do bloco acima); mas os 14 da pág. 39 nunca eram incluídos.
        let continuaDaPaginaAnterior = false;
        for (const p of paginas) {
            // A recuperação usa a camada integral quando disponível, pois ela funciona
            // como Ctrl+F e encontra cabeçalhos/servidores que a reconstrução
            // geométrica pode perder. A função janelasControleFMetropolitanaA faz
            // o corte estrutural no próximo cabeçalho de qualquer outra SRE, então
            // a camada integral nunca é usada sem essa fronteira.
            const fonteBusca = p.textoBuscaDiario || p.texto || '';
            const janelas = janelasControleFMetropolitanaA(fonteBusca);
            if (janelas.length === 0 && continuaDaPaginaAnterior && virtuais.length) {
                // Sem cabeçalho próprio nesta página, mas a tabela larga da
                // anterior ainda estava aberta: a continuação (cortada no primeiro
                // cabeçalho de outra SRE que porventura apareça aqui) entra como
                // uma NOVA página virtual, sequencial à anterior — NUNCA colada
                // no mesmo texto dela. Grudar os dois textos faria esta chamada
                // recursiva reviver exatamente o mesmo bug que motivou todo este
                // mecanismo: o "Documento assinado..." do fim da janela anterior
                // (ainda dentro do MESMO bloco/texto) voltaria a cortar a leitura
                // de linha antes de alcançar a continuação. Como página virtual
                // SEPARADA, a própria passagem recursiva de `parsearAtosDiario`
                // (mais abaixo) herda o ato ativo entre as duas (`ultimoAtoAtivo`/
                // `tipoHerdado`/`formatoTabelaLarga`) exatamente como já faz para
                // páginas reais.
                const continuacao = cortarNoPrimeiroCabecalhoDeOutraSre(fonteBusca);
                if (continuacao.trim()) {
                    virtuais.push({ ...p, texto: continuacao, textoBuscaDiario: undefined });
                }
            }
            continuaDaPaginaAnterior = !!p.terminaTabelaLarga;
            for (let j = 0; j < janelas.length; j++) {
                virtuais.push({
                    ...p,
                    texto: janelas[j],
                    textoBuscaDiario: undefined,
                });
            }
        }
        if (virtuais.length) {
            const rec = parsearAtosDiario(virtuais, tiposAtivos, true);
            const chaves = new Set(registros.map(chaveRegistroRecuperacao));
            // A busca Ctrl+F roda sobre a camada LINEAR (sem reordenar por coluna),
            // então um MaSP que já apareceu corretamente na leitura por coluna
            // pode, na leitura linear, cair colado ao fragmento de outra coluna
            // vizinha — produzindo um registro fantasma com o mesmo MaSP só que
            // com nome truncado/trocado e sob um tipo de ato errado (ex.: MaSP de
            // Thiago Henrique Amaro, real em Licença-Paternidade, recuperado como
            // uma "Anulação" com cargo "Kubitschek – São Geraldo"). Como o MaSP é
            // o identificador confiável da pessoa, qualquer MaSP já presente na
            // leitura por coluna nunca precisa de recuperação: a pessoa já foi
            // capturada, e inventar mais um registro por Ctrl+F só arrisca
            // misturar atos — exatamente o problema que esta camada existe para
            // evitar, não para causar.
            const maspsJaEncontrados = new Set(registros.map((r) => normalizarMasp(r.masp || "")).filter(Boolean));
            let recuperados = 0;
            for (const r of rec.registros) {
                const k = chaveRegistroRecuperacao(r);
                if (chaves.has(k))
                    continue;
                if (r.masp && maspsJaEncontrados.has(normalizarMasp(r.masp)))
                    continue;
                chaves.add(k);
                registros.push(r);
                recuperadosCtrlF.add(r);
                recuperados++;
                logs.push({
                    nivel: r.confianca === 'alta' ? 'info' : 'aviso',
                    origem: r.secretaria === 'SEPLAG/MG' ? 'Diário/SEPLAG/Ctrl+F' : 'Diário/SEE/Ctrl+F',
                    pagina: r.fonte_pagina,
                    mensagem: `[RECUPERAÇÃO CTRL+F] SRE Metropolitana A: ${r.nome_servidor} | MaSP ${r.masp}.`,
                });
            }
            logs.push({
                nivel: 'info', origem: 'Diário/Filtro',
                mensagem: `Busca integral tipo Ctrl+F concluída: ${virtuais.length} janela(s) da SRE Metropolitana A localizada(s); ${recuperados} registro(s) ausente(s) recuperado(s).`,
            });
        }
    }
    // ÂNCORA DA TABELA DE LOTAÇÃO: em uma página que contém a tabela oficial
    // da Metropolitana A, a leitura operacional começa no PRIMEIRO servidor
    // impresso da tabela. Isso impede que qualquer ruído/ato acima da tabela
    // na mesma página apareça na lista, mas preserva páginas anteriores válidas
    // (ex.: Acumulação da SEPLAG) e todos os atos narrativos que vêm depois.
    let totalRemovidosAntesDaAncora = 0;
    const paginasComAncora = new Map();
    for (const r of registros) {
        // Um registro recuperado pelo Ctrl+F (ver `recuperadosCtrlF` acima) vem
        // de uma chamada recursiva com numeração de trecho própria, incomparável
        // com o ordem_fonte desta passagem — nunca serve de âncora aqui.
        if (r.tipo_ato !== "lotacao" || r.ordem_fonte == null || recuperadosCtrlF.has(r))
            continue;
        const k = `${r.fonte_arquivo || ""}|${r.fonte_pagina || 0}`;
        const atual = paginasComAncora.get(k);
        if (atual == null || r.ordem_fonte < atual)
            paginasComAncora.set(k, r.ordem_fonte);
    }
    if (paginasComAncora.size) {
        for (let i = registros.length - 1; i >= 0; i--) {
            const r = registros[i];
            // Idem: um registro recuperado pelo Ctrl+F nunca é removido por uma
            // âncora calculada com a numeração de outra passagem — do contrário
            // TODA recuperação Ctrl+F de uma página com Lotação seria apagada
            // aqui (regressão real: Diário 05/09/2026, pág. 38 — 29 servidores
            // de 3 tabelas largas, corretamente recuperados, eram apagados de
            // volta por esta âncora).
            if (recuperadosCtrlF.has(r))
                continue;
            const k = `${r.fonte_arquivo || ""}|${r.fonte_pagina || 0}`;
            const ancora = paginasComAncora.get(k);
            if (ancora != null && r.ordem_fonte != null && r.ordem_fonte < ancora) {
                totalRemovidosAntesDaAncora++;
                registros.splice(i, 1);
            }
        }
        for (const [k] of paginasComAncora) {
            const [, pag] = k.split("|");
            const primeiro = registros
                .filter((r) => `${r.fonte_arquivo || ""}|${r.fonte_pagina || 0}` === k && r.tipo_ato === "lotacao")
                .sort((a, b) => (a.ordem_fonte || 0) - (b.ordem_fonte || 0))[0];
            if (primeiro)
                logs.push({
                    nivel: "info", origem: "Diário/Filtro", pagina: Number(pag) || undefined,
                    mensagem: `Âncora de início aplicada: leitura da página começa no primeiro servidor da Lotação — ${primeiro.nome_servidor} | MaSP ${primeiro.masp}. Conteúdo anterior na mesma página foi ignorado.`,
                });
        }
    }
    if (totalRemovidosAntesDaAncora > 0) {
        logs.push({ nivel: "info", origem: "Diário/Filtro", mensagem: `${totalRemovidosAntesDaAncora} registro(s) anterior(es) ao primeiro servidor da Lotação foram descartados na(s) própria(s) página(s) da tabela.` });
    }
    // Sem correções por data, página, nome ou MaSP. Casos históricos devem
    // ser cobertos por testes de regressão, nunca por injeção de dados no parser.
    // LIMPEZA FINAL ANTI-CONTAMINAÇÃO.
    // Remove apenas evidências inequívocas de vazamento estrutural; nunca usa
    // whitelist de nomes. Isso impede registros de Metropolitana B/outras SREs,
    // assinaturas e recuperações que misturaram dois atos/colunas.
    const reOutraSreEstrutural = /(?:^|[:;\n])\s*SRE\s+(?:DE\s+)?(?!METROPOLITANA\s*A\b)(?:METROPOLITANA\s*[B-Z]\b|DIVINOPOLIS\b|JUIZ\s+DE\s+FORA\b|GOV\.?\s*VALADARES\b|[A-ZÀ-Ü][A-ZÀ-Ü \.]{2,40})/i;
    const reNomeContaminado = /\b(CONCEDE|REGISTRA|RETIFICA|ANULA|LICEN[ÇC]A|PATERNIDADE|MATERNIDADE|DOCUMENTO\s+ASSINADO|SECRET[ÁA]RIO|SUPERINTEND[ÊE]NCIA|PORTARIA|PROCESSO)\b/i;
    const reTituloAto = /(?:^|\n)\s*(?:ATO\s*N[ºo°.]|RETIFICA[ÇC][ÃA]O|ANULA[ÇC][ÃA]O|LICEN[ÇC]A|AFASTAMENTO|F[ÉE]RIAS[\s–—\/-]*PR[ÊE]MIO|ABONO\s+DE\s+PERMAN[ÊE]NCIA|LOTA[ÇC][ÃA]O)\b/gim;
    for (let i = registros.length - 1; i >= 0; i--) {
        const r = registros[i];
        const origem = `${r.bloco_origem || ''}\n${r.texto_ato || ''}`;
        const recuperado = /RECUPERADO_(?:FALLBACK_MASP|AUDITORIA_BASICA)/i.test(r.observacao || '');
        const titulos = [...origem.matchAll(reTituloAto)].length;
        const outraSre = reOutraSreEstrutural.test(origem);
        const nomeRuim = reNomeContaminado.test(r.nome_servidor || '');
        // Em recuperação, mais de um título de ato no mesmo bloco prova que a
        // geometria misturou colunas; não aceitamos a associação heurística.
        const blocoMisturado = recuperado && titulos > 1;
        if (outraSre || nomeRuim || blocoMisturado) {
            logs.push({
                nivel: 'aviso', origem: 'Diário/Limpeza', pagina: r.fonte_pagina,
                mensagem: `Registro descartado por contaminação estrutural: ${r.nome_servidor || '(sem nome)'} | MaSP ${r.masp || '(sem MaSP)'}.`,
            });
            registros.splice(i, 1);
            continue;
        }
        // Remove a etiqueta técnica do texto publicado. Ela continua implícita
        // nos logs, mas não deve aparecer como parte da IA nem forçar REVISAR.
        if (recuperado && r.observacao) {
            r.observacao = r.observacao
                .replace(/\s*[|]?\s*RECUPERADO_FALLBACK_MASP\s*/ig, ' ')
                .replace(/\s*[|]?\s*RECUPERADO_AUDITORIA_BASICA\s*/ig, ' ')
                .replace(/\s*\|\s*$/g, '').trim();
        }
        if (r.problemas_validacao?.length === 0) {
            r.confianca = 'alta';
            r.selecionar = true;
        }
    }
    // Deduplicação conservadora: remove somente cópia idêntica do mesmo ato,
    // MaSP, nome, admissão e página. Diferentes atos/admissões são preservados.
    //
    // Uma tabela larga de Férias-Prêmio pode repetir o MESMO MaSP várias
    // vezes no MESMO ato — uma linha por quinquênio de referência concedido,
    // com tipo/numero_ato/admissão/página/nome idênticos entre as linhas e só
    // a "observacao" (quinquênio + data) mudando. Sem incluir a observacao na
    // chave para esse caso, esta limpeza também as tratava como cópias do
    // mesmo registro (Diário 05/09/2026, pág. 38: Lilian de Souza tinha 4
    // linhas na tabela e só 1 sobrevivia).
    const chavesFinais = new Set();
    for (let i = registros.length - 1; i >= 0; i--) {
        const r = registros[i];
        const ehTabelaLarga = (r.problemas_validacao || []).some((p) => p.startsWith('TABELA_LARGA_DIARIO'));
        const k = [r.fonte_arquivo || '', r.fonte_pagina || 0, r.tipo_ato || '', r.numero_ato || '', normalizarMasp(r.masp || ''), normalizarNome(r.nome_servidor || ''), r.admissao || '', ehTabelaLarga ? (r.observacao || '') : ''].join('|').toUpperCase();
        if (chavesFinais.has(k))
            registros.splice(i, 1);
        else
            chavesFinais.add(k);
    }
    // ESCOPO FINAL DO DIÁRIO — TODOS OS SERVIDORES DA METROPOLITANA A.
    //
    // A tabela de Lotação e os atos narrativos pertencem ao mesmo escopo
    // institucional e ambos precisam chegar à conferência/I.A. quando possuem
    // servidor individualizado. A fronteira de SRE já foi aplicada ANTES, por
    // dividirPorSreMetropolitanaA(): ao aparecer o cabeçalho estrutural
    // "SRE Metropolitana B", "C" ou qualquer outra SRE, os trechos posteriores
    // não entram em `registros`.
    //
    // Portanto NÃO removemos a Lotação quando existem atos narrativos depois.
    // A ordem final é exclusivamente a ordem física da fonte:
    // página -> região -> coluna -> posição -> servidor dentro do ato.
    //
    // Regra de escopo:
    //   1) entrou em SRE METROPOLITANA A -> mantém TODOS os servidores válidos;
    //   2) preserva exatamente a ordem física: página -> coluna esquerda para
    //      direita -> topo para baixo -> servidor dentro do ato;
    //   3) ao encontrar o PRIMEIRO cabeçalho estrutural de outra SRE
    //      (Metropolitana B/C/etc.), encerra definitivamente o escopo;
    //   4) nunca usa whitelist de nomes/MaSP para decidir quem pertence à A.
    //
    // Atos sem servidor individualizado (ex.: Anulação 25/26) podem ser
    // detectados/logados, mas não geram um RegistroDiario de pessoa.
    registros.sort((a, b) => (a.ordem_fonte || 0) - (b.ordem_fonte || 0));
    if (registros.length === 0) {
        logs.push({ nivel: "aviso", origem: "Diário", mensagem: "Nenhum servidor encontrado no escopo permitido: SEE/SEPLAG + SRE Metropolitana A." });
    }
    else {
        logs.push({ nivel: "info", origem: "Diário/Filtro", mensagem: `Filtro rígido aplicado: ${registros.length} registro(s) mantido(s), todos vinculados à SRE Metropolitana A.` });
    }
    if (paginasForaDeEscopo > 0) {
        logs.push({ nivel: "info", origem: "Diário/Filtro", mensagem: `${paginasForaDeEscopo} página(s) sem trecho elegível da SRE Metropolitana A foram ignoradas.` });
    }
    if (trechosOutrasSres > 0) {
        logs.push({ nivel: "info", origem: "Diário/Filtro", mensagem: `${trechosOutrasSres} trecho(s) de outras SREs foram descartados; Metropolitana B/C e demais regionais não geram I.A.` });
    }
    // Auditoria de MaSP repetida com dados divergentes — achado manualmente
    // mais de uma vez nesta sessão (ex.: mesma MaSP em duas escolas/cargos
    // diferentes, um caso legítimo de dois vínculos, outro possível dígito
    // trocado). Em vez de depender de olhar manualmente, todo MaSP que se
    // repete com escola OU cargo diferentes agora gera um aviso automático —
    // nunca muda `confianca` nem bloqueia nada, é só um alerta pra conferência
    // humana decidir se é a mesma pessoa com dois cargos ou uma MaSP errada.
    const porMasp = new Map();
    for (const r of registros) {
        const chave = (r.masp || "").replace(/\D/g, "");
        if (!chave)
            continue;
        (porMasp.get(chave) || porMasp.set(chave, []).get(chave)).push(r);
    }
    for (const [, regs] of porMasp) {
        if (regs.length < 2)
            continue;
        const escolas = new Set(regs.map((r) => (r.localidade_escola || "").trim()).filter(Boolean));
        const cargos = new Set(regs.map((r) => (r.cargo || "").trim()).filter(Boolean));
        if (escolas.size > 1 || cargos.size > 1) {
            const resumo = regs.map((r) => `${r.nome_servidor || "(sem nome)"} — ${r.localidade_escola || "(sem escola)"} / ${r.cargo || "(sem cargo)"}`).join(" | ");
            logs.push({
                nivel: "aviso", origem: "Diário/Auditoria",
                mensagem: `MaSP ${regs[0].masp} aparece em ${regs.length} registros com escola ou cargo diferentes — confira se é a mesma pessoa com mais de um vínculo ou se a MaSP saiu errada em algum deles: ${resumo}.`,
            });
        }
    }
    return { registros, logs };
}
/** Aplica a ordem física do Diário sempre que a geometria nativa existe.
 *  IMPORTANTE: `usouOcr` não desativa esta etapa. O OCR pode melhorar a
 *  leitura, mas não conhece a ordem das colunas; x/y nativo é a fonte da
 *  sequência visual e do corte no cabeçalho da próxima SRE.
 *
 *  `continuaTabelaLarga` (opcional): a página ANTERIOR terminou no meio de
 *  uma tabela larga de Férias-Prêmio/Retificação (ver
 *  `extrairTabelaLargaFeriasPremio`) sem nenhuma fronteira real — nem nova
 *  SRE, nem novo ato. Regressão real (Diário 02/10/2026, pág. 38→39): essa
 *  tabela atravessou a quebra de página sem repetir o cabeçalho "MUNICÍPIO
 *  ÓRGÃO DE LOTAÇÃO/EXERCÍCIO" (o jornal só o imprime uma vez, no topo), e
 *  a página seguinte só trazia mais linhas de servidor direto, depois do
 *  timbre "Documento assinado eletronicamente..." — um rodapé impresso em
 *  TODA página do Diário, não um fim de tabela/ato. Sem herdar o estado
 *  "dentro da tabela" de uma página para a outra, os 14 servidores da
 *  continuação desapareciam da Metropolitana A por completo. O retorno
 *  inclui `terminaTabelaLarga`, para a PRÓXIMA página (ver
 *  `extrairPaginasDiario`, que encadeia isso sequencialmente). */
export function aplicarOrdemGeometricaDiario(p, continuaTabelaLarga = false) {
    if (p.linhas?.length && p.larguraPagina && p.alturaPagina) {
        let terminaTabelaLarga = false;
        const texto = linhasParaTextoDiario(p.linhas, p.larguraPagina, p.alturaPagina, p.numero, {
            continuaTabelaLarga,
            aoTerminar: (v) => { terminaTabelaLarga = v; },
        });
        return { ...p, texto, terminaTabelaLarga };
    }
    return p;
}
/** Extrai texto de PDFs ou fotos de páginas do Diário reutilizando o mesmo
 *  pipeline nativo+OCR das laudas. Fotos são tratadas como página única. */
export async function extrairPaginasDiario(files, onProgress) {
    const resultado = await extrairTextoPDFs(files, onProgress);
    // Mantém uma camada integral para a busca tipo Ctrl+F ANTES de qualquer
    // corte/reordenação geométrica.
    const paginasComBusca = resultado.paginas.map((p) => ({
        ...p,
        textoBuscaDiario: p.linhas?.length ? linhasParaTexto(p.linhas) : p.texto,
    }));
    // Encadeado SEQUENCIALMENTE (não .map) porque cada página precisa saber
    // se a ANTERIOR terminou no meio de uma tabela larga — ver o comentário
    // de `aplicarOrdemGeometricaDiario`.
    const paginas = [];
    let continuaTabelaLarga = false;
    for (const p of paginasComBusca) {
        const pagina = aplicarOrdemGeometricaDiario(p, continuaTabelaLarga);
        paginas.push(pagina);
        continuaTabelaLarga = !!pagina.terminaTabelaLarga;
    }
    const alteradas = paginas.filter((p, i) => p.texto !== resultado.paginas[i]?.texto).length;
    const logs = [...resultado.logs];
    if (alteradas)
        logs.push({ nivel: "info", origem: "Diário/Layout", mensagem: `${alteradas} página(s) reorganizada(s) pela geometria nativa em ordem de leitura por colunas (esquerda → direita), inclusive páginas em que o OCR também foi executado.` });
    // Só há risco real de ordem por OCR quando NÃO existe geometria nativa
    // (por exemplo, foto avulsa). PDFs com camada nativa continuam usando x/y.
    for (const p of paginas) {
        if (!p.usouOcr || p.linhas?.length)
            continue;
        const b = baseText(p.texto);
        const qtdAtos = (b.match(/\bATO\s+N/g) || []).length;
        if (qtdAtos >= 2 || (b.includes("SRE METROPOLITANA A") && b.includes("MASP"))) {
            logs.push({
                nivel: "aviso", origem: "Diário/Layout", pagina: p.numero,
                mensagem: `[LEITURA PARCIAL] PÁG. ${p.numero}: imagem/OCR sem geometria nativa e com estrutura potencialmente multicolunar. Confira a ordem visual antes de emitir I.A.`,
            });
        }
    }
    return { paginas, logs };
}
export { TIPOS_ATO_DIARIO };
// ============================================================================
// LIMITAÇÕES CONHECIDAS DESTA VERSÃO (declaradas, não escondidas)
// ============================================================================
// - PDFs nativos do Diário passam agora pelo resolvedor geométrico de colunas
//   (x/y) antes da segmentação. Páginas que só permitem OCR continuam sem
//   geometria fina e, por isso, são marcadas para revisão quando o texto
//   apresenta sinais de mistura de colunas.
// - Não há leitura do SUMÁRIO da primeira página para achar os intervalos
//   de página oficiais — o escopo é determinado por cabeçalho encontrado em
//   ordem de leitura ao longo do documento, o que cobre os casos de
//   regressão testados, mas não substitui uma leitura de sumário real.
// - Ocorrências sem MaSP publicado não são capturadas nesta versão (o
//   ancoramento continua exigindo "MASP ..." explícito no bloco).
// - Papéis de pessoa (alvo_do_ato / substituído / membro_comissão / etc.)
//   não são classificados; a extração continua sendo por MaSP+nome dentro
//   do bloco, o que já reduz fortemente falsos positivos de assinatura e
//   autoridade (que normalmente não têm MaSP citado do mesmo jeito), mas
//   não é uma classificação de papel completa.
