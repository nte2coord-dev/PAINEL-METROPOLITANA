// ============================================================================
// ocrPipeline.ts — avaliação de qualidade do texto nativo + OCR com
// Tesseract.js (local, sem chave de API) com múltiplas tentativas.
// ============================================================================
import Tesseract from "tesseract.js";
import { semAcento } from "./normalizers.js";
const RE_MASP = /(?:MaSP|MASP|Masp)\s*:?\s*[0-9][0-9.\s]{3,14}-\d{1,2}/;
const RE_NOME_PROVAVEL = /\b[A-ZÀ-Ü]{2,}(?:\s+[A-ZÀ-Ü]{2,}){1,6}\b/;
const RE_CARGO_PROVAVEL = /\b(?:PEB|ATB|TDE|ANE|ANEI|EEB|ASB|AEB|FGD)[A-Z0-9/-]*\b/i;
/** Conta quantas palavras "grudadas" existem — heurística: token muito
 *  longo (>18 chars) sem espaço, todo alfabético, é provável concatenação
 *  de duas ou mais palavras por falha de extração de espaçamento. */
function contarPalavrasColadas(texto) {
    const tokens = texto.split(/\s+/);
    return tokens.filter((t) => /^[A-Za-zÀ-ÿ]{18,}$/.test(t)).length;
}
function percentualCaracteresEstranhos(texto) {
    if (!texto)
        return 1;
    const total = texto.length;
    const estranhos = (texto.match(/[^\wÀ-ÿ\s.,;:\-\/()º°"']/g) || []).length;
    return total > 0 ? estranhos / total : 1;
}
/** Verifica se a sequência de linhas está em ordem de leitura plausível
 *  (y decrescente de forma consistente, sem grandes saltos alternados
 *  que indiquem colunas misturadas). */
function linhasEmOrdem(linhas) {
    if (linhas.length < 3)
        return true;
    let inversoes = 0;
    for (let i = 1; i < linhas.length; i++) {
        if (linhas[i].y > linhas[i - 1].y + 5)
            inversoes++;
    }
    return inversoes < linhas.length * 0.15;
}
/** Avalia a qualidade da camada de texto nativo de uma página. Não decide
 *  sozinha se deve rodar OCR — devolve os sinais para `precisaDeOcr()`
 *  decidir com critérios explícitos (nunca só "mais de 100 caracteres"). */
export function avaliarQualidadeTexto(texto, linhas) {
    const motivos = [];
    const temMasp = RE_MASP.test(texto);
    const temNomeProvavel = RE_NOME_PROVAVEL.test(texto);
    const temCargoProvavel = RE_CARGO_PROVAVEL.test(texto);
    const pctEstranhos = percentualCaracteresEstranhos(texto);
    const coladas = contarPalavrasColadas(texto);
    const ordem = linhasEmOrdem(linhas);
    let pontuacao = 1.0;
    if (texto.trim().length < 40) {
        pontuacao -= 0.5;
        motivos.push("texto muito curto");
    }
    if (temMasp && !temNomeProvavel) {
        pontuacao -= 0.3;
        motivos.push("tem MaSP mas não tem nome reconhecível");
    }
    if (temMasp && !temCargoProvavel) {
        pontuacao -= 0.1;
        motivos.push("tem MaSP mas não tem cargo reconhecível");
    }
    if (pctEstranhos > 0.08) {
        pontuacao -= 0.25;
        motivos.push(`${(pctEstranhos * 100).toFixed(0)}% de caracteres estranhos`);
    }
    if (coladas > 2) {
        pontuacao -= 0.2;
        motivos.push(`${coladas} palavra(s) aparentemente grudada(s)`);
    }
    if (!ordem) {
        pontuacao -= 0.25;
        motivos.push("linhas fora de ordem de leitura");
    }
    if (!temMasp && !temNomeProvavel) {
        pontuacao -= 0.2;
        motivos.push("nenhum MaSP nem nome reconhecível no texto");
    }
    pontuacao = Math.max(0, Math.min(1, pontuacao));
    return {
        pontuacao,
        temMasp,
        temNomeProvavel,
        temCargoProvavel,
        percentualCaracteresEstranhos: pctEstranhos,
        palavrasColadas: coladas,
        linhasDesordenadas: !ordem,
        motivos,
    };
}
/** Decide se a página precisa de OCR — critérios explícitos, nunca só
 *  "mais de 100 caracteres". */
export function precisaDeOcr(qualidade) {
    if (qualidade.pontuacao < 0.55)
        return true;
    if (qualidade.temMasp && !qualidade.temNomeProvavel)
        return true;
    if (qualidade.linhasDesordenadas)
        return true;
    if (qualidade.percentualCaracteresEstranhos > 0.12)
        return true;
    return false;
}
// ── Pré-processamento de imagem para OCR ────────────────────────────────────
function clonarCanvas(origem) {
    const c = document.createElement("canvas");
    c.width = origem.width;
    c.height = origem.height;
    const ctx = c.getContext("2d");
    ctx?.drawImage(origem, 0, 0);
    return c;
}
function paraTonsDeCinzaEContraste(canvas) {
    const out = clonarCanvas(canvas);
    const ctx = out.getContext("2d");
    const img = ctx.getImageData(0, 0, out.width, out.height);
    const d = img.data;
    for (let i = 0; i < d.length; i += 4) {
        const lum = d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114;
        // Aumento leve de contraste em torno do ponto médio
        const v = Math.max(0, Math.min(255, (lum - 128) * 1.25 + 128));
        d[i] = d[i + 1] = d[i + 2] = v;
    }
    ctx.putImageData(img, 0, 0);
    return out;
}
function binarizar(canvas) {
    const out = clonarCanvas(canvas);
    const ctx = out.getContext("2d");
    const img = ctx.getImageData(0, 0, out.width, out.height);
    const d = img.data;
    let soma = 0, n = 0;
    for (let i = 0; i < d.length; i += 64) {
        soma += d[i];
        n++;
    }
    const media = n > 0 ? soma / n : 128;
    const limiar = Math.max(85, Math.min(160, media * 0.82));
    for (let i = 0; i < d.length; i += 4) {
        const v = d[i] < limiar ? 0 : 255;
        d[i] = d[i + 1] = d[i + 2] = v;
    }
    ctx.putImageData(img, 0, 0);
    return out;
}
async function reconhecer(canvas) {
    // O fluxo do painel é português; carregar inglês junto aumentava download/memória
    // e tempo de inicialização sem benefício consistente para as laudas.
    const resultado = await Tesseract.recognize(canvas, "por", { logger: () => { } });
    return { texto: resultado.data.text || "", confianca: resultado.data.confidence ?? 0 };
}
function possuiSinaisDocumentais(texto) {
    const b = semAcento(texto || "").toUpperCase();
    const sinais = ["MASP", "ATO", "SERVIDOR", "SERVIDORA", "SRE", "ADM", "PEB", "RETIFICA", "FERIAS", "VIGENCIA"];
    return sinais.filter((s) => b.includes(s)).length >= 2;
}
function primeiraLeituraBoa(texto, confianca) {
    const limpo = (texto || "").replace(/\s+/g, " ").trim();
    if (limpo.length < 50)
        return false;
    if (confianca >= 84)
        return true;
    return confianca >= 73 && possuiSinaisDocumentais(limpo);
}
/** OCR adaptativo com NO MÁXIMO duas passagens completas.
 *  1ª: imagem como veio, sem filtros caros.
 *  2ª: somente se necessário, tons de cinza + contraste + binarização. */
export async function ocrComMultiplasTentativas(canvasOriginal) {
    try {
        const fast = await reconhecer(canvasOriginal);
        if (primeiraLeituraBoa(fast.texto, fast.confianca)) {
            return { texto: fast.texto, confiancaMedia: fast.confianca, variante: "original", passagens: 1 };
        }
        const enhancedCanvas = binarizar(paraTonsDeCinzaEContraste(canvasOriginal));
        const enhanced = await reconhecer(enhancedCanvas);
        const scoreFast = fast.confianca + Math.min((fast.texto || "").length / 100, 10);
        const scoreEnhanced = enhanced.confianca + Math.min((enhanced.texto || "").length / 100, 10);
        if (scoreEnhanced >= scoreFast) {
            return { texto: enhanced.texto, confiancaMedia: enhanced.confianca, variante: "binarizado", passagens: 2 };
        }
        return { texto: fast.texto, confiancaMedia: fast.confianca, variante: "original", passagens: 2 };
    }
    catch {
        return { texto: "", confiancaMedia: 0, variante: "original", passagens: 0 };
    }
}
/** Limpeza pós-OCR de artefatos de reconhecimento MUITO comuns e
 *  inequívocos (não tenta "adivinhar" conteúdo, só normaliza grafia). */
export function limparTextoOcr(texto) {
    if (!texto)
        return "";
    return texto
        .split("\n")
        .map((linha) => {
        let l = linha.trim();
        if (l.replace(/[^a-zA-Z0-9à-úÀ-Ú]/g, "").length < 3 && !/^\d+$/.test(l))
            return "";
        l = l.replace(/Masp\s*([0-9])/gi, "Masp $1");
        l = l.replace(/MaSP\s*:?\s*/gi, "MaSP: ");
        l = l.replace(/CARG[OÓÒÔÕ]\s*/gi, "CARGO ");
        l = l.replace(/F[EÉE]RIAS\s*[-–—]?\s*PR[EÊE]MIO/gi, "FÉRIAS-PRÊMIO");
        l = l.replace(/RETIFI[CÇ]A[CÇ][AÃ]O/gi, "RETIFICAÇÃO");
        l = l.replace(/ANULA[CÇ][AÃ]O/gi, "ANULAÇÃO");
        return l;
    })
        .filter(Boolean)
        .join("\n");
}
export { semAcento };
