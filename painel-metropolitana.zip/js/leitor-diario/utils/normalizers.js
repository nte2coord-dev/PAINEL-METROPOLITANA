// ============================================================================
// normalizers.ts — normalização de texto/valores. Funções puras, sem I/O.
// ============================================================================
export function semAcento(txt) {
    return (txt || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}
export function normalizarLinha(txt) {
    return (txt || "").replace(/\s+/g, " ").trim();
}
/** Normaliza um MaSP para o padrão "0000000-0" usado na lauda oficial
 *  (corpo numérico + hífen + dígito verificador, SEM separador de milhar).
 *  Os documentos de origem às vezes trazem o MaSP pontuado ("1.002.272-1"),
 *  mas a lauda-modelo consolidada usa sempre o formato plano ("1002272-1")
 *  — nunca inventa/arredonda dígitos, apenas remove a pontuação de entrada
 *  e preserva os zeros à esquerda que já estavam presentes no corpo. */
export function normalizarMasp(raw) {
    if (!raw)
        return "";
    const digitos = raw.replace(/\D/g, "");
    if (digitos.length < 5)
        return raw.trim(); // curto demais para ser MaSP real
    const corpo = digitos.slice(0, -1);
    const dv = digitos.slice(-1);
    return `${corpo}-${dv}`;
}
export function somenteDigitosMasp(masp) {
    return (masp || "").replace(/\D/g, "");
}
export function normalizarBusca(txt) {
    return semAcento(txt || "").toLowerCase();
}
export function somenteDigitos(txt) {
    return (txt || "").replace(/\D/g, "");
}
export function slug(txt) {
    return (semAcento(txt || "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "_")
        .replace(/^_+|_+$/g, "") || "item");
}
/** Normaliza um nome de servidor: remove ruído comum de rótulos de
 *  formulário colados ("(nome do servidor)"), pontuação nas pontas,
 *  espaços duplicados. NÃO valida se é um nome plausível — isso é
 *  responsabilidade de fieldValidators.ts. */
export function normalizarNome(raw) {
    if (!raw)
        return "";
    let n = normalizarLinha(raw);
    n = n.replace(/\s+\((?:MaSP|nome|cargo|município|órgão|id\.?).*/i, "");
    n = n.replace(/[,;:]+$/g, "");
    n = n.replace(/\s{2,}/g, " ").trim();
    n = n.replace(/^[^\wÀ-Ú]+|[^\wÀ-Ú]+$/gi, "");
    return n.toUpperCase();
}
/** Normaliza admissão para sempre ter 2 dígitos ("1" → "01"). Não inventa
 *  valor: se `raw` estiver vazio, devolve vazio. */
export function normalizarAdmissao(raw) {
    if (!raw)
        return "";
    const n = parseInt(raw.replace(/\D/g, ""), 10);
    if (Number.isNaN(n))
        return "";
    return String(n).padStart(2, "0");
}
/** Corrige erros de OCR/digitação INEQUÍVOCOS em texto de retificação —
 *  nunca reinterpreta o SENTIDO do texto, só conserta grafias quebradas
 *  conhecidas. Qualquer correção mais ambígua fica marcada como
 *  "correcao" na origem do campo, nunca aplicada silenciosamente sem log. */
export function corrigirTextoRetificacao(str) {
    if (!str)
        return { texto: "", corrigido: false };
    let out = str.replace(/^[_\s.\-]+/g, "").trim();
    const original = out;
    // "42 quing." / "42quinq" → "4º quinq." — dígito+"2" seguido de "quinq"
    // OU da variante de OCR "quing" (perda de uma letra de "quinquênio") é
    // erro clássico onde o "2" mimetiza o símbolo de grau.
    out = out.replace(/\b(\d)2\s*[º°o]?\s*qui?n[qg]/gi, "$1º quinq");
    out = out.replace(/\b(\d)2\s*[º°o]?\s*qui?n[qg]u[eê]nio/gi, "$1º quinquênio");
    // "ref. ac" / "ref. a0" → "ref. ao"
    out = out.replace(/\bref\.\s*a[c0]\b/gi, "ref. ao");
    out = out.replace(/\bac\s+(\d[º°o]?)\b/gi, "ao $1");
    // "a artir de" / "a p artir de" → "a partir de"
    out = out.replace(/\ba\s+a?rtir\s+de\b/gi, "a partir de");
    out = out.replace(/\ba\s+p\s+artir\s+de\b/gi, "a partir de");
    // "or 02 meses" no INÍCIO da frase (perda do "p" de "por") → "por 02 meses"
    // Só corrige quando é claramente o início da cláusula (não altera "por"
    // já correto nem palavras que legitimamente terminam em "or").
    out = out.replace(/^or\s+(\d{1,2}\s+mes)/i, "por $1");
    out = out.replace(/([;.]\s*)or\s+(\d{1,2}\s+mes)/gi, "$1por $2");
    return { texto: out, corrigido: out !== original };
}
