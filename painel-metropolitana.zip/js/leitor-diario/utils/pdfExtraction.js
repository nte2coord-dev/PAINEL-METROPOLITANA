// ============================================================================
// pdfExtraction.ts — extração de texto NATIVO do PDF preservando posição.
// Não decide nada sobre qualidade/OCR — isso é responsabilidade de
// ocrPipeline.ts (avaliarQualidadeTexto).
// ============================================================================
import * as pdfjsLib from "pdfjs-dist";
if (typeof window !== "undefined" && "GlobalWorkerOptions" in pdfjsLib) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;
}
/** Reconstrói linhas a partir dos itens de texto do pdf.js usando proximidade
 *  vertical (não apenas contagem de caracteres) e junta itens da mesma linha
 *  respeitando o espaçamento horizontal real entre eles. */
export function reconstruirLinhas(textContent, origemX = 0, origemY = 0) {
    const itens = [];
    for (const item of textContent.items) {
        if (!("str" in item) || typeof item.str !== "string")
            continue;
        if (!item.str.trim())
            continue;
        const tx = item.transform;
        itens.push({
            str: item.str,
            x: tx[4] - origemX,
            y: tx[5] - origemY,
            altura: item.height || Math.abs(tx[3]) || 10,
            largura: item.width || item.str.length * (Math.abs(tx[0]) || 5),
        });
    }
    if (itens.length === 0)
        return [];
    itens.sort((a, b) => b.y - a.y);
    const linhas = [];
    let atual = [];
    let yAtual = itens[0].y;
    for (const item of itens) {
        // Tolerância proporcional à altura da fonte (linhas de fontes maiores
        // têm mais variação de y entre itens da MESMA linha).
        const tolerancia = Math.max(3, item.altura * 0.4);
        if (Math.abs(item.y - yAtual) > tolerancia) {
            if (atual.length > 0)
                linhas.push(atual);
            atual = [item];
            yAtual = item.y;
        }
        else {
            atual.push(item);
        }
    }
    if (atual.length > 0)
        linhas.push(atual);
    return linhas.map((itensLinha) => {
        itensLinha.sort((a, b) => a.x - b.x);
        let texto = "";
        for (let i = 0; i < itensLinha.length; i++) {
            const item = itensLinha[i];
            if (i > 0) {
                const prev = itensLinha[i - 1];
                const gap = item.x - (prev.x + prev.largura);
                // Espaço real entre colunas/palavras — usa a largura medida do
                // item anterior, não uma estimativa por quantidade de caracteres.
                if (gap > Math.max(2, prev.altura * 0.25))
                    texto += " ";
            }
            texto += item.str;
        }
        return { y: itensLinha[0].y, itens: itensLinha, texto: texto.trim() };
    }).filter((l) => l.texto.length > 0);
}
export function linhasParaTexto(linhas) {
    return linhas.map((l) => l.texto).join("\n");
}
export async function renderizarPaginaParaCanvas(page, escala = 3.2) {
    const viewport = page.getViewport({ scale: escala });
    const canvas = document.createElement("canvas");
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const ctx = canvas.getContext("2d");
    if (ctx) {
        await page.render({ canvasContext: ctx, viewport }).promise;
    }
    return canvas;
}
export async function extrairPaginasNativas(file, onProgress) {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    const paginas = [];
    for (let n = 1; n <= pdf.numPages; n++) {
        if (onProgress)
            onProgress(n / pdf.numPages, `Lendo página ${n}/${pdf.numPages}`);
        const page = await pdf.getPage(n);
        const textContent = await page.getTextContent();
        const [origemX = 0, origemY = 0] = Array.isArray(page.view) ? page.view : [0, 0];
        const linhas = reconstruirLinhas(textContent, Number(origemX) || 0, Number(origemY) || 0);
        paginas.push({ pagina: page, linhas, texto: linhasParaTexto(linhas) });
    }
    return { paginas };
}
const RE_SRE_TERMINAL_DIARIO = /^\s*(?:SRE\s+(?:DE\s+)?METROPOLITANA|METROPOLITANA)\s*([B-Z])\b/i;
const RE_CABECALHO_ATO_DIARIO = /^(?:ANULA[ÇC][ÃA]O|RETIFICA[ÇC][ÃA]O|LICEN[ÇC]A(?:-|\s)|AFASTAMENTO(?:\s|$)|ABONO\s+DE\s+PERMAN[ÊE]NCIA|F[ÉE]RIAS[\s–—/-]*PR[ÊE]MIO|REDU[ÇC][ÃA]O\s+DE\s+CARGA|AMPLIA[ÇC][ÃA]O\s+DE\s+CARGA|ALTERA[ÇC][ÃA]O\s+DE\s+NOME|ACR[ÉE]SCIMO\s+DE\s+TITULA[ÇC][ÃA]O)/i;
function fragmentarLinhaDiario(linha, larguraPagina) {
    if (!linha.itens.length)
        return [];
    const itens = [...linha.itens].sort((a, b) => a.x - b.x);
    // No jornal de 4 colunas o vão entre colunas é pequeno (~10–15 pt),
    // enquanto o espaço normal entre palavras/trechos do mesmo parágrafo é
    // bem menor. O limiar é proporcional à página e tem piso em 8 pt.
    const limiar = Math.max(8, larguraPagina * 0.011);
    const grupos = [];
    let atual = [itens[0]];
    for (let i = 1; i < itens.length; i++) {
        const ant = itens[i - 1];
        const item = itens[i];
        const gap = item.x - (ant.x + ant.largura);
        const saltoX = item.x - ant.x;
        // Alguns PDFs (e também reconstruções sintéticas) trazem a largura do
        // item anterior superestimada, fazendo dois itens de colunas distintas
        // parecerem sobrepostos. Quando os x iniciais dão um salto compatível
        // com coluna e as caixas se sobrepõem, usamos o x inicial como segunda
        // evidência de fronteira de coluna.
        const sobreposicaoComSaltoDeColuna = gap <= 0 && saltoX > larguraPagina * 0.18;
        // Títulos de atos são longos e podem quase encostar no título da coluna
        // seguinte. O vão físico então fica menor que o limiar, apesar de os x
        // iniciais saltarem exatamente uma coluna. Se o NOVO item já é outro
        // cabeçalho de ato, o salto horizontal é evidência estrutural suficiente.
        const novoCabecalhoEmOutraColuna = RE_CABECALHO_ATO_DIARIO.test(item.str.trim()) &&
            saltoX > larguraPagina * 0.18;
        if (gap > limiar || sobreposicaoComSaltoDeColuna || novoCabecalhoEmOutraColuna) {
            grupos.push(atual);
            atual = [item];
        }
        else {
            atual.push(item);
        }
    }
    grupos.push(atual);
    return grupos.map((g) => {
        let texto = '';
        for (let i = 0; i < g.length; i++) {
            if (i) {
                const ant = g[i - 1];
                const gap = g[i].x - (ant.x + ant.largura);
                if (gap > Math.max(1.5, ant.altura * 0.18))
                    texto += ' ';
            }
            texto += g[i].str;
        }
        const x0 = Math.min(...g.map((x) => x.x));
        const x1 = Math.max(...g.map((x) => x.x + x.largura));
        return { y: linha.y, x0, x1, texto: texto.replace(/\s+/g, ' ').trim() };
    }).filter((f) => f.texto);
}
function clusterizarXs(xs, tolerancia) {
    const ordenados = [...xs].sort((a, b) => a - b);
    const grupos = [];
    for (const x of ordenados) {
        const ultimo = grupos[grupos.length - 1];
        if (!ultimo || Math.abs(x - ultimo.reduce((a, b) => a + b, 0) / ultimo.length) > tolerancia) {
            grupos.push([x]);
        }
        else
            ultimo.push(x);
    }
    return grupos.map((g) => ({ x: g.reduce((a, b) => a + b, 0) / g.length, contagem: g.length }));
}
/** Quando há mais clusters detectados do que as 4 colunas físicas
 *  esperadas, algum é espúrio — um título levemente deslocado, uma citação
 *  de artigo que bateu por engano no gatilho de cabeçalho de ato — e por
 *  isso tem MUITO menos ocorrências que as colunas de verdade. Regressão
 *  real (Diário 17/07/2026, pág. 36): um cabeçalho deslocado em x≈122
 *  formava um 5º cluster com uma única ocorrência. Escolher sempre os 4
 *  primeiros clusters pela posição X (esquerda→direita) descartava a
 *  ÚLTIMA coluna física de verdade (a mais à direita) sempre que esse
 *  cluster espúrio aparecia ENTRE duas colunas reais — e a coluna
 *  descartada acabava fundida no bucket da coluna vizinha, misturando o
 *  texto de duas colunas físicas diferentes (foi assim que a servidora
 *  Carla Moreira dos Santos, de um ato de outra coluna sem nenhuma relação
 *  com a Metropolitana A, apareceu colada ao ato da Regina Barbosa
 *  Pereira). Escolher pelas MAIS ocorrências, e só depois reordenar por X,
 *  garante que as colunas de verdade sempre vençam um cluster espúrio,
 *  não importa onde ele caia na página. */
function escolherMelhoresColunas(clusters, maximo) {
    return [...clusters]
        .sort((a, b) => b.contagem - a.contagem)
        .slice(0, maximo)
        .map((c) => c.x)
        .sort((a, b) => a - b);
}
/**
 * Separa os itens da própria linha diretamente pelas faixas geométricas das
 * colunas. Isso é mais robusto que tentar dividir uma linha longa apenas pelo
 * "gap" entre palavras: no Diário, textos de colunas vizinhas podem se
 * sobrepor horizontalmente e parecer um único parágrafo para o PDF.js.
 */
function indiceColunaPorX(x, xs) {
    if (xs.length <= 1)
        return 0;
    // REGRA IMPORTANTE DO DIÁRIO: `xs` representa o INÍCIO de cada coluna,
    // não o centro dela. Usar o ponto médio entre dois inícios dividia a
    // própria coluna ao meio (um item em x=100 da coluna 1 era enviado à
    // coluna 2). Isso quebrava a continuidade de atos e fazia servidores
    // desaparecerem. A coluna correta é a última cujo início já foi alcançado.
    const espacamentos = xs.slice(1).map((v, i) => v - xs[i]).filter((v) => v > 0);
    const passo = espacamentos.length ? espacamentos.sort((a, b) => a - b)[Math.floor(espacamentos.length / 2)] : 0;
    const tolerancia = Math.max(3, passo * 0.045);
    let idx = 0;
    for (let i = 1; i < xs.length; i++) {
        if (x >= xs[i] - tolerancia)
            idx = i;
        else
            break;
    }
    return idx;
}
/** Junta os itens de UMA linha, em ordem de X, num único texto — mesma regra
 *  de espaçamento usada nos grupos por coluna (só insere espaço quando o vão
 *  físico entre itens é maior que o normal entre letras/palavras). */
function textoDaLinhaCompleta(itensOrdenados) {
    let texto = '';
    for (let i = 0; i < itensOrdenados.length; i++) {
        if (i) {
            const ant = itensOrdenados[i - 1];
            const gap = itensOrdenados[i].x - (ant.x + ant.largura);
            if (gap > Math.max(1.5, ant.altura * 0.18))
                texto += ' ';
        }
        texto += itensOrdenados[i].str;
    }
    return texto.replace(/\s+/g, ' ').trim();
}
// Um cabeçalho de SRE ("SRE Metropolitana A", "SRE de Pouso Alegre"...) às
// vezes é impresso CENTRALIZADO como divisor de seção, numa posição X que
// não alinha com NENHUMA coluna física real — diferente do corpo que ele
// introduz, sempre colado à margem esquerda da própria coluna. Regressão
// real (Diário 02/10/2026, pág. 38): "SRE Metropolitana A" centralizado em
// x≈371 (entre as colunas física 2, em x≈244, e 3, em x≈428) caía na
// coluna 2 pela própria posição X, enquanto a tabela de Férias-Prêmio que
// ele abre começa na coluna 1 (x≈60) uma linha abaixo. Como a leitura
// processa uma coluna inteira antes da próxima, o cabeçalho saía DEPOIS
// de toda a tabela que ele deveria abrir — a tabela inteira (5
// servidores) ficava fora do escopo da Metropolitana A, só recuperável
// pela segunda passagem Ctrl+F (que não sabe continuar entre páginas).
const RE_CABECALHO_SRE_LINHA_SOLTA = /^[ \t]*-?\s*SRE\s+(?:DE\s+)?[^\n:]{2,70}\s*$/i;
function fragmentarLinhasPorColunas(linhas, colunasX, linhasDeTabelaLarga) {
    if (!colunasX.length)
        return [];
    const xs = [...colunasX].sort((a, b) => a - b);
    const saida = [];
    for (let li = 0; li < linhas.length; li++) {
        const linha = linhas[li];
        const itensOrdenados = [...linha.itens].sort((a, b) => a.x - b.x);
        // Uma linha de tabela larga (ver `marcarLinhasDeTabelaLarga`) NUNCA pode
        // ser fragmentada por coluna: ela já é, sozinha, um servidor inteiro —
        // município, escola, MaSP, nome, cargo, admissão e data, todos na MESMA
        // linha física, atravessando de propósito as 4 faixas da grade
        // editorial. Fragmentá-la por coluna é exatamente o que embaralhava um
        // servidor com outro (Diário 05/09/2026, pág. 38).
        if (linhasDeTabelaLarga?.has(linha)) {
            const texto = textoDaLinhaCompleta(itensOrdenados);
            if (texto) {
                saida.push({
                    y: linha.y,
                    x0: Math.min(...itensOrdenados.map((it) => it.x)),
                    x1: Math.max(...itensOrdenados.map((it) => it.x + it.largura)),
                    texto,
                });
            }
            continue;
        }
        // Cabeçalho de SRE "solto" (linha com um único item, texto inteiro
        // igual a "SRE ..."): usa a coluna da PRÓXIMA linha física (seu
        // próprio conteúdo), não a posição X dele mesmo — ver
        // `RE_CABECALHO_SRE_LINHA_SOLTA` acima. `itensOrdenados.length === 1`
        // é deliberadamente restritivo: nunca se aplica a uma linha onde "SRE
        // ..." está colado a outro conteúdo (aí a posição X dele é informação
        // real, não um acidente de centralização).
        let xForcado = null;
        if (itensOrdenados.length === 1 && RE_CABECALHO_SRE_LINHA_SOLTA.test(linha.texto)) {
            const proxima = linhas[li + 1];
            if (proxima?.itens.length) {
                xForcado = Math.min(...proxima.itens.map((it) => it.x));
            }
        }
        const idxForcado = xForcado != null ? indiceColunaPorX(xForcado, xs) : null;
        const grupos = xs.map(() => []);
        for (const item of itensOrdenados) {
            const idx = idxForcado ?? indiceColunaPorX(item.x, xs);
            grupos[idx].push(item);
        }
        for (let gi = 0; gi < grupos.length; gi++) {
            const g = grupos[gi];
            if (!g.length)
                continue;
            // `textoColunar` decide a coluna de CADA fragmento de novo, a partir
            // do próprio x0 (ver `indiceColunaPorX(f.x0, xs)` ali) — sem também
            // substituir x0/x1 aqui, o agrupamento forçado acima não tinha
            // nenhum efeito: o fragmento carregava a posição X NATIVA do item
            // (a mesma posição "errada" que motivou forçar a coluna) e
            // `textoColunar` a recolocava exatamente na coluna de origem.
            const usaXForcado = idxForcado === gi && xForcado != null;
            saida.push({
                y: linha.y,
                x0: usaXForcado ? xForcado : Math.min(...g.map((x) => x.x)),
                x1: usaXForcado ? xForcado : Math.max(...g.map((x) => x.x + x.largura)),
                texto: textoDaLinhaCompleta(g),
            });
        }
    }
    return saida.filter((f) => f.texto);
}
function linhaEhCabecalhoPagina(linha, paginaNumero) {
    if (!paginaNumero)
        return false;
    const txt = linha.texto.replace(/\s+/g, ' ').trim();
    const n = String(paginaNumero).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`^${n}\\s*[–—-]\\s*.*(?:FEIRA|DI[ÁA]RIO\\s+DO\\s+EXECUTIVO|MINAS\\s+GERAIS)`, 'i').test(txt);
}
function textoColunar(fragmentos, colunasX) {
    const colunas = colunasX.map(() => []);
    const xs = [...colunasX].sort((a, b) => a - b);
    for (const f of fragmentos) {
        // Mesmo critério da fragmentação: x0 pertence à última coluna cujo
        // início já foi alcançado. Nunca classificar pelo início "mais perto".
        const melhor = indiceColunaPorX(f.x0, xs);
        colunas[melhor].push(f);
    }
    // Apenas ordem física: coluna esquerda -> direita, e dentro de cada coluna
    // de cima -> baixo. NENHUMA SRE é filtrada nesta camada.
    const partes = [];
    for (const col of colunas) {
        col.sort((a, b) => (b.y - a.y) || (a.x0 - b.x0));
        for (const f of col)
            partes.push(f.texto);
    }
    return partes.join('\n');
}
// Regressão real (Diário 05/09/2026, pág. 38): além da tabela de Lotação
// (tratada acima), o Diário também imprime atos de Férias-Prêmio e
// Retificação em formato de TABELA LARGA — uma linha física por servidor,
// com município/escola/MaSP/servidor/cargo/admissão/período/quinquênio/data
// espalhados ao longo de TODA a largura da página, atravessando as 4 faixas
// da grade editorial normal. Cada linha bruta (antes de qualquer
// fragmentação) já vem com a linha inteira, na ordem certa — é a
// fragmentação por coluna, pensada para textos narrativos lado a lado, que
// destrói essa tabela: cada uma das 4 faixas vira um "bloco" próprio,
// impresso em sequência (todas as células de MUNICÍPIO/ESCOLA de TODAS as
// linhas, depois todas as de MaSP/SERVIDOR, depois CARGO/ADMISSÃO, depois
// A PARTIR DE/DATA), embaralhando servidor com servidor errado — impossível
// de recompor depois. O cabeçalho desse tipo de tabela sempre traz
// "MUNICÍPIO ÓRGÃO DE LOTAÇÃO/EXERCÍCIO" na mesma linha física.
const RE_TABELA_LARGA_CABECALHO = /MUNIC[ÍI]PIO\s+[ÓO]RG[ÃA]O\s+DE\s+LOTA[ÇC][ÃA]O\s*\/\s*EXERC[ÍI]CIO/i;
/** Um novo título de ato ou uma nova fronteira de SRE sempre encerra a
 *  tabela larga em andamento — ela nunca continua depois disso, mesmo sem
 *  quebra de página. */
function encerraTabelaLarga(textoLinha) {
    const t = textoLinha.trim();
    if (!t)
        return false;
    return RE_CABECALHO_ATO_DIARIO.test(t) || /^-?\s*SRE\b/i.test(t) || /^METROPOLITANA\s+[A-Z]\b/i.test(t);
}
/** Marca, sem reordenar ou agrupar nada, quais linhas (já em ordem física,
 *  de cima para baixo) pertencem a uma tabela larga em andamento — do
 *  próprio cabeçalho até a próxima âncora que a encerra. Devolver apenas um
 *  Set (em vez de recortar/segmentar a lista de linhas) é deliberado: a
 *  ORDEM de leitura entre colunas continua sendo decidida, como sempre,
 *  pelo `textoColunar` — que já sabe intercalar corretamente o conteúdo de
 *  uma mesma coluna ao longo da página. Uma primeira versão desta correção
 *  tentou recortar a página em trechos "tabela"/"narrativa" e processar
 *  cada um isoladamente; isso quebrava a ordem de leitura sempre que uma
 *  tabela e um parágrafo de OUTRA coluna caíam no mesmo intervalo de Y,
 *  fazendo um ato "herdar" a tabela de um vizinho (Diário 05/09/2026,
 *  pág. 38: a tabela do Ato Nº 78/2026 saía atribuída ao Ato Nº 27/2026). */
/** `comecaDentro`: true quando a página ANTERIOR terminou no meio de uma
 *  tabela larga sem nenhuma fronteira real (ver `paginaTerminaDentroDeTabelaLarga`
 *  e `aplicarOrdemGeometricaDiario`) — a marcação então começa já "dentro",
 *  mesmo que o cabeçalho "MUNICÍPIO ÓRGÃO DE LOTAÇÃO/EXERCÍCIO" não se
 *  repita nesta página (o jornal normalmente só o imprime uma vez, no topo
 *  da tabela). */
function marcarLinhasDeTabelaLarga(linhasOrdenadas, comecaDentro = false) {
    const marcadas = new Set();
    let dentro = comecaDentro;
    for (const l of linhasOrdenadas) {
        const t = l.texto;
        if (RE_TABELA_LARGA_CABECALHO.test(t)) {
            dentro = true;
            marcadas.add(l);
            continue;
        }
        if (dentro) {
            if (encerraTabelaLarga(t)) {
                dentro = false;
            }
            else {
                marcadas.add(l);
            }
        }
    }
    return marcadas;
}
/** Varre a página em ordem física simples (Y decrescente) só para saber se
 *  ela termina "dentro" de uma tabela larga aberta — independe de qual
 *  caminho de reconstrução por coluna acaba sendo usado para montar o texto
 *  final (`linhasParaTextoDiario` tem vários). Serve só para encadear o
 *  estado "dentro da tabela" de uma página para a próxima; ver
 *  `aplicarOrdemGeometricaDiario` em diarioParser.ts.
 *
 *  Regressão real (Diário 02/10/2026, pág. 38→39): uma tabela larga de
 *  Férias-Prêmio/Concessão atravessou a quebra de página sem repetir nem o
 *  título do ato nem o cabeçalho de colunas — a página seguinte só trazia
 *  mais linhas de servidor direto, depois do timbre "Documento assinado
 *  eletronicamente..." (rodapé de TODA página do Diário, não um fim de
 *  tabela/ato). Sem esse encadeamento, essas linhas entravam na
 *  reconstrução comum por coluna (pensada para texto narrativo em 4
 *  faixas) e eram embaralhadas com servidor errado, ou a função de
 *  extração nem tentava ler a página por faltar o cabeçalho — os 14
 *  servidores da continuação desapareciam da Metropolitana A por completo. */
function paginaTerminaDentroDeTabelaLarga(linhas, comecaDentro) {
    let dentro = comecaDentro;
    for (const l of [...linhas].sort((a, b) => b.y - a.y)) {
        const t = l.texto;
        if (!dentro) {
            if (RE_TABELA_LARGA_CABECALHO.test(t))
                dentro = true;
            continue;
        }
        if (encerraTabelaLarga(t))
            dentro = false;
    }
    return dentro;
}
/** Reconstrói o texto do Diário em ordem HUMANA: coluna da esquerda de cima
 * para baixo, depois a coluna seguinte. Páginas híbridas (ex.: tabela de
 * Lotação ocupando a parte superior e quatro colunas narrativas abaixo)
 * preservam a tabela em ordem de linhas e só aplicam a leitura colunar na
 * região narrativa. Isso evita que quatro atos na mesma altura sejam
 * concatenados horizontalmente e contaminem servidor/cargo/data entre si. */
export function linhasParaTextoDiario(linhas, larguraPagina, alturaPagina, paginaNumero, opcoes) {
    const continuaTabelaLarga = !!opcoes?.continuaTabelaLarga;
    if (!linhas.length || !larguraPagina) {
        opcoes?.aoTerminar?.(paginaTerminaDentroDeTabelaLarga(linhas, continuaTabelaLarga));
        return linhasParaTexto(linhas);
    }
    // A reconstrução geométrica não decide mais o escopo da SRE.
    // Ela apenas preserva a ordem física do jornal; o filtro Metropolitana A
    // é aplicado depois, pelo parser estrutural, de forma igual para qualquer edição.
    // A linha impressa "36 – sexta-feira, ..." é uma âncora editorial real.
    // Quando o número da página é conhecido, qualquer resíduo geométrico acima
    // desse cabeçalho não pertence ao corpo operacional daquela página.
    let linhasPagina = linhas;
    if (paginaNumero) {
        const cabecalhoImpresso = linhas.find((l) => linhaEhCabecalhoPagina(l, paginaNumero));
        if (cabecalhoImpresso) {
            const yTopo = cabecalhoImpresso.y;
            linhasPagina = linhas.filter((l) => l === cabecalhoImpresso || l.y < yTopo + 0.5);
        }
    }
    // Calculado uma única vez, independente de qual caminho de reconstrução
    // por coluna é tomado logo abaixo (ambos levam ao mesmo conjunto de
    // linhas físicas desta página) — ver `paginaTerminaDentroDeTabelaLarga`.
    opcoes?.aoTerminar?.(paginaTerminaDentroDeTabelaLarga(linhasPagina, continuaTabelaLarga));
    const fragmentosIniciais = linhasPagina.flatMap((l) => fragmentarLinhaDiario(l, larguraPagina));
    const linhaTexto = linhasPagina.map((l) => l.texto).join('\n');
    const temTabelaLotacao = /SRE\s+METROPOLITANA\s*A[\s\S]{0,500}LOTA[ÇC][ÃA]O\s+ATO/i.test(linhaTexto);
    const headers = fragmentosIniciais.filter((f) => RE_CABECALHO_ATO_DIARIO.test(f.texto));
    const clustersDetectados = clusterizarXs(headers.map((h) => h.x0), Math.max(24, larguraPagina * 0.055));
    // O Diário do Executivo usa grade editorial de quatro colunas nas regiões
    // narrativas. Depender apenas do x do TÍTULO do ato fazia uma coluna sumir
    // quando o PDF fundia títulos vizinhos ou quando a coluna começava por uma
    // continuação de ato. Nesses casos a ordem virava row-major e o cabeçalho
    // "SRE Metropolitana B" aparecia DEPOIS de servidores da B, contaminando A.
    // Quando há evidência de página multicolunar, usamos as quatro faixas físicas
    // estáveis da página; a parte tabular superior continua preservada row-major.
    const parecePaginaJornal = larguraPagina > 500 && alturaPagina > 700;
    const sinaisColuna = headers.length >= 2 || /SRE\s+METROPOLITANA\s+[A-Z]/i.test(linhaTexto);
    const clusters = (parecePaginaJornal && sinaisColuna)
        ? (clustersDetectados.length >= 3
            // Prefere os inícios medidos na própria página. No Diário real de
            // 17/07/2026 eles ficam em ~59, 244, 428 e 612 pt. Forçar uma grade
            // teórica deslocava as colunas 3/4 e misturava atos. Escolhe pelas
            // MAIS ocorrências (não pelas 4 primeiras por posição X) para nunca
            // deixar um cluster espúrio empurrar a última coluna física de
            // verdade pra fora — ver `escolherMelhoresColunas`.
            ? escolherMelhoresColunas(clustersDetectados, 4)
            // Fallback da grade editorial real observada no Diário do Executivo.
            : [0.07, 0.29, 0.51, 0.73].map((f) => larguraPagina * f))
        : clustersDetectados.map((c) => c.x);
    // Sem evidência de múltiplas colunas, a reconstrução comum é mais segura.
    if (clusters.length < 2)
        return linhasParaTexto(linhasPagina);
    if (temTabelaLotacao && alturaPagina > 0) {
        // Região superior = tabela row-major; região inferior = atos column-major.
        const candidatosBaixos = headers.filter((h) => h.y < alturaPagina * 0.52);
        if (candidatosBaixos.length) {
            const fronteira = Math.max(...candidatosBaixos.map((h) => h.y));
            const tol = 4;
            const topo = linhasPagina
                .filter((l) => l.y > fronteira + tol)
                .sort((a, b) => b.y - a.y)
                .map((l) => l.texto)
                .filter(Boolean)
                .join('\n');
            const linhasBaixo = linhasPagina.filter((l) => l.y <= fronteira + tol);
            const linhasDeTabelaBaixo = marcarLinhasDeTabelaLarga([...linhasBaixo].sort((a, b) => b.y - a.y));
            const baixo = fragmentarLinhasPorColunas(linhasBaixo, clusters, linhasDeTabelaBaixo);
            return [topo, textoColunar(baixo, clusters)].filter(Boolean).join('\n');
        }
    }
    // Cabeçalho editorial ocupa a largura toda e deve permanecer antes do corpo,
    // impresso sem fragmentação por coluna (faz sentido: é uma linha só, a
    // largura da página inteira). Regressão real (Diário 17/07/2026, pág. 36):
    // esse limiar por Y pegava também a primeira linha de títulos do corpo —
    // ela ficava fisicamente acima de 93% da altura medida da página — mas
    // essa linha tinha um título de ato POR COLUNA (4 colunas físicas
    // diferentes), não um cabeçalho de largura inteira. Como o cabeçalho é
    // impresso via `l.texto` (a linha bruta, sem separação por coluna), os 4
    // títulos saíam colados um no outro na mesma linha — foi assim que
    // "ANULAÇÃO - ATO Nº 32/2026" (de uma coluna sem nenhuma relação com a
    // Metropolitana A) grudou em "ABONO DE PERMANÊNCIA - ATO Nº 46/2026" e
    // contaminou o ato da Regina Barbosa Pereira com a Carla Moreira dos
    // Santos, de um ato completamente diferente. Uma linha com itens em MAIS
    // DE UMA das colunas físicas detectadas nunca é o cabeçalho editorial —
    // é corpo multicolunar disfarçado de estar perto do topo da página — e
    // precisa passar pela fragmentação por coluna como qualquer outra linha.
    const limiarCabecalho = alturaPagina ? alturaPagina * 0.93 : Infinity;
    const xsClusters = [...clusters].sort((a, b) => a - b);
    const linhaTemMaisDeUmaColuna = (l) => {
        if (xsClusters.length < 2)
            return false;
        const indices = new Set(l.itens.map((it) => indiceColunaPorX(it.x, xsClusters)));
        return indices.size > 1;
    };
    const ehCatchAllTopo = (l) => l.y >= limiarCabecalho && !linhaTemMaisDeUmaColuna(l);
    const cabecalho = linhasPagina
        .filter((l) => ehCatchAllTopo(l) || linhaEhCabecalhoPagina(l, paginaNumero))
        .sort((a, b) => b.y - a.y)
        .map((l) => l.texto)
        .filter(Boolean)
        .join('\n');
    const corpoLinhas = linhasPagina.filter((l) => (!alturaPagina || !ehCatchAllTopo(l)) && !linhaEhCabecalhoPagina(l, paginaNumero));
    // Marca as linhas de eventuais tabelas largas (ver `marcarLinhasDeTabelaLarga`)
    // ANTES de fragmentar — a ordem de leitura entre colunas continua sendo
    // decidida inteiramente pelo `textoColunar`, como em qualquer página; a
    // única mudança é que essas linhas específicas nunca são cortadas ao meio.
    // `continuaTabelaLarga` (ver topo da função): a página anterior terminou
    // no meio da mesma tabela, então a proteção vale desde a primeira linha
    // do corpo mesmo sem o cabeçalho se repetir aqui — `comecaDentro` abaixo.
    const linhasDeTabela = (RE_TABELA_LARGA_CABECALHO.test(linhaTexto) || continuaTabelaLarga)
        ? marcarLinhasDeTabelaLarga([...corpoLinhas].sort((a, b) => b.y - a.y), continuaTabelaLarga)
        : undefined;
    const corpo = fragmentarLinhasPorColunas(corpoLinhas, clusters, linhasDeTabela);
    return [cabecalho, textoColunar(corpo, clusters)].filter(Boolean).join('\n');
}
