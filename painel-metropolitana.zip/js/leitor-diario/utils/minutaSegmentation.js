// ============================================================================
// minutaSegmentation.ts — divide o texto de uma página em blocos, um por
// servidor. Corrige o bug "página com vários servidores vira uma linha só":
// a segmentação ancora em cada ocorrência de MaSP, não na página inteira.
// ============================================================================
// MaSP: dígitos (com pontuação opcional) + hífen + 1-2 dígitos verificadores.
// Aceita "MaSP", "MASP", "Masp" (a captura em si é sempre feita explicitamente
// por "MaSP" como rótulo OU um padrão numérico isolado no início de linha).
// IMPORTANTE: o `(?=...)` é uma LOOKAHEAD — não consome o primeiro caractere
// do nome do servidor. Uma versão anterior usava `\s+[A-ZÀ-Ü]` sem lookahead,
// que comia a primeira letra do nome (ex.: "WILTON" virava "ILTON").
const RE_MASP_ROTULADO = /(?:MaSP|MASP|Masp)\s*:?\s*([0-9][0-9.\s]{3,14}-\d{1,2})/gi;
const RE_MASP_INICIO_LINHA = /^\s*([0-9][0-9.\s]{3,14}-\d{1,2})(?=\s+[A-ZÀ-Ü])/gm;
const RE_CONTEXTO_ASSINATURA_FORTE = /ASSINATURA\s+DO|FUNCION[ÁA]RIO\s+RESPONS[ÁA]VEL|DIRETORA?\s+ESCOLAR|TEMPOR[ÁA]RIO\s+AUTORIZADO\s+PELO\s+SEI|ASS\.?\s*T[ÉE]CNICO\s+DE\s+EDUCA[ÇC][ÃA]O\s+B[ÁA]SICA/i;
const RE_MASP_CARIMBO = /(?:DIRETOR(?:A)?|RESPONS[ÁA]VEL|T[ÉE]CNICO(?:A)?)[^\n]{0,45}\bMASP\b|\bMASP\b[^\n]{0,45}(?:DIRETOR(?:A)?|RESPONS[ÁA]VEL|T[ÉE]CNICO(?:A)?)/i;
function maspEmContextoDeAssinatura(texto, inicio, fim) {
    const linhaIni = texto.lastIndexOf('\n', inicio - 1) + 1;
    const proximaQuebra = texto.indexOf('\n', fim);
    const linhaFim = proximaQuebra >= 0 ? proximaQuebra : texto.length;
    const linha = texto.slice(linhaIni, linhaFim);
    if (RE_MASP_CARIMBO.test(linha))
        return true;
    const linhas = texto.split(/\r?\n/);
    const pos = texto.slice(0, inicio).split('\n').length - 1;
    const viz = linhas.slice(Math.max(0, pos - 4), Math.min(linhas.length, pos + 3)).join('\n');
    return RE_CONTEXTO_ASSINATURA_FORTE.test(viz);
}
function coletarOcorrenciasMasp(texto) {
    const ocorrencias = [];
    const vistos = new Set();
    for (const rx of [RE_MASP_ROTULADO, RE_MASP_INICIO_LINHA]) {
        rx.lastIndex = 0;
        let m;
        while ((m = rx.exec(texto)) !== null) {
            // Evita duplicar quando o mesmo MaSP casa nos dois padrões na mesma posição
            const posAprox = m.index;
            let duplicado = false;
            for (const v of vistos) {
                if (Math.abs(v - posAprox) < 15) {
                    duplicado = true;
                    break;
                }
            }
            if (!duplicado && !maspEmContextoDeAssinatura(texto, m.index, m.index + m[0].length)) {
                vistos.add(posAprox);
                ocorrencias.push({ masp: m[1], index: m.index, fimMatch: m.index + m[0].length });
            }
        }
    }
    ocorrencias.sort((a, b) => a.index - b.index);
    return ocorrencias;
}
// Marcadores de rodapé/assinatura: tudo o que vem DEPOIS de um destes
// nunca é dado do servidor (é nome de quem assina, MaSP de quem assina,
// data de assinatura, carimbo de autorização) — mesmo que contenha um
// padrão que pareça um MaSP válido (ex.: "Diretora- MASP 667427-9" no
// rodapé de um formulário de retificação real). Cortar aqui ANTES de
// procurar ocorrências de MaSP evita blocos-fantasma criados a partir do
// MaSP de quem assinou o documento.
const RE_INICIO_RODAPE = /(?:^\s*Assinatura\s*:?\s*$|\bAssinatura\s+do\s*\(?\s*a\s*\)?\s+(?:Diretor|Respons[áa]vel)(?:\s*\(?\s*a\s*\)?)?\b|\bAssinatura\s+do\s+(?:Diretor|Respons[áa]vel)\b|\bTempor[áa]rio\s+Autorizado\s+Pelo\s+SEI\b)/im;
/** Remove o rodapé de assinatura (e tudo depois dele) do texto de uma
 *  página, antes da segmentação por servidor. Exportada para reuso na
 *  etapa de limpeza e para testes unitários isolados. */
export function removerRodapeAssinatura(texto) {
    const m = RE_INICIO_RODAPE.exec(texto);
    if (!m)
        return texto;
    return texto.slice(0, m.index);
}
/** Segmenta o texto de UMA página em um bloco por servidor. Se nenhum
 *  MaSP for encontrado, devolve um único bloco cobrindo a página inteira
 *  (comportamento de fallback — o validador vai marcar como "revisar" se
 *  não conseguir extrair um servidor dali). */
export function segmentarPagina(textoOriginal) {
    const texto = removerRodapeAssinatura(textoOriginal);
    const ocorrencias = coletarOcorrenciasMasp(texto);
    if (ocorrencias.length === 0) {
        return [
            {
                masp: "",
                maspBruto: "",
                textoAntes: "",
                textoDepois: texto,
                textoCompleto: texto,
                indexInicio: 0,
                indexFim: texto.length,
            },
        ];
    }
    const blocos = [];
    const JANELA_ANTES = 500; // caracteres olhados para trás, no máximo
    for (let i = 0; i < ocorrencias.length; i++) {
        const atual = ocorrencias[i];
        const anterior = i > 0 ? ocorrencias[i - 1].fimMatch : 0;
        const proximo = i + 1 < ocorrencias.length ? ocorrencias[i + 1].index : texto.length;
        const inicioAntes = Math.max(anterior, atual.index - JANELA_ANTES);
        const textoAntes = texto.slice(inicioAntes, atual.index);
        const textoDepois = texto.slice(atual.fimMatch, proximo);
        blocos.push({
            masp: atual.masp,
            maspBruto: atual.masp,
            textoAntes,
            textoDepois,
            textoCompleto: texto.slice(inicioAntes, proximo),
            indexInicio: inicioAntes,
            indexFim: proximo,
        });
    }
    return blocos;
}
