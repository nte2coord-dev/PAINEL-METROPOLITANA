// ============================================================================
// diarioMetropolitanaA.ts — regras puras e auditáveis do fluxo DIPE para o
// Diário do Executivo/MG.
//
// Escopo obrigatório:
//   • somente SEE e SEPLAG;
//   • somente SRE METROPOLITANA A;
//   • nunca atravessar para Metropolitana B/C ou qualquer outra SRE;
//   • nos atos de acumulação da SEPLAG, entrar no órgão Educação e extrair
//     servidor por servidor apenas do subbloco Metropolitana A;
//   • preservar a fundamentação/decisão exatamente a partir do Diário;
//   • tabelas de Lotação da Metropolitana A viram um registro por linha.
//
// Este módulo não chama LLM e não depende do navegador. Isso permite testar
// as regras de fronteira/extração separadamente do OCR/pdf.js.
// ============================================================================
import { normalizarLinha, normalizarMasp, normalizarNome, semAcento, slug } from "./normalizers.js";
import { validarMasp, validarNomeServidor, validarCargo } from "./fieldValidators.js";
function base(txt) {
    return semAcento(txt || "").toUpperCase().replace(/\s+/g, " ").trim();
}
/** Aceita as variações reais observadas no Diário/OCR, inclusive a forma
 *  colada "METROPOLITANAA" que aparece na extração do PDF de 17/07/2026. */
export function ehMetropolitanaA(txt) {
    const b = base(txt).replace(/[^A-Z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
    return /(?:^| )METROPOLITANA\s*A(?: |$)/.test(b) || /(?:^| )METROPOLITANAA(?: |$)/.test(b);
}
const RE_CABECALHO_SRE = /^[ \t]*-?\s*(?:(?:SRE\s+(?:DE\s+)?)|(?:SUPERINTEND[ÊE]NCIA\s+REGIONAL\s+DE\s+ENSINO\s*[-–—:]?\s*))([^\n:]{2,70})\s*:?\s*$/gim;
// OCR/PDF pode juntar o próximo título na mesma linha: "SRE Metropolitana B ABONO...".
// A regex genérica acima exige linha inteira e perderia esse ponto de corte.
// Esta forma dedicada reconhece apenas SRE Metropolitana <letra> no INÍCIO
// da linha, portanto não confunde menções narrativas como "em exercício na
// SRE Metropolitana B" no meio de um servidor.
const RE_CABECALHO_METRO_CURTO = /^[ \t]*-?\s*SRE\s+(?:DE\s+)?METROPOLITANA\s*([A-Z])\b/gim;
// O jornal real também imprime "METROPOLITANA B" como cabeçalho de coluna
// isolado, SEM a palavra "SRE" na frente (ex.: quando o layout do Diário
// tem uma coluna por regional). Nesse caso as duas regexes acima não batem
// e a leitura atravessava para a próxima SRE sem cortar — exatamente o
// problema relatado ("o jornal continua lendo depois da Metropolitana B").
// Esta forma cobre a linha "isolada" (só a palavra METROPOLITANA + letra,
// nada mais na linha, com no máximo pontuação/traço em volta).
const RE_CABECALHO_METRO_ISOLADO = /^[ \t]*[-–—•]?\s*METROPOLITANA\s*([A-Z])\s*[-–—:]?\s*$/gim;
// Mudança de unidade administrativa da SEE encerra um escopo SRE herdado.
// Ex.: depois de um ato de vice-diretor da Metropolitana A, o Diário pode
// abrir 'Superintendência de Gestão de Pessoas e Normas'. Os atos seguintes
// são do órgão central e NÃO podem herdar Metropolitana A. Não inclui
// 'Superintendência Regional de Ensino', que é justamente um cabeçalho de SRE.
const RE_LIMITE_UNIDADE_ADMIN = /^[ \t]*(?:SUPERINTEND[ÊE]NCIA\s+(?!REGIONAL\s+DE\s+ENSINO)[^\n]{3,100}|SUBSECRETARIA\s+DE\s+[^\n]{3,100}|DIRETORIA\s+(?!CENTRAL\s+DE\s+GEST[ÃA]O\s+DE\s+DIREITOS\s+DO\s+SERVIDOR)[^\n]{3,100})\s*$/gim;
function classificarNomeSre(nome) {
    return ehMetropolitanaA(nome) ? "METROPOLITANA_A" : "OUTRA";
}
/** Divide um trecho mantendo estado entre páginas. O surgimento de qualquer
 *  outro cabeçalho de SRE encerra imediatamente o bloco Metropolitana A. */
export function dividirPorSreMetropolitanaA(texto, sreInicial) {
    const eventos = [];
    const rx = new RegExp(RE_CABECALHO_SRE.source, RE_CABECALHO_SRE.flags);
    let m;
    while ((m = rx.exec(texto)) !== null) {
        eventos.push({ pos: m.index, fim: m.index + m[0].length, sre: classificarNomeSre(m[1]) });
        if (m.index === rx.lastIndex)
            rx.lastIndex++;
    }
    const rxMetro = new RegExp(RE_CABECALHO_METRO_CURTO.source, RE_CABECALHO_METRO_CURTO.flags);
    while ((m = rxMetro.exec(texto)) !== null) {
        const letra = String(m[1] || '').toUpperCase();
        eventos.push({ pos: m.index, fim: m.index + m[0].length, sre: letra === 'A' ? 'METROPOLITANA_A' : 'OUTRA' });
        if (m.index === rxMetro.lastIndex)
            rxMetro.lastIndex++;
    }
    const rxMetroIsolado = new RegExp(RE_CABECALHO_METRO_ISOLADO.source, RE_CABECALHO_METRO_ISOLADO.flags);
    while ((m = rxMetroIsolado.exec(texto)) !== null) {
        const letra = String(m[1] || '').toUpperCase();
        eventos.push({ pos: m.index, fim: m.index + m[0].length, sre: letra === 'A' ? 'METROPOLITANA_A' : 'OUTRA' });
        if (m.index === rxMetroIsolado.lastIndex)
            rxMetroIsolado.lastIndex++;
    }
    // Fronteira inline legítima: '... servidora: SRE METROPOLITANA B – ...'.
    // Exige início de linha, ':' ou ';' antes de SRE para não confundir frases
    // narrativas como 'em exercício na SRE Metropolitana B'.
    const rxMetroInline = /(?:^|[:;]\s*)SRE\s+(?:DE\s+)?METROPOLITANA\s*([A-Z])\b/gim;
    while ((m = rxMetroInline.exec(texto)) !== null) {
        const letra = String(m[1] || '').toUpperCase();
        const posSre = m.index + m[0].toUpperCase().lastIndexOf('SRE');
        eventos.push({ pos: posSre, fim: m.index + m[0].length, sre: letra === 'A' ? 'METROPOLITANA_A' : 'OUTRA' });
        if (m.index === rxMetroInline.lastIndex)
            rxMetroInline.lastIndex++;
    }
    // Se já estamos dentro da Metropolitana A e começa uma nova unidade
    // administrativa do órgão central, encerramos a herança de SRE.
    const rxLim = new RegExp(RE_LIMITE_UNIDADE_ADMIN.source, RE_LIMITE_UNIDADE_ADMIN.flags);
    while ((m = rxLim.exec(texto)) !== null) {
        eventos.push({ pos: m.index, fim: m.index + m[0].length, sre: 'OUTRA' });
        if (m.index === rxLim.lastIndex)
            rxLim.lastIndex++;
    }
    eventos.sort((a, b) => a.pos - b.pos || a.fim - b.fim);
    // O mesmo cabeçalho pode casar nas duas regexes. Mantém um evento por posição.
    for (let i = eventos.length - 1; i > 0; i--) {
        if (eventos[i].pos === eventos[i - 1].pos)
            eventos.splice(i, 1);
    }
    if (eventos.length === 0) {
        return { trechos: [{ texto, sre: sreInicial }], sreFinal: sreInicial };
    }
    const trechos = [];
    let cursor = 0;
    let atual = sreInicial;
    for (const ev of eventos) {
        if (ev.pos > cursor)
            trechos.push({ texto: texto.slice(cursor, ev.pos), sre: atual });
        // Dentro da MESMA página/seção, a primeira outra SRE encerra A.
        // O parser reinicia este estado ao avançar de página, permitindo que uma
        // nova Metropolitana A legítima seja encontrada mais adiante no jornal.
        if (atual === "METROPOLITANA_A" && ev.sre === "OUTRA") {
            atual = "ENCERRADA";
        }
        else if (atual !== "ENCERRADA") {
            atual = ev.sre;
        }
        // Mantém o cabeçalho dentro do trecho novo para rastreabilidade.
        cursor = ev.pos;
    }
    if (cursor < texto.length)
        trechos.push({ texto: texto.slice(cursor), sre: atual });
    return { trechos, sreFinal: atual };
}
export function temCabecalhoExplicitoMetropolitanaA(texto) {
    const rx = new RegExp(RE_CABECALHO_SRE.source, RE_CABECALHO_SRE.flags);
    let m;
    while ((m = rx.exec(texto)) !== null) {
        if (ehMetropolitanaA(m[1]))
            return true;
    }
    return false;
}
function paginaPorOffset(offsets, pos) {
    for (const o of offsets)
        if (pos >= o.inicio && pos <= o.fim)
            return o.pagina;
    return offsets.length ? offsets[offsets.length - 1].pagina : null;
}
// `preferirIntegral` escolhe qual camada de texto vira a fonte: a camada
// LINEAR/integral (textoBuscaDiario, útil como Ctrl+F quando a reconstrução
// geométrica falhou em capturar o bloco inteiro) ou a camada GEOMÉTRICA já
// organizada por coluna (texto). Regressão real (Diário 05/09/2026, pág.
// 17): a camada linear/integral não entende a grade de colunas do jornal,
// então ela intercala trechos de colunas vizinhas que só por acaso caem na
// mesma altura Y — "-SRE METROPOLITANA A:" (coluna 1) colou direto em cima
// de "MARCELA GRIGORIO ALVES PEREIRA" (na verdade da SRE de Leopoldina,
// bem mais abaixo na leitura real, mas na mesma altura de uma coluna
// vizinha), apagando os 9 servidores reais da Metropolitana A sem nenhum
// aviso. A camada geométrica, quando reconhece a tabela/lista, já resolve
// isso corretamente — por isso `extrairAcumulacoesMetropolitanaA` tenta a
// camada geométrica PRIMEIRO e só cai para a integral se aquela não achar
// nada (ver função exportada abaixo).
function montarTextoContinuo(paginas, preferirIntegral = true) {
    let texto = "";
    const offsets = [];
    for (const pagina of paginas) {
        const inicio = texto.length;
        const fonte = preferirIntegral
            ? (pagina.textoBuscaDiario || pagina.texto || "")
            : (pagina.texto || pagina.textoBuscaDiario || "");
        texto += fonte + "\n";
        offsets.push({ inicio, fim: texto.length, pagina });
    }
    return { texto, offsets };
}
// Teto de segurança para os dois trechos de texto fixo (fundamentação e
// decisão) exibidos na tela de conferência. Regressão real (Diário
// 17/07/2026, pág. 17): quando a fronteira "-SRE ..." que normalmente
// encerra a Decisão não começa a própria linha (mesma colagem de coluna
// documentada em `extrairAcumulacoesMetropolitanaA`), o corte por
// início-de-linha nunca casa e o trecho capturado passa a incluir a seção
// inteira — dezenas de SREs e centenas de servidores de outras regiões,
// todos interligados com texto de um ato completamente diferente. Uma
// Decisão real nunca passa de poucas centenas de caracteres; travar um
// teto aqui garante que a tela de conferência sempre mostra um cabeçalho
// do tamanho de um cabeçalho, mesmo quando a fronteira de corte falha.
const TAMANHO_MAXIMO_TEXTO_FIXO = 700;
function limitarTamanho(texto) {
    return texto.length > TAMANHO_MAXIMO_TEXTO_FIXO
        ? `${texto.slice(0, TAMANHO_MAXIMO_TEXTO_FIXO).trim()}…`
        : texto;
}
function recortarFundamentacaoAcumulacao(cabecalho) {
    const inicio = cabecalho.search(/A\s+DIRETORA\s+DA\s+DIRETORIA\s+CENTRAL/i);
    const fonte = inicio >= 0 ? cabecalho.slice(inicio) : cabecalho;
    return normalizarLinha(limitarTamanho(fonte));
}
function recortarDecisao(decisaoEListas) {
    // A fronteira "-SRE ..."/"-SECRETARIA ..." também tolera vir sem quebra
    // de linha antes de si, pela mesma razão documentada acima: mesmo sem
    // início de linha, corta a Decisão assim que a lista de servidores
    // (que sempre abre com esse marcador) começa — antes de precisar do
    // teto de tamanho como último recurso.
    const m = /DECIS[ÃA]O\s*:\s*([\s\S]*?)(?=\n?\s*-\s*(?:SRE|SECRETARIA|FUNDA[ÇC][ÃA]O|POL[ÍI]CIA|INSTITUTO)\b|$)/i.exec(decisaoEListas);
    return normalizarLinha(m ? `Decisão: ${limitarTamanho(m[1])}` : "");
}
function splitForaParenteses(txt) {
    const partes = [];
    let nivel = 0;
    let atual = "";
    for (const ch of txt) {
        if (ch === "(")
            nivel++;
        if (ch === ")" && nivel > 0)
            nivel--;
        if (ch === "/" && nivel === 0) {
            partes.push(normalizarLinha(atual));
            atual = "";
        }
        else {
            atual += ch;
        }
    }
    if (atual.trim())
        partes.push(normalizarLinha(atual));
    return partes.filter(Boolean);
}
const TERMOS_PARENTESES_NAO_MUNICIPIO = /\b(EXERCENDO|AUXILIAR|SECRETARI|PROFESSOR|PROFESSORA|APOIO|AFAST|TECNIC|TÉCNIC|DIRETOR|DIRETORA|COORDENADOR|COORDENADORA|EMPRESA|EBSERH|C[ÂA]MARA|VEREADOR|APOSENTAD[OA]|RPPS)\b/i;
// Regressão real (Diário 05/09/2026, pág. 17): a observação de
// aposentadoria às vezes vem colada ao NOME DO MUNICÍPIO real, dentro do
// MESMO parêntese ("PROFESSOR(BELO HORIZONTE - APOSENTADO RPPS)") — sem
// remover essa cauda antes de validar, o termo bloqueado acima ("RPPS")
// rejeitava o parêntese inteiro e jogava fora um município real
// (Rosane Ribeiro Menezes, MaSP 0290192-4).
const RE_QUALIFICADOR_APOSENTADORIA = /\s*[-–—]\s*APOSENTAD[OA]\b.*$/i;
function extrairMunicipioFinal(detalhes) {
    const todos = [...detalhes.matchAll(/\(([^()]{2,50})\)/g)];
    if (!todos.length)
        return "";
    const cand = normalizarLinha(normalizarLinha(todos[todos.length - 1][1]).replace(RE_QUALIFICADOR_APOSENTADORIA, ""));
    if (!cand || TERMOS_PARENTESES_NAO_MUNICIPIO.test(cand) || /\d/.test(cand))
        return "";
    return cand.toUpperCase();
}
// Termos que nunca aparecem num vínculo real de acumulação ("PEB/PEB",
// "PEB/PROFESSOR(CONTAGEM)") mas são comuns em avisos de outros órgãos
// (IGAM, meio ambiente) que a colagem de colunas pode grudar no detalhe
// quando a fronteira "-SRE ..."/"-SECRETARIA ..." também está corrompida
// e sobra texto alheio entre o último servidor e o corte real (Diário
// 06/08/2026, pág. 15: Joseane Pereira Morais Chaves).
const RE_DETALHE_CONTAMINADO = /\b(PROCESSO\s*N[ºO°.]|PORTARIA|USU[ÁA]RIO|DEFERIDO|INDEFERIDO|ARQUIVADO|REQUERIMENTO)\b/i;
/** Um `)` sem `(` correspondente é sinal quase certo de que a colagem de
 *  coluna cortou o início do parêntese de outro servidor (ex.: "SÃO
 *  PAULO)" virando apenas "PAULO)"), colando o resto no detalhe deste —
 *  nunca acontece num vínculo real, onde os parênteses de município vêm
 *  sempre inteiros (Diário 17/07/2026, pág. 17: Cledina Freitas Silva). */
function temParentesesDesbalanceados(detalhes) {
    let abertos = 0;
    for (const ch of detalhes) {
        if (ch === "(")
            abertos++;
        else if (ch === ")") {
            if (abertos === 0)
                return true;
            abertos--;
        }
    }
    return false;
}
function montarProblemasBasicos(nome, masp, detalhes) {
    const problemas = [];
    const vn = validarNomeServidor(nome);
    const vm = validarMasp(masp);
    if (!vn.valido)
        problemas.push(`Nome: ${vn.motivo}`);
    if (!vm.valido)
        problemas.push(`MaSP: ${vm.motivo}`);
    if (detalhes.length > 80 || RE_DETALHE_CONTAMINADO.test(detalhes) || temParentesesDesbalanceados(detalhes)) {
        problemas.push("Cargo/vínculo suspeito de contaminação por colagem de colunas — confira contra o Diário original.");
    }
    return problemas;
}
/** Extrator específico do ato SEPLAG "Acumulação de Cargos, Empregos e
 *  Funções Públicos". Ele não depende da ordem nome/MaSP usada pelos atos
 *  genéricos: neste ato o padrão real é NOME -Masp 0000000-0, vínculos. */
function extrairAcumulacoesDeUmaFonte(paginas, dataEdicao, preferirIntegral) {
    const registros = [];
    const logs = [];
    const { texto, offsets } = montarTextoContinuo(paginas, preferirIntegral);
    // A seção é ancorada no TÍTULO do próprio ato ("Acumulação de Cargos,
    // Empregos e Funções Públicos"), não no cabeçalho "DIRETORIA CENTRAL DE
    // GESTÃO / DE DIREITOS DO SERVIDOR" que ficava acima dele. Regressão real
    // encontrada nesta base (Diário 17/07/2026, pág. 17): aquele cabeçalho é
    // só o NOME DA DIRETORIA, e a frase completa "A Diretora da Diretoria
    // Central de Gestão de Direitos do Servidor, ..." é reaproveitada como
    // abertura de QUALQUER ato assinado pela mesma diretoria — inclusive atos
    // completamente diferentes (ex.: "PRORROGAÇÃO DE POSSE" de uma única
    // servidora, sem nenhuma relação com Acumulação de Cargos). Ancorar no
    // cabeçalho da diretoria por si só, mesmo com espaço para colagem de
    // coluna, cria pares falsos "DIRETORIA CENTRAL DE GESTÃO...DE DIREITOS DO
    // SERVIDOR" formados por coincidência dentro de um ato totalmente alheio,
    // e a seção calculada a partir dali vem misturada com esse outro ato —
    // exatamente o "ACUMULAÇÃO DE CARGOS" com texto de outro ato colado por
    // dentro que apareceu na conferência do usuário. O título do ato, em
    // compensação, é o NOME ESPECÍFICO desse tipo de decisão: nunca é reused
    // por outro ato e, nas duas edições reais já conferidas, sempre chega
    // inteiro (nunca partido ao meio pela colagem de colunas), mesmo quando o
    // cabeçalho da diretoria acima dele vem corrompido.
    const reAcumulacaoTitulo = /ACUMULA[ÇC][ÃA]O\s+DE\s+CARGOS,?\s+EMPREGOS\s+E\s+FUN[ÇC][ÕO]ES\s+P[ÚU]BLICOS/gi;
    const inicios = [...texto.matchAll(reAcumulacaoTitulo)].map((m) => m.index ?? 0);
    if (!inicios.length)
        return { registros, logs };
    for (let i = 0; i < inicios.length; i++) {
        const inicio = inicios[i];
        const fim = i + 1 < inicios.length ? inicios[i + 1] : texto.length;
        let secao = texto.slice(inicio, fim);
        // Evita engolir atos claramente posteriores quando a diretoria não é
        // repetida no cabeçalho da página seguinte.
        const limitePosterior = secao.search(/\n\s*(?:COMISS[ÃA]O\s+DE\s+ACUMULA[ÇC][ÃA]O|A\s+SECRET[ÁA]RIA\s+DE\s+ESTADO\s+DE\s+PLANEJAMENTO|PELA\s+SECRETARIA\s+DE\s+ESTADO\s+DE)/i);
        if (limitePosterior > 0)
            secao = secao.slice(0, limitePosterior);
        const decisoes = [...secao.matchAll(/DECIS[ÃA]O\s*:/gi)].map((m) => m.index ?? 0);
        if (!decisoes.length)
            continue;
        for (let d = 0; d < decisoes.length; d++) {
            const decPos = decisoes[d];
            const decFim = d + 1 < decisoes.length ? decisoes[d + 1] : secao.length;
            const cabecalho = secao.slice(0, decPos);
            const decisaoEListas = secao.slice(decPos, decFim);
            // Sem âncora de início de linha: mesma contaminação de coluna da
            // pág. 15 (Diário 06/08/2026) também gruda texto do IGAM bem antes
            // deste marcador ("...Usuário: Antonio -SECRETARIA DE ESTADO DE
            // EDUCAÇÃO:"), então ele nunca começa a própria linha nesta edição.
            const reEducacao = /-\s*SECRETARIA\s+DE\s+ESTADO\s+DE\s+EDUCA[ÇC][ÃA]O\s*:\s*/gi;
            const ed = reEducacao.exec(decisaoEListas);
            if (!ed)
                continue;
            const blocoEducacao = decisaoEListas.slice(ed.index + ed[0].length);
            // Mesma contaminação de coluna do reEducacao acima: nesta edição
            // "-SRE METROPOLITANA A:" também aparece colado a texto do IGAM
            // ("...Deferido com condicionante, -SRE METROPOLITANA A:"), sem
            // começar a própria linha.
            const reAlvo = /-\s*SRE\s+(?:DE\s+)?METROPOLITANA\s*A\s*:\s*/gi;
            const alvo = reAlvo.exec(blocoEducacao);
            if (!alvo)
                continue;
            const posAlvoGlobal = inicio + decPos + ed.index + ed[0].length + alvo.index;
            let blocoAlvo = blocoEducacao.slice(alvo.index + alvo[0].length);
            // Mesma contaminação de coluna: sem a âncora de início de linha aqui
            // também, "-SRE METROPOLITANA B:" (ou a próxima secretaria) podia
            // aparecer colado a texto do IGAM e nunca ser reconhecido como
            // fronteira — daí o corte não acontecia e a extração continuava
            // "comendo" dezenas de linhas de texto totalmente alheio como se
            // fossem mais servidores da Metropolitana A.
            const proximaSre = /-\s*SRE\s+(?:DE\s+)?[^\n:]{2,70}\s*:\s*/i.exec(blocoAlvo);
            const proximaSecretaria = /-\s*(?:SECRETARIA|FUNDA[ÇC][ÃA]O|POL[ÍI]CIA|INSTITUTO)\b[^\n:]{2,90}:\s*/i.exec(blocoAlvo);
            const cortes = [proximaSre?.index, proximaSecretaria?.index].filter((v) => typeof v === "number" && v >= 0);
            if (cortes.length)
                blocoAlvo = blocoAlvo.slice(0, Math.min(...cortes));
            const fundamentacao = recortarFundamentacaoAcumulacao(cabecalho);
            const decisao = recortarDecisao(decisaoEListas);
            const textoLegal = normalizarLinha([fundamentacao, decisao].filter(Boolean).join(" "));
            const paginaOrigem = paginaPorOffset(offsets, posAlvoGlobal);
            const plano = blocoAlvo.replace(/\s*\n\s*/g, " ").trim();
            const rxServidor = /([A-ZÀ-Ü][A-ZÀ-Ü'´.\-\s]{4,110}?)\s*-\s*Masp\s*([0-9][0-9.\s]{4,14}-\s*\d{1,2})\s*,\s*([^;]+?)(?=;|$)/gi;
            let sm;
            let idx = 0;
            while ((sm = rxServidor.exec(plano)) !== null) {
                const nome = normalizarNome(sm[1]);
                const masp = normalizarMasp(sm[2]);
                const detalhes = normalizarLinha(sm[3]).replace(/[.\s]+$/g, "");
                const vinculos = splitForaParenteses(detalhes);
                const cargo = vinculos[0] || detalhes;
                const cargo2 = vinculos.length > 1 ? vinculos.slice(1).join("/") : "";
                const municipio = extrairMunicipioFinal(detalhes);
                const problemas = montarProblemasBasicos(nome, masp, detalhes);
                registros.push({
                    id: `dia_acum_${paginaOrigem?.numero ?? 0}_${slug(masp)}_${idx}_${registros.length}`,
                    selecionar: problemas.length === 0,
                    tipo_ato: "acumulacao_cargos",
                    tipo_label: "Acumulação de Cargos, Empregos e Funções Públicos",
                    titulo_ato: "ACUMULAÇÃO DE CARGOS, EMPREGOS E FUNÇÕES PÚBLICOS",
                    texto_legal: textoLegal,
                    fundamentacao_legal: fundamentacao,
                    decisao,
                    masp,
                    nome_servidor: nome,
                    secretaria: "SEPLAG/MG",
                    cargo,
                    cargo_2: cargo2,
                    municipio,
                    orgao_sre: "SRE METROPOLITANA A",
                    localidade_escola: municipio,
                    pagina_jornal: paginaOrigem ? `PÁG. ${paginaOrigem.numero}` : "",
                    data_jornal: dataEdicao,
                    texto_ato: detalhes,
                    fonte_arquivo: paginaOrigem?.arquivo || paginas[0]?.arquivo || "",
                    fonte_pagina: paginaOrigem?.numero,
                    bloco_origem: normalizarLinha(sm[0]),
                    texto_origem: paginaOrigem?.texto || secao,
                    confianca: problemas.length ? "revisar" : "alta",
                    problemas_validacao: problemas,
                    historico_alteracoes: [],
                });
                logs.push({
                    nivel: problemas.length ? "aviso" : "info",
                    origem: "Diário/SEPLAG",
                    pagina: paginaOrigem?.numero,
                    mensagem: `[SRE METROPOLITANA A] Acumulação: ${nome} | MaSP ${masp}${problemas.length ? " — revisão necessária" : ""}.`,
                });
                idx++;
            }
            if (idx > 0) {
                logs.push({
                    nivel: "info",
                    origem: "Diário/SEPLAG",
                    pagina: paginaOrigem?.numero,
                    mensagem: `Bloco de Acumulação processado: ${idx} servidor(es) da SRE Metropolitana A. A leitura foi encerrada antes da próxima SRE.`,
                });
            }
        }
    }
    return { registros, logs };
}
/** Extrator específico do ato SEPLAG "Acumulação de Cargos, Empregos e
 *  Funções Públicos". Tenta primeiro a camada geométrica (texto), que
 *  entende a grade de colunas do jornal e por isso é a mais confiável
 *  quando reconhece o bloco; só cai para a camada linear/integral
 *  (textoBuscaDiario) se a geométrica não encontrar NENHUM servidor da
 *  Metropolitana A — cobrindo o caso em que a reconstrução geométrica
 *  falhou em capturar o bloco inteiro (ver `montarTextoContinuo`). */
export function extrairAcumulacoesMetropolitanaA(paginas, dataEdicao) {
    const viaGeometrica = extrairAcumulacoesDeUmaFonte(paginas, dataEdicao, false);
    if (viaGeometrica.registros.length > 0)
        return viaGeometrica;
    return extrairAcumulacoesDeUmaFonte(paginas, dataEdicao, true);
}
function normalizarDataTabela(d) {
    const limpo = d.trim();
    // PDF.js frequentemente devolve as datas da tabela sem separadores:
    // "23042026" em vez de "23/04/2026". Isso é dado válido da célula,
    // não motivo para marcar o servidor como REVISAR.
    const compacto = /^(\d{2})(\d{2})(20\d{2})$/.exec(limpo.replace(/\D/g, ""));
    if (compacto)
        return `${compacto[1]}/${compacto[2]}/${compacto[3]}`;
    const m = /(\d{1,2})[\/\s.\-]+(\d{1,2})[\/\s.\-]+(20\d{2})/.exec(limpo);
    return m ? `${m[1].padStart(2, "0")}/${m[2].padStart(2, "0")}/${m[3]}` : "";
}
function extrairCaudaLotacao(resto) {
    const texto = normalizarLinha(resto);
    // A tabela tem estrutura fixa da direita para a esquerda:
    // CONTEÚDO | CH | POSSE | EXERCÍCIO | DATA DA NOMEAÇÃO.
    // Lemos as três últimas datas como células próprias, aceitando tanto
    // dd/mm/aaaa quanto o formato colado ddmmaaaa gerado pelo PDF.js.
    const tokens = texto.split(/\s+/).filter(Boolean);
    const datas = [];
    let corte = tokens.length;
    for (let i = tokens.length - 1; i >= 0 && datas.length < 3; i--) {
        const token = tokens[i];
        const data = normalizarDataTabela(token);
        if (data) {
            datas.unshift(data);
            corte = i;
            continue;
        }
        // Também cobre uma data que chegou quebrada em 3 tokens: "23 04 2026".
        if (i >= 2) {
            const tripla = `${tokens[i - 2]} ${tokens[i - 1]} ${tokens[i]}`;
            const dataTripla = normalizarDataTabela(tripla);
            if (dataTripla) {
                datas.unshift(dataTripla);
                corte = i - 2;
                i -= 2;
                continue;
            }
        }
        // Depois que começamos a colher datas, qualquer outro token encerra a
        // cauda. Assim não confundimos números do conteúdo com datas.
        if (datas.length > 0)
            break;
    }
    const antesDatas = tokens.slice(0, corte).join(" ").trim();
    const chMatch = /^(.*\S)\s+(\d{1,2})$/.exec(antesDatas);
    const conteudo = normalizarLinha(chMatch ? chMatch[1] : antesDatas);
    const cargaHoraria = chMatch ? chMatch[2].padStart(2, "0") : "";
    return {
        conteudo,
        cargaHoraria,
        dataPosse: datas[0] || "",
        dataExercicio: datas[1] || "",
        dataNomeacao: datas[2] || "",
    };
}
/** Parser para a tabela de "LOTAÇÃO ATO Nº ..." usada pela Metropolitana A.
 *  O MaSP aparece sem a palavra MASP e, por isso, não pode ser lido pelo
 *  regex genérico de atos narrativos. */
export function extrairLotacaoTabelaMetropolitanaA(blocoTexto, meta) {
    if (!/\bLOTA[ÇC][ÃA]O\b/i.test(blocoTexto) || !/LOCALIDADE\s+ESCOLA\s+MASP\s+NOME\s+ADM/i.test(blocoTexto))
        return [];
    const linhas = blocoTexto.split(/\r?\n/).map((l) => normalizarLinha(l)).filter(Boolean);
    const idxCab = linhas.findIndex((l) => /LOCALIDADE\s+ESCOLA\s+MASP\s+NOME\s+ADM/i.test(l));
    if (idxCab < 0)
        return [];
    const cabecalho = linhas.slice(0, idxCab).join(" ");
    const numero = /LOTA[ÇC][ÃA]O\s+ATO\s+N[ºO°.]*\s*([\d.]+\s*\/\s*\d{4})/i.exec(cabecalho)?.[1]?.replace(/\s+/g, "") || "";
    const textoLegal = normalizarLinha(cabecalho.replace(/^.*?LOTA[ÇC][ÃA]O\s+ATO\s+N[ºO°.]*\s*[\d.]+\s*\/\s*\d{4}/i, ""));
    const regs = [];
    for (let i = idxCab + 1; i < linhas.length; i++) {
        const linha = linhas[i];
        if (/^(?:DOCUMENTO\s+ASSINADO|SECRETARIA\s+DE\s+ESTADO|SUPERINTEND[ÊE]NCIA\b|ATO\s+N[ºO°.]|RETIFICA|ANULA)/i.test(linha))
            break;
        const m = /^(.+?)\s+((?:E\.?E\.?|ESCOLA\s+ESTADUAL|INSTITUTO)\s+.+?)\s+(\d{6,9})\s+(.+?)\s+(\d{1,2})\s+([A-Z]{2,5})\s+(.+)$/i.exec(linha);
        if (!m)
            continue;
        const municipio = normalizarLinha(m[1]).toUpperCase();
        const escola = normalizarLinha(m[2]).toUpperCase().replace(/^E\.\s*E\.?\s*/i, "EE ");
        const masp = normalizarMasp(m[3]);
        const nome = normalizarNome(m[4]);
        const admissao = String(parseInt(m[5], 10)).padStart(2, "0");
        const cargo = m[6].toUpperCase();
        const resto = normalizarLinha(m[7]);
        const { conteudo, cargaHoraria, dataPosse, dataExercicio, dataNomeacao, } = extrairCaudaLotacao(resto);
        const problemas = montarProblemasBasicos(nome, masp, cargo);
        // A Lotação é uma TABELA estruturada. Se as células obrigatórias foram
        // extraídas, o registro é considerado correto mesmo que o PDF tenha
        // removido barras das datas ou pontuação visual.
        const camposTabelaObrigatorios = [
            municipio, escola, masp, nome, admissao, cargo,
            conteudo, cargaHoraria, dataPosse, dataExercicio, dataNomeacao,
        ];
        if (camposTabelaObrigatorios.some((v) => !String(v || "").trim())) {
            problemas.push("Lotação: uma ou mais células obrigatórias da linha não puderam ser lidas.");
        }
        regs.push({
            id: `dia_lot_${meta.pagina}_${slug(masp)}_${i}_${regs.length}`,
            selecionar: problemas.length === 0,
            tipo_ato: "lotacao",
            tipo_label: "Lotação / Mudança de Lotação",
            titulo_ato: `LOTAÇÃO${numero ? ` - ATO Nº ${numero}` : ""}`,
            cabecalho_ato: [`LOTAÇÃO${numero ? ` - ATO Nº ${numero}` : ""}`, textoLegal].filter(Boolean).join("\n"),
            numero_ato: numero,
            ano_ato: numero.split("/")[1] || "",
            texto_legal: textoLegal,
            fundamentacao_legal: textoLegal,
            masp,
            nome_servidor: nome,
            secretaria: meta.secretaria || "SEE/MG",
            cargo,
            admissao,
            municipio,
            orgao_sre: "SRE METROPOLITANA A",
            localidade_escola: escola,
            conteudo,
            carga_horaria: cargaHoraria,
            data_posse: dataPosse,
            data_exercicio: dataExercicio,
            data_nomeacao: dataNomeacao,
            data_vigencia: dataExercicio ? `Exercício em ${dataExercicio}` : "",
            pagina_jornal: `PÁG. ${meta.pagina}`,
            data_jornal: meta.dataEdicao,
            texto_ato: linha,
            fonte_arquivo: meta.arquivo,
            fonte_pagina: meta.pagina,
            bloco_origem: linha,
            texto_origem: blocoTexto,
            confianca: problemas.length ? "revisar" : "alta",
            problemas_validacao: problemas,
            // Escala de página em 1e12 (não 1e9): dá espaço de sobra ao deslocamento
            // de trecho ("trechoBase") já somado em meta.ordemBase pelo chamador
            // (diarioParser.ts), sem jamais invadir a faixa numérica da página
            // seguinte quando a mesma página tem mais de um trecho da SRE A.
            ordem_fonte: meta.pagina * 1000000000000 + (meta.ordemBase || 0) * 100 + i,
            historico_alteracoes: [],
        });
    }
    return regs;
}
// Regressão real (Diário 05/09/2026, pág. 38): além dos atos de Lotação, o
// Diário também publica Férias-Prêmio (Concessão/Afastamento) e Retificação
// em formato de TABELA LARGA — uma linha por servidor, com município,
// escola, MaSP, nome, cargo, admissão e a cauda específica do tipo de ato
// (período/quinquênio/data, ou onde-se-lê/leia-se) espalhados por TODA a
// largura da página. O cabeçalho dessa tabela é sempre "MUNICÍPIO ÓRGÃO DE
// LOTAÇÃO/EXERCÍCIO..." — igual ao cabeçalho da Lauda gerada pelo próprio
// programa — mas o MaSP aparece sem a palavra "MASP" antes do número
// (só no cabeçalho da tabela), então nenhum extrator narrativo encontra
// ninguém aqui: os ~31 servidores de 3 tabelas nessa única página
// desapareciam por completo, sem nenhum aviso.
export const RE_TABELA_LARGA_CABECALHO = /MUNIC[ÍI]PIO\s+[ÓO]RG[ÃA]O\s+DE\s+LOTA[ÇC][ÃA]O\s*\/\s*EXERC[ÍI]CIO/i;
const RE_TABELA_LARGA_ENCERRA = /^(?:DOCUMENTO\s+ASSINADO|SECRETARIA\s+DE\s+ESTADO|SUPERINTEND[ÊE]NCIA\b|ATO\s+N[ºO°.]|RETIFICA(?![ÇC][ÃA]O\s*[-–—])|ANULA(?![ÇC][ÃA]O\s*[-–—])|-?\s*SRE\b|METROPOLITANA\s+[A-Z]\b)/i;
const RE_TABELA_LARGA_CARGO = /\b(PEB|ATB|ANE|AEB|EEB|TDE|ASB)[A-Z0-9]*(?:\/[A-Z0-9]+)?\b/;
// "INST" é a abreviação real usada no Diário para "Instituto" (ex.: "Belo
// Horizonte Inst de Educ de Minas Gerais" — o tradicional Instituto de
// Educação de Minas Gerais). Sem reconhecer essa abreviação, a linha toda
// ("BELO HORIZONTE INST DE EDUC DE MINAS GERAIS") virava município, sem
// nenhuma escola separada — um "órgão/escola não encontrado" que na
// verdade só faltava reconhecer a abreviação.
const RE_TABELA_LARGA_ESCOLA_PREFIXO = /(?:E\.?\s*E\.?\b|ESCOLA\s+ESTADUAL\b|INSTITUTO\b|INST\.?\s+DE\b|CESEC\b|SRE\b)/i;
// `\/+` (não `\/`) em vez de uma barra só: regressão real (Diário 02/10/2026,
// pág. 39) tem uma data publicada com barra DUPLICADA por engano do próprio
// jornal ("02/01//2026") — o dia/mês/ano está certo, só a pontuação saiu
// errada na publicação. Aceitar 1+ barras tolera esse erro de digitação do
// Diário sem deixar de exigir a forma dia/mês/ano.
const RE_DATA_RECONHECIDA = /\b\d{1,2}\/+\d{1,2}\/+\d{2,4}\b/;
/** Prefixo do `problemas_validacao` quando cargo/admissão/data da linha de
 *  tabela PASSARAM na validação estrutural — usado por
 *  `conferenciaDiarioGenerator.ts` para não tratar isso como um problema de
 *  verdade na Conferência Geral (ver `TABELA_LARGA_DIARIO_OK` abaixo). A
 *  linha continua marcada "revisar" (a função nunca promete certeza que a
 *  divisão município/escola não garante), mas o relatório não precisa
 *  assustar o usuário com uma lista de "71 erros" quando na prática é "71
 *  linhas de tabela, todas com cargo/admissão/data no formato esperado,
 *  mesmo cuidado de sempre que se aplica a toda tabela do Diário". */
export const PREFIXO_TABELA_LARGA_OK = "TABELA_LARGA_DIARIO_OK";
export const PREFIXO_TABELA_LARGA_PROBLEMA = "TABELA_LARGA_DIARIO";
/** Parser para a tabela larga de Férias-Prêmio/Retificação (ver comentário
 *  acima). Diferente da Lotação — cuja tabela tem um formato fixo e único —
 *  esta cobre 3 variações de cauda (Concessão: quinquênio+data; Afastamento:
 *  período+quinquênio+data; Retificação: onde-se-lê+leia-se), cada uma com
 *  seu próprio jeito de quebrar linha. Por causa dessa variação, e porque a
 *  fronteira entre MUNICÍPIO e ÓRGÃO/ESCOLA nem sempre é reconhecível (às
 *  vezes o "órgão de lotação" é a própria SRE, não uma escola), esta função
 *  NUNCA classifica como "alta": MaSP e nome saem com confiança alta de
 *  reconhecimento (âncoras inequívocas), mas cargo/admissão/local sempre
 *  pedem conferência humana contra o Diário original — nunca some ninguém,
 *  mas também nunca finge ter 100% de certeza estrutural que não tem. */
export function extrairTabelaLargaFeriasPremio(blocoTexto, meta, opcoes) {
    const emContinuacao = !!opcoes?.emContinuacao;
    const linhas = blocoTexto.split(/\r?\n/).map((l) => normalizarLinha(l)).filter(Boolean);
    const idxCabEncontrado = linhas.findIndex((l) => RE_TABELA_LARGA_CABECALHO.test(l));
    if (idxCabEncontrado < 0 && !emContinuacao)
        return [];
    // -1 quando em continuação sem repetição do cabeçalho: o loop abaixo
    // começa em `idxCab + 1`, ou seja, na primeira linha do bloco.
    const idxCab = idxCabEncontrado;
    const regs = [];
    for (let i = idxCab + 1; i < linhas.length; i++) {
        const linha = linhas[i];
        if (RE_TABELA_LARGA_ENCERRA.test(linha))
            break;
        // A própria continuação do cabeçalho, quando quebra em duas linhas
        // (ex.: "...QUINQUÊNIO DE\nREFERÊNCIA"), ou uma segunda ocorrência do
        // cabeçalho (a mesma tabela pode repeti-lo a cada nova página impressa).
        if (RE_TABELA_LARGA_CABECALHO.test(linha))
            continue;
        const maspMatch = /\d[\d.\s]{3,9}-\s*\d{1,2}/.exec(linha);
        if (!maspMatch)
            continue; // linha sem MaSP reconhecível — não inventa, só ignora (cabeçalho quebrado, rodapé, etc.)
        const antesDoMasp = linha.slice(0, maspMatch.index).trim();
        const depoisDoMasp = linha.slice(maspMatch.index + maspMatch[0].length).trim();
        if (!antesDoMasp || !depoisDoMasp)
            continue;
        const masp = normalizarMasp(maspMatch[0]);
        const prefixoEscola = RE_TABELA_LARGA_ESCOLA_PREFIXO.exec(antesDoMasp);
        const municipio = normalizarLinha(prefixoEscola ? antesDoMasp.slice(0, prefixoEscola.index) : antesDoMasp).toUpperCase();
        const escola = normalizarLinha(prefixoEscola ? antesDoMasp.slice(prefixoEscola.index) : "").toUpperCase();
        const cargoMatch = RE_TABELA_LARGA_CARGO.exec(depoisDoMasp);
        if (!cargoMatch)
            continue; // sem um código de cargo reconhecível não há como separar nome do resto — não inventa
        const nome = normalizarNome(depoisDoMasp.slice(0, cargoMatch.index));
        const caudaAposCargo = depoisDoMasp.slice(cargoMatch.index + cargoMatch[0].length).trim();
        const cargo = cargoMatch[0].toUpperCase();
        const admissaoMatch = /^(\d{1,2})\b/.exec(caudaAposCargo);
        const admissao = admissaoMatch ? admissaoMatch[1].padStart(2, "0") : "";
        // Tudo que sobra (período/quinquênio/data OU onde-se-lê/leia-se, a
        // depender do tipo de ato) fica de fora dos campos estruturados — nunca
        // dividido "no chute" — e vai inteiro para a observação, à disposição
        // de quem for conferir.
        const caudaResto = normalizarLinha(admissaoMatch ? caudaAposCargo.slice(admissaoMatch[0].length) : caudaAposCargo);
        if (!validarNomeServidor(nome).valido)
            continue;
        // Checagem estrutural de verdade (não é só "nunca confia em tabela"):
        // quando cargo, admissão e data batem no formato esperado, a linha fica
        // marcada como rotina — ainda pede conferência (o programa não garante
        // 100% a fronteira entre município e escola nesse formato, ver nota no
        // topo do arquivo), mas sem alarde de "erro" no relatório de
        // Conferência Geral. Quando ALGUMA dessas checagens falha de verdade, a
        // mensagem aponta exatamente qual.
        const cargoValido = validarCargo(cargo).valido;
        const admissaoValida = /^\d{2}$/.test(admissao);
        const temDataReconhecida = RE_DATA_RECONHECIDA.test(caudaResto);
        const problemas = montarProblemasBasicos(nome, masp, cargo);
        if (cargoValido && admissaoValida && temDataReconhecida && municipio && escola) {
            problemas.push(`${PREFIXO_TABELA_LARGA_OK}: extraído de tabela do Diário — cargo, admissão e data no formato esperado; `
                + "ainda recomendável conferir contra a publicação original (o programa não garante 100% a divisão "
                + "entre município e órgão/escola nesse formato de tabela).");
        }
        else {
            const motivos = [];
            if (!cargoValido)
                motivos.push(`cargo em formato não reconhecido ("${cargo}")`);
            if (!admissaoValida)
                motivos.push(admissao ? `admissão não ficou com 2 dígitos ("${admissao}")` : "admissão não encontrada");
            if (!temDataReconhecida)
                motivos.push("nenhuma data reconhecida no período/quinquênio");
            if (!municipio)
                motivos.push("município não encontrado");
            if (!escola)
                motivos.push("órgão/escola não encontrado");
            problemas.push(`${PREFIXO_TABELA_LARGA_PROBLEMA}: extraído de tabela do Diário, com ${motivos.join("; ")} — `
                + "confira cargo/admissão/período contra a publicação original.");
        }
        regs.push({
            id: `dia_tab_${meta.pagina}_${slug(masp)}_${i}_${regs.length}`,
            selecionar: false,
            tipo_ato: meta.tipoAto,
            tipo_label: meta.tipoLabel,
            titulo_ato: meta.tituloAto,
            cabecalho_ato: [meta.tituloAto, meta.textoLegal].filter(Boolean).join("\n"),
            numero_ato: meta.numeroAto || "",
            ano_ato: meta.anoAto || "",
            texto_legal: meta.textoLegal || "",
            fundamentacao_legal: meta.textoLegal || "",
            masp,
            nome_servidor: nome,
            secretaria: meta.secretaria || "SEE/MG",
            cargo,
            admissao,
            municipio,
            orgao_sre: "SRE METROPOLITANA A",
            localidade_escola: escola,
            observacao: caudaResto,
            pagina_jornal: `PÁG. ${meta.pagina}`,
            data_jornal: meta.dataEdicao,
            texto_ato: linha,
            fonte_arquivo: meta.arquivo,
            fonte_pagina: meta.pagina,
            bloco_origem: linha,
            texto_origem: blocoTexto,
            confianca: "revisar",
            problemas_validacao: problemas,
            // Escala de página em 1e12 (não 1e9): dá espaço de sobra ao deslocamento
            // de trecho ("trechoBase") já somado em meta.ordemBase pelo chamador
            // (diarioParser.ts), sem jamais invadir a faixa numérica da página
            // seguinte quando a mesma página tem mais de um trecho da SRE A.
            ordem_fonte: meta.pagina * 1000000000000 + (meta.ordemBase || 0) * 100 + i,
            historico_alteracoes: [],
        });
    }
    return regs;
}
